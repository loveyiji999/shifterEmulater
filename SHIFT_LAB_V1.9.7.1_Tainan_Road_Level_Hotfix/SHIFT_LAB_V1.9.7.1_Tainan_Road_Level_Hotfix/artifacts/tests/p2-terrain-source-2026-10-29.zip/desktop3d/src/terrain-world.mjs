import * as THREE from 'three';
import {TerrainField,TERRAIN_TILE_SIZE} from './terrain-geometry.mjs';

// Chunk-owned, reachable terrain. The exact typed arrays feed rendering and
// collision; quality settings may not replace this near-field support surface.
export class TerrainWorld {
  constructor(road){this.road=road;this.tiles=new Map();this.field=null;}
  clear(){
    for(const tile of this.tiles.values())this.dispose(tile);
    this.tiles.clear();this.field=null;
  }
  dispose(tile){
    const road=this.road;
    if(tile.collider){road.groundHandles.delete(tile.collider.handle);road.surfaceMap.unbind(tile.collider);
      road.world.removeCollider(tile.collider,true);}
    road.scene.remove(tile.mesh);tile.mesh.geometry.dispose();
  }
  make(tx,tz){
    const road=this.road,data=this.field.buildTile(tx,tz);
    if(!data.indices.length)return null;
    const geometry=new THREE.BufferGeometry();let collider=null,mesh=null;
    try{
      geometry.setAttribute('position',new THREE.BufferAttribute(data.vertices,3));
      geometry.setAttribute('uv',new THREE.BufferAttribute(data.uv,2));
      geometry.setAttribute('normal',new THREE.BufferAttribute(data.normals,3));
      geometry.setIndex(new THREE.BufferAttribute(data.indices,1));
      mesh=new THREE.Mesh(geometry,road.soilMaterial);mesh.receiveShadow=true;
      mesh.userData.terrainTile={tx,tz};
      collider=road.world.createCollider(road.rapier.ColliderDesc.trimesh(data.vertices,data.indices).setFriction(.7));
      road.surfaceMap.bind(collider,{kind:'terrain',layerId:`terrain:${tx}:${tz}`,
        faces:Array(data.indices.length/3).fill('earth.'+road.surfaceMap.condition)});
      road.groundHandles.add(collider.handle);road.scene.add(mesh);
      return {mesh,collider};
    }catch(error){
      if(collider){road.groundHandles.delete(collider.handle);road.surfaceMap.unbind(collider);road.world.removeCollider(collider,true);}
      if(mesh)road.scene.remove(mesh);geometry.dispose();throw error;
    }
  }
  ensure(position){
    const state=this.road.physics.route.v3State;
    if(!this.field||this.field.state!==state||this.field.revision!==state.revision){
      this.clear();this.field=new TerrainField(this.road.physics);
    }
    const tx=Math.floor(position.x/TERRAIN_TILE_SIZE),tz=Math.floor(position.z/TERRAIN_TILE_SIZE),needed=new Set();
    const candidates=new Map();
    try{
      for(let x=tx-1;x<=tx+1;x++)for(let z=tz-1;z<=tz+1;z++){
        const key=x+','+z;needed.add(key);
        if(!this.tiles.has(key)){const tile=this.make(x,z);if(tile)candidates.set(key,tile);}
      }
    }catch(error){for(const tile of candidates.values())this.dispose(tile);throw error;}
    for(const [key,tile] of candidates)this.tiles.set(key,tile);
    for(const [key,tile] of this.tiles)if(!needed.has(key)){this.dispose(tile);this.tiles.delete(key);}
    if(candidates.size)this.field.retain({minX:(tx-1)*TERRAIN_TILE_SIZE,maxX:(tx+2)*TERRAIN_TILE_SIZE,
      minZ:(tz-1)*TERRAIN_TILE_SIZE,maxZ:(tz+2)*TERRAIN_TILE_SIZE});
  }
}
