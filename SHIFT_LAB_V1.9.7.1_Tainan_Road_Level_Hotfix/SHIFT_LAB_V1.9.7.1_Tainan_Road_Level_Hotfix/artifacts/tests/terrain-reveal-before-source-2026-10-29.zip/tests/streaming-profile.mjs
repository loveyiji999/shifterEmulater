import {collectPerformanceBaseline} from './performance-baseline.mjs';
export async function collectStreamingProfile({getContext,stepOnce,setPause},options={}){
  const {core:d,road,bridge}=getContext();
  const manager=road.streamer;
  if(options.synchronous&&manager){manager.invalidate();road.streamer=null;}
  if(d.route.config.generator!==3||d.route.config.turnChance||d.route.config.slopeChance)throw Error('Flat V3 trace required');
  const mode=document.getElementById('drive-mode');mode.value='manual';mode.dispatchEvent(new Event('change'));
  setPause(true);d.inputKeys.clear();d.releaseKeyboardOverride();d.requestGear(0);
  Object.assign(d.hostControls,{active:true,steer:0,throttle:0,brake:0,clutch:1,parkPawl:false});
  const place=()=>{road.ensure(70);bridge.teleport({roadPoint:{...d.roadPointAt(70),y:road.position(70,0).y},speed:14});};
  place();let origin=bridge.rigidBody.translation(),end=origin,capturing=false;setPause(false);
  const events=[],original=road.ensure;
  road.ensure=function(...args){const start=performance.now();try{return original.apply(this,args);}
    finally{const ms=performance.now()-start;if(capturing&&ms>1)events.push({s:args[0],ms});}};
  try{
    const result=await collectPerformanceBaseline({renderer:getContext().renderer,road,core:d,getContext},
      {warmupSeconds:options.warmupSeconds??1,captureSeconds:options.captureSeconds??25,requireNative:!!options.requireNative,
        beforeCapture:options.warmupSeconds?place:undefined,onCaptureStart:()=>{origin=bridge.rigidBody.translation();capturing=true;},
        onCaptureStop:()=>{end=bridge.rigidBody.translation();capturing=false;}});
    setPause(true);
    return {...result,scope:'moving real-vehicle terrain streaming trace; not P3 completion',streamEvents:events,
      distanceM:Math.hypot(end.x-origin.x,end.z-origin.z),streaming:road.streamingStats?.()??{mode:'synchronous'}};
  }finally{road.ensure=original;setPause(true);if(options.synchronous&&manager){road.streamer=manager;manager.warmed();}}
}
