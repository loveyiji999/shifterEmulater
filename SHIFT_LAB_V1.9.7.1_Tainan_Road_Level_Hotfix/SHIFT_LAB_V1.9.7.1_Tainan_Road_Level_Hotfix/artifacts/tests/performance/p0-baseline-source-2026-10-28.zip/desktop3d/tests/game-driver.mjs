import {driveRoadV3Check} from './road-v3-driver.mjs';
import {isAutomaticMode} from '../src/automatic-transmission.mjs';
import {collectPerformanceBaseline} from './performance-baseline.mjs';
import {legacyDirectionalKey,legacySteerFromVisualAxis,visualSteeringFromLegacy} from '../src/steering-input.mjs';

// Loaded by main.mjs only in Vite development mode, never in the game build.
export function installGameDriver({getContext,stepOnce,updateHud,applyMap,openGameMode,
  selectAutomaticRange,driveProcedural,setPause,frameView}){
  const $=id=>document.getElementById(id);
  let baseline={status:'idle',result:null,error:null};
function currentSnapshot(){
  const {core:d,bridge,road,vehicle,labReady,paused,autoRange,visualVehicleId,gameModes,userMapConfig,physicsMs,dropSteps,trackedKeys}=getContext();
  if(!labReady)return {ready:false,error:$('input-status').textContent};
  const b=bridge.rigidBody,v=b.linvel(),t=b.translation();
  return {ready:true,scenario:'free',paused,step:d.state.time,
    gear:d.state.gear,pendingGear:d.state.pendingGear,clutch:d.state.clutch,
    engineOn:d.state.engineOn,driveMode:$('drive-mode').value,
    autoRange:isAutomaticMode($('drive-mode').value)?autoRange:null,
    parkPawl:!!d.state.parkPawl,
    x:t.x,y:t.y,z:t.z,vx:v.x,vy:v.y,vz:v.z,
    signedVelocity:d.state.velocity,
    speed:Math.hypot(v.x,v.y,v.z),yaw:d.vehicleMotion.yawRate,
    roll:d.vehicleMotion.roll,pitch:d.vehicleMotion.pitch,
    contacts:d.suspension.contacts,rayHits:bridge.wheelCastHits,
    wheelSurfaces:d.WHEEL_IDS.map(id=>({id,contact:d.wheelModel[id].contact,
      surface:d.wheelModel[id].contactSurface??null,normal:d.wheelModel[id].normal})),
    vehicleSchema:vehicle.definition.schema,
    wheelVisuals:vehicle.wheels.map(({id,pivot})=>({id,localY:pivot.position.y,
      expectedLocalY:bridge.wheelVisualState[id]?.hubLocalY??null})),
    invalidWheelLoads:bridge.invalidWheelLoads,contactMicrosteps:bridge.contactMicrosteps,
    forceResetCount:bridge.forceResetCount,maxExternalForceN:bridge.maxExternalForceN,
    maxExternalTorqueNm:bridge.maxExternalTorqueNm,bodyMassKg:b.mass(),
    railHits:bridge.railHits,
    barrierHits:bridge.barrierHits,collisionCount:bridge.collisionCount,
    impact:bridge.maxImpactImpulse,penetration:bridge.maxBarrierPenetration,
    routeS:d.route.distance,physicsMs,frameDrops:dropSteps,
    driverMode:$('drive-mode').value,inputKeys:[...trackedKeys],mapSeed:d.route.config.seed,
    roadEnvironment:'procedural',
    uiMode:gameModes?.mode||'drive',
    driverSteer:visualSteeringFromLegacy(d.vehicleMotion.steerInput),
    legacySteer:d.vehicleMotion.steerInput,roadSurface:d.state.surface,
    vehiclePreset:visualVehicleId,roadResources:road.resourceStats(),
    focus:document.activeElement?.id||document.activeElement?.tagName||'none'};
}
  window.__SHIFT_LAB_3D_QA__={
    startBaseline(options){
      if(baseline.status==='running')throw Error('Baseline already running');
      const context=getContext();
      if(context.paused||context.locked)throw Error('Baseline needs active simulation');
      baseline={status:'running',result:null,error:null};
      collectPerformanceBaseline({renderer:context.renderer,road:context.road,core:context.core,getContext},options)
        .then(result=>{baseline={status:'complete',result,error:null};})
        .catch(error=>{baseline={status:'failed',result:null,error:error.message};});
      return {status:baseline.status};
    },
    get baseline(){return baseline;},
    frameView,version:'1.9.7.1',steeringMapping:{visualLeft:legacyDirectionalKey('a'),
      visualRight:legacyDirectionalKey('d'),visualPadRight:legacySteerFromVisualAxis(1)},
    get ready(){return getContext().labReady;},get paused(){return getContext().paused;},
    snapshot:currentSnapshot,
    step(n=1){const {labReady,locked}=getContext();if(!labReady||locked)throw Error('busy/not ready');
      setPause(true);
      for(let i=0;i<Math.max(0,Math.min(10000,Math.trunc(n)));i++)stepOnce();
      updateHud(true);return currentSnapshot();},
    driveRoadV3(options){return driveRoadV3Check({getContext,stepOnce,setPause,snapshot:currentSnapshot},options);},
    get map(){return {...getContext().core.route.config};},
    get savedMap(){return {...getContext().userMapConfig};},
    get roadQuality(){const q=getContext().core.route.quality;return q?{...q}:null;},
    driveProcedural(){driveProcedural();return currentSnapshot();},
    applyMap(config){applyMap(config);return currentSnapshot();},
    openMode:openGameMode,selectAutomaticRange
  };
}
