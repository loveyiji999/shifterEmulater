# V1.9.3 技術實作：真實 Overture 建築模型

## 版本範圍

以使用者驗收的 V1.9.2 原始碼及真實台南道路 `tainan-station-roads.json` 為基準。本次只新增 `buildings/building` 資料鏈、建築視覺化、碰撞與資料切換，保留原網頁架構、Rapier 車輛動力、PRND、換檔及程序化 QA。來源不得被測試 fixture 冒充。

## 模組及格式

1. `src/city-buildings-geo.mjs`：固定 `TAINAN_STATION` 投影，使用 Sutherland-Hodgman 對 2×2 km 裁切，支援 Polygon/MultiPolygon/holes，輸出 `shiftlab.city.buildings.v1`；有效 Overture `properties.theme === "buildings"`／`type === "building"`、ODbL 與幾何上限均需通過檢查。若內院裁切產生拓撲不確定性，不製造實心屋頂。
2. `src/city-building-geometry.mjs`：每個建築多邊形以來源頂點為準，使用 Three.js Earcut 產生屋頂及外牆，支援真內院、升高底部。indexed triangles／vertex colors 與 Rapier 共用頂點及索引。200m 格網合併 mesh，避免每個建物產生一個 draw call 或 collider。
3. `src/city-world.mjs`：`setBuildings()`, `clearBuildings()`, `syncBuildingColliders()`, `buildingStats`；批次渲染整區量體，車輛附近 245m 載入建築 trimesh；車位中心與上次同步移動超過 60m 才更新；切換程序化模式完整回收。地面及道路 collider 仍由 V1.9.2 建立。
4. `src/main.mjs`：城市模式新增縮放／平移街廓預覽、建築狀態、官方資料檔 `./data/tainan-station-buildings.json` 自動載入與單檔匯入。缺建築不阻擋道路駕駛，不提供任何假造街廓。
5. `scripts/prepare-tainan-buildings.mjs`：轉換器先解析和驗證，寫入 `.tmp` 後原子替換輸出，不覆蓋舊有效結果。
6. `scripts/fetch-tainan-buildings.py`：官方 `overturemaps.record_batch_reader("building",bbox=...)` + `get_writer("geojson")`，嘗試 STAC release 識別，轉檔完成才將原始 GeoJSON 納入 `overture_raw`；Windows 一鍵腳本在 `desktop3d/FETCH_TAINAN_BUILDINGS_WINDOWS.cmd`。

## 來源高度與渲染分級

| `heightSource` | 規則 | 意義 |
|---|---|---|
| `height` | 官方 `height` 1~350 m | 來源高度；**不是獨立現場量測** |
| `floors` | 合法 `num_floors × 3.2 m` | 樓層推估，非真實高度 |
| `estimated` | subtype 用途預設值；未知者 9.6 m | 未知高度的工程預設 |

有有效 `min_height` 時基底使用該值，缺少則使用有效 `min_floor × 3.2 m` 或 0 m，頂端為基底加高度。色彩區分三個資料可信度類別。

## 已驗證與未實測的界線

- 官方來源下載需要可對外連網，本環境 DNS 解析失敗，因此目前發行 zip **沒有真正的新建築圖資**；產生的是轉換器、Renderer、Collider 及 QA，不能宣稱目前已觀測台南實際建築。原道路檔仍有效。
- 測試 geometry fixture 使用虛擬坐標且只存在測試程式；沒有放到遊戲的 `public/data/`。
- 目前沒有真正的橋高／道路三維分層、建築材質或建築物理結構破壞；不主張街景已完全還原。
