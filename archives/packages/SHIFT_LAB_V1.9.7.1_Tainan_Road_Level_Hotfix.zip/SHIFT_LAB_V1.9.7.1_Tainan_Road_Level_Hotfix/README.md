# SHIFT LAB V1.9.7.1 — 臺南路面浮空／建築高度基準／路口高低接縫修復

**修補 V1.9.7 已回報的缺陷**：市區道路相對地面浮空，普通路面與建築基準不同，以及多岔路口坡道接面不平整。本版保留官方 Overture 路網與建築輪廓座標、四輪物理、手排、自排、護欄及橋下碰撞設施。

## 立即啟動

1. 解壓完整包至新資料夾。若 V1.9.7 已下載 `desktop3d/public/data/tainan-station-buildings.json`，請直接從舊版複製到新專案相同路徑。**不需重新下載道路或建築**。
2. 執行根目錄 `START_WEB_WINDOWS.cmd`，進入臺南道路駕駛模式。
3. 可先執行 `desktop3d/QA_V1971_WINDOWS.cmd`，驗證城市高度接縫、V1.9.6 立體地形、V1.9.7 橋梁護欄及 V1.9.5 平面路網回歸。

## 修復內容

- **共同高度基準**：一般平面地面與建築地基以本地 `Y=0` 表示；柏油使用 `Y=0.025 m` 的最小視覺間距（原本路面 Y=0.16、地面 Y=-0.02），避免地面與道路過度分離。
- **路口坡道精確銜接**：先計算 connector 路口的實際面片範圍，再將坡度分配在路口**以外**的路段；所有進出道路在接面具有同一個高度，不新增短距離過陡「補接坡」。
- **低坡道路旁的浮空側面**：新增程序化接地邊坡視覺幾何；它不是行駛用柏油，也不加入輪胎接地碰撞。
- **地下道地面與側壁**：重新計算開挖門檻、擋土壁與一般地面橫越的高度避讓，保留橋梁／地下道與實際 Rapier 路面三角網格分層。

**重要限制**：`level_rules` 只有相對層級，沒有臺南實測 DEM/高程。橋梁、坡道、地下道的絕對高度仍是工程估算；已知部分有來源層級的道路本來就應高於地面，不能把它們與建築強制拉成同高度。新增補坡不代表當地真實填土結構。

**離線 QA 已通過**，完整資料見 `V1971_IMPLEMENTATION.md`、`V1971_QA.md`。本環境無法從離線 npm 快取安裝 Vite／Rapier，正式 WebGL 駕駛及 Rapier 動態碰撞尚待 Windows 驗收。

---

## 以下保留 V1.9.7 舊版說明作為歷史參考

# SHIFT LAB V1.9.7 — 立體橋梁結構、護欄、擋土壁與附屬設施

本版延續使用者已驗收的 V1.9.6 臺南立體道路／地下道物理，不改動來源道路平面圖資或車輛動力，增加**可視橋板、推估橋墩、Rapier 可碰撞防護欄、下凹道路擋土壁及反光標記**。

## Windows 安裝與驗收

1. 將本版完整 ZIP 解壓至**新資料夾**；如 V1.9.6 已下載過官方建築，請從舊版複製 `desktop3d/public/data/tainan-station-buildings.json` 到同一路徑，否則可執行 `desktop3d/FETCH_TAINAN_BUILDINGS_WINDOWS.cmd`。道路資料已內附，**不需再執行道路下載**。
2. 雙擊根目錄 `START_WEB_WINDOWS.cmd`，Vite 服務啟動後於瀏覽器進入臺南駕駛；按原本方式操控車輛、手排、自排或手柄。正常駕駛不新增測試文字介面。
3. 可以先雙擊 `desktop3d/QA_V197_WINDOWS.cmd` 做不依賴 npm 套件的幾何和既有平面回歸。安裝套件後另執行 `npm run qa:city:structures:rapier`、`npm run qa:all`、`npm run build`。
4. 在臺南預覽／測試模式檢視「立體道路結構」統計與診斷圖層，實際駕駛高架路、橋下道路與下凹段。進階 QA 請閱讀 `V197_QA.md`。

**特別說明**：Overture `level_rules` 表示相對上下層，**不是實測海拔**；護欄高度、橋墩位置、橋板厚度、擋土壁位置和構造均為遊戲工程估計，不代表真實臺南建設圖。橋下淨空、隧道頂板、精細路面美術、交通號誌、路權等並未達正式還原程度。詳見 `V197_IMPLEMENTATION.md` 與 `V197_QA.md`。

---

## 以下為 V1.9.6 及更早版本封存說明

# SHIFT LAB V1.9.6 — 臺南立體道路與坡道碰撞物理

V1.9.6 延續 V1.9.5 的真實 Overture 臺南 2×2 公里道路、建築及獨立四輪車輛模型。**本版的優先目標是三維車行路面在畫面與 Rapier 上使用一致的幾何**：來源道路層級決定橋梁／下凹段，連接路網生成過渡坡道，地表開口避免原本平坦地面阻塞地下路段。V1.9.7 的橋墩、護欄與立體道路外觀、V1.9.8 的材質光照均未提前宣稱完成。

## 立即使用（Windows）

1. **完整包**：解壓縮 `SHIFT_LAB_V1.9.6_Tainan_3D_Road_Physics.zip`，建議用新資料夾，勿覆蓋舊版 ZIP 本體；新包保留所有原有程式與臺南道路資料。
2. 若你在 V1.9.5 已取得真實建築資料，將舊版 `desktop3d/public/data/tainan-station-buildings.json` 複製至同一路徑。若還沒有，執行 `desktop3d/FETCH_TAINAN_BUILDINGS_WINDOWS.cmd`；**無須為 V1.9.6 再下載一次道路**。
3. 執行根目錄 `START_WEB_WINDOWS.cmd`。第一次啟動會檢查／安裝 npm 相依套件。進入「台南」即可開始駕駛，原先換檔、手柄與鍵盤仍可使用。
4. 在台南城市預覽的「立體道路診斷」開啟「顯示真實柏油路面三角形」：觀察橋面、下凹段、接點與標線的高度。可在下方讀取估算高程、坡度、道路／輪跡 QA，並匯出 `SHIFT_LAB_V196_City_3D_Road_QA.json`。
5. 如需執行程式層驗收，可直接雙擊 `desktop3d/QA_V196_WINDOWS.cmd`（只需 Node.js、不需要 npm 下載）。進階驗收在 `desktop3d` 執行 `npm run qa:city:elevation`、`npm run qa:city:elevation:rapier`（後者需 npm 相依套件）、`npm run qa:all`。

## V1.9.6 已實作

- **來源層級轉成三維道路**：保留 `level_rules` 的區間資訊，新增 `sourceRange` 記錄裁切段在原始 Overture 中心線的位置，避免把帶有 `between` 規則的區間錯套到地圖裁切線段。
- **路網接點統一高度與漸變坡道**：只沿官方 connector 連通關係延伸上下層高度；沒有 connector 的平面交叉**不合併高度**。路口面片、坡道分段及其 Rapier `trimesh` 共用同一座標來源，避免把視覺坡道當成物理平路。
- **橋面與下凹道路可被實際車輪接觸**：3D 車行三角形直接進入 Rapier；車輛瞬移與重置改為使用實際起始道路 Y，不再假定台南路面恆等於 0.16m。車輪懸吊、重力、車身俯仰仍沿用原物理核心。
- **地表避讓與恢復地面**：地面改為與 Rapier 共用的局部開挖三角網格，對低於地面的道路預留通行孔洞。孔洞下方有明確標為「安全恢復平台」的碰撞面，不冒充真實隧道底板或土壤地形。
- **街道繪製跟隨坡度**：估算式中心虛線、車道邊線、路緣與人行道跟隨所屬路面的 Y；它們依然是無物理碰撞的視覺幾何。
- **保留舊版驗證**：V1.9.5 原平面路面網格可以透過 `elevationMode:'flat'` 完全重現，保留其原始 SHA-256 回歸驗證。車輛動力、路權、道路平面拓樸與原先 2D 幾何的 XY 資料不變。

## 高程資料準確性與已知限制

**Overture `level_rules` 是高低層關係，而非真實海拔或公尺高度。** V1.9.6 用每層 **5.25 公尺**、單方向估算漸變坡度約 **7.5%** 建立可模擬的高度；正負層級在相近的同一路網相互影響時，部分生成路段可能達 **15%**。系統提供最大坡度 QA 以供人工複核，**這些數字不能當成臺南真實道路坡度／橋梁淨高**。市區普通道路在沒有 DEM 時維持參考 Y=0.16m，不代表實測海拔。

地面開挖為安全通行用的方格缺口，未建立測繪級路堤、隧道頂板／側牆、排水、橋墩、道路護欄、真正的高程 DEM、車道號誌與路權。高架下面的地面和地下段周圍可能有視覺斷面，預計在 V1.9.7 補齊建構細節。**在完成帶高度的官方 DEM／測量資料與 Windows 實車操作 QA 以前，本版只能稱為幾何及物理架構正確的工程原型，不能稱為真實高程完全還原。**

實作細節與驗收情況：`V196_IMPLEMENTATION.md`、`V196_QA.md`。來源與授權：`DATA_PROVENANCE.md`，**© OpenStreetMap contributors, Overture Maps Foundation（ODbL 1.0）**。

---

## 以下為 V1.9.5 及更早版本封存說明

# SHIFT LAB V1.9.5 — 臺南真實道路精度與路口 QA

本版沿用 V1.9.4 的 Overture 真實道路、建築量體和四輪物理。改善的重點是**實際行駛場景的道路視覺連續性和可查證的路口品質**，不是重做車輛操控，也不是用程序化道路取代台南圖資。

## Windows 使用／更新

1. 若目前 V1.9.4 已能遊玩且已取得建築資料，請**備份原資料夾後使用 V1.9.5 覆蓋更新包**，解壓內容覆蓋到 V1.9.4 專案根目錄。覆蓋包不含 `desktop3d/public/data/`，不會替換你已有的真實台南建築 JSON。
2. 若選擇完整包，解壓後將先前下載的 `desktop3d/public/data/tainan-station-buildings.json` 複製回新專案；尚未取得時，執行 `desktop3d/FETCH_TAINAN_BUILDINGS_WINDOWS.cmd`。
3. 執行根目錄 `START_WEB_WINDOWS.cmd`，開啟 `http://127.0.0.1:5173/`，進入「台南」城市預覽。
4. 可開關標線／人行道／碰撞診斷，使用「定位下一處路口異常候選」及「定位下一處疑似重疊」檢查街廓；匯出 V1.9.5 城市診斷 JSON。
5. 不必開遊戲的診斷：執行 `desktop3d/AUDIT_TAINAN_STREETS_WINDOWS.cmd`，輸出到 `desktop3d/reports/tainan-street-audit.json`。若建築 JSON 未存在，建築部分會標記「未測」，而不是零重疊。

## V1.9.5 改善內容

- **標線與路口銜接**：同一 Overture segment 即使被 connector 切成多段，虛擬虛線的間距仍以原始長度對齊；路口進出口新增標線退縮安全區。這些標線只作工程可視化，不是台灣實際車道標線資料。
- **人行道與路緣**：對已知柏油碰撞曲面執行實際三角形覆蓋檢查，排除可能畫在其他道路上的猜測式人行道面板；路口的裸露邊緣新增估算式轉角路緣和人行道片段。**不新增任何人行道／路緣 Rapier 碰撞體**。
- **輪胎軌跡空間驗證**：以 1.56 m 左右輪距（中心左右各 0.78 m）對路面三角形逐段取樣，與原中心線覆蓋檢查分開。台南內附資料的 39,252 個可容納輪距取樣點均命中柏油；另外 2 段真實寬度為 1.5 m 的服務道路被分類為**過窄**，不會被誤判為碰撞缺口或被虛假拓寬。
- **路口品質複核**：列出急角、多重分支、短道路及填充面偏大的候選節點，支援畫面定位與離線 JSON。需人工複核，不能直接宣稱官方地理資料錯誤。
- **凹形建築重疊精度**：對 Polygon／holes 的幾何交集採用逐三角形計算，避免將內凹的建築輪廓當成凸形填滿；標記道路寬度來自來源規則還是估算，以便區分疑似「路幅過寬」的假警報。

## 安全及資料精度

- 所有道路位置來源仍是 V1.9.4 的 Overture 車行中心線和 connector。**30,168 個原柏油三角形與 291 個分區的幾何頂點／索引雜湊值完全一致**，未以外觀改動來增加車輛碰撞或填補地形。
- `source-rule` 只代表本資料含 Overture 寬度規則；不代表對應道路可安全通行或建築位置已現場勘測。大部分道路寬度仍依分類估算。
- 仍未處理橋梁／地下道高程、真實交通管制、各道路的實測車道數、道路材質貼圖、正式交通號誌。地面下方恢復平台保留，並非真實地形。
- 工程自動 QA 是**二維路面支撐**；實際 Windows WebGL2 + Rapier 駕駛與台南建築外觀仍需你實機驗收。

開發明細見 `V195_IMPLEMENTATION.md`，驗收結果與限制見 `V195_QA.md`，前版內容保留如下。

---

# SHIFT LAB V1.9.4 — 臺南真實街道細化與 QA

這個版本沿用 V1.9.3.1 車輛物理、真實道路與建築碰撞，在城市畫面新增**估算式**路面標線、人行道與路緣視覺、道路／建築投影交疊掃描、10m 米制尺及地理座標診斷。新增圖層不替換原本的物理車行路面。

## Windows 使用

1. 解壓後執行專案根目錄 `START_WEB_WINDOWS.cmd`（與前版相同）。
2. 真實建築不包含在下載包中。若先前已下載成功，請保留或複製原 `desktop3d/public/data/tainan-station-buildings.json`；若從全新目錄解壓，請執行 `desktop3d/FETCH_TAINAN_BUILDINGS_WINDOWS.cmd`。
3. 進入「台南」城市預覽，尋找「V1.9.4 · 街道橫斷面與幾何驗證」區塊，可切換標線／路緣人行道／碰撞三角形、檢查疑似重疊並匯出 JSON。
4. 「測試模式」也能查看最近道路寬度（區分官方寬度規則／推估）、WGS84 和米制座標。
5. 需要不開瀏覽器的批次診斷時，雙擊 `desktop3d/AUDIT_TAINAN_STREETS_WINDOWS.cmd`，輸出 `desktop3d/reports/tainan-street-audit.json`。如果沒有正式建築 JSON，報告會標示「建築資料未載入」，**不會宣稱零重疊**。

**重要：** 本版人行道、路緣與車道塗裝均不是官方提供的實際橫斷面測量值，不可作為導航或交通標誌依據；已驗收的車輛和柏油碰撞邏輯不變。

開發細節：`V194_IMPLEMENTATION.md`；QA 結果及尚未驗證事項：`V194_QA.md`。以下保留前版歷史說明。

---

# SHIFT LAB V1.9.3.1 — 臺南建築資料下載與轉檔修復

**網頁單機可駕駛原型**（Vite / Three.js / Rapier）／2026-10-22。沿用 V1.9.2 臺南火車站 2×2 km Overture 真實道路、路口、四輪車體、換檔與物理驗收，不更動實車動力模型。

## V1.9.3.1 修復說明（2026-10-22）

V1.9.3 官方建築下載可完成，但 Node 轉檔器錯把 `properties.theme/type` 當成必填欄位。`overturemaps` v1.0.2 透過 `get_writer('geojson')` 產生的正式 GeoJSON，可能只在資料分區中包含 `theme=buildings/type=building`，而不在每筆 `Feature.properties` 重覆輸出。舊版因此在成功下載後誤判而報錯。新版仍會驗證 Overture 必填 `version`、唯一 `id`、Polygon／MultiPolygon 座標及明確提供時的 `theme/type`，不會加入虛構建築。

**此修復不含真實台南建築檔；你仍需在 Windows 下載一次。** 因為 V1.9.3 原程式在轉檔失敗時會刪除 `.download`，若先前執行失敗且快取已被移除，就不能重用那次下載。V1.9.3.1 會保留轉檔失敗的快取（及 SHA256+release 來源紀錄），重新執行同一 Windows 腳本會優先重試本機檔案，不會再下載。手動命令：

```powershell
cd desktop3d
python scripts/fetch-tainan-buildings.py --reconvert-only  # 只重轉、絕不連網；沒有快取會明確失敗
python scripts/fetch-tainan-buildings.py                  # 有快取即轉換，無快取才下載
python scripts/fetch-tainan-buildings.py --refresh        # 強制取得最新 Overture 發布資料
```

**建議先使用 Windows 一鍵腳本** `desktop3d/FETCH_TAINAN_BUILDINGS_WINDOWS.cmd`。成功時應輸出 `PASS Overture 台南真實建築資料轉換`，並在 `desktop3d/public/data/tainan-station-buildings.json` 寫入真實輪廓（不是測試資料）。重新整理瀏覽器即可。詳細資料見 `V1931_HOTFIX.md`。

## V1.9.3 已有功能

- **真實建築輪廓**：官方 Overture `theme=buildings/type=building` GeoJSON 經 WGS84→本地公尺投影及範圍裁切，保留 Polygon、MultiPolygon、內院挖空、建築名稱、用途、`height`、`num_floors`、`min_height`。
- **3D 街廓**：依來源輪廓產生實體外牆與屋頂，批次索引幾何，每 200 m 一個空間瓦片。依高度資料品質使用不同色系，不使用隨機街廓替代地理位置。
- **Rapier 建築碰撞**：屋頂與牆面使用相同索引幾何的 `ColliderDesc.trimesh`。僅載入車輛半徑約 245m 內的建築碰撞分塊，行駛時更新；返回程序化道路會回收。
- **高度區分**：來源 `height` 直接使用；有 `num_floors` 則以每層 3.2 m 推算；其餘依用途給明確標示的估高。沒有高度資料**不代表實測高度**。
- **建築資料匯入**：城市介面可匯入原始官方 building GeoJSON 或轉換後 JSON；支援從磁碟重新讀取、顯示來源高度／樓層估高／預設估高棟數。

## 重要：本壓縮檔沒有新的台南建築圖資

本發行檔包含 **V1.9.2 真實道路**（可直接行駛），但不包含臺南 Overture `building` 原始資料或轉換結果。理由：此執行環境無外部網路存取，未取得可驗證的真正臺南建築檔案。**未使用程序化假建物頂替真實圖資。** 如果尚未執行以下下載，遊戲會顯示道路，但城市畫面會明確提示「建築圖資未載入」。

### Windows 最快使用方式

1. 解壓縮整個專案。
2. 第一次下載官方建築：進入 `desktop3d`，雙擊 **`FETCH_TAINAN_BUILDINGS_WINDOWS.cmd`**（需要 Python 及網路，會安裝官方 `overturemaps` 套件）；下載成功會在 `desktop3d/public/data/` 產生 `tainan-station-buildings.json`。
3. 在專案根目錄雙擊 **`START_WEB_WINDOWS.cmd`**，瀏覽 `http://127.0.0.1:5173/`。如果你先啟動遊戲、再下載建築，重新整理網頁即可。
4. 選擇「臺南真實街道」可利用縮放、北南東西平移按鈕俯瞰真實建築輪廓，按「開始駕駛台南道路」即可在原四輪物理中行駛並與建物碰撞。自排若是 P 檔需切到 D 檔才會前進。

若沒有 Python，但可在 <https://explore.overturemaps.org/> 下載指定範圍的 `building` GeoJSON，可在遊戲的城市模式直接使用「匯入官方建築 GeoJSON」檢視（瀏覽器匯入不會自動儲存到本機專案）。

### 命令列與手動轉檔

需要 Node.js 20.19+ 或 22+；下載 Overture 需 Python + `overturemaps`、網路：

```sh
cd desktop3d
python -m pip install overturemaps
python scripts/fetch-tainan-buildings.py
# 或：已下載的官方 GeoJSON
node scripts/prepare-tainan-buildings.mjs overture_raw/tainan_building.geojson
# 啟動／測試
npm install
npm run dev
npm run qa:all
```

目標範圍與 V1.9.2 道路完全一致：中心 22.9972062216332°N、120.212369589515°E，東西與南北各 ±1000 m。官方建築下載紀錄放在 `overture_raw/tainan_building.geojson`，緊湊地圖放在 `public/data/tainan-station-buildings.json`，格式 `shiftlab.city.buildings.v1`。

## 已知限制

- 建築輪廓為屋頂投影或地面占地輪廓，不等於真實立面、照片或精確街景；目前皆為柱狀量體，尚未建置窗戶、騎樓、地標模型、斜屋頂和建築分層。`building_part` **不在** V1.9.3 施工範圍。
- `min_height`、樓層高度以模型近似處理，來源並不保證每棟都有高度。部分 Overture ML 建築輪廓誤差可能與 1.9.2 道路視覺寬度重疊。**沒有更動或假造真實位置來掩飾重疊。**
- 路面仍是 Y≈0.16 m 平面：真實高程、橋梁、隧道高架分層、停車動線、建築與路面高程一致性將由後續版本處理。
- 舊版程序化道路及物理測試仍然保留。最終驗收需在支援 WebGL2 的 Windows 瀏覽器操作，檢查附近路口的建築相對位置。
- 當前 Linux 測試環境內隨包提供的是 Windows 平台 node_modules（僅作單元測試），缺少 Rollup 的 Linux 原生套件；Linux 本機 `vite build` 未能執行。正式壓縮檔不含 node_modules，Windows 首次啟動會安裝平台正確的相依套件。

## QA／追溯

- `V193_IMPLEMENTATION.md`、`V193_QA.md`、`V193_QA_RESULT.log`：實作／測試／已知限制。
- `V192_IMPLEMENTATION.md`、`V192_QA.md`、`README_V192_ARCHIVE.md`：前一版功能與道路幾何驗證。
- `DATA_PROVENANCE.md`：道路與建築官方來源、ODbL、標示／釋出責任。地圖授權署名：**© OpenStreetMap contributors, Overture Maps Foundation**。
