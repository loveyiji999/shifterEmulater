## V1.9.7.1 — 2026-10-22 — Road Datum and Junction Seam Hotfix

- Fixed the at-grade city road / terrain / Overture building base Y mismatch (old asphalt +.16m, old soil -.02m, building base 0m). Shared ground Y=0 and road Y=+.025m.
- Reordered connector trim and topo-aware grade propagation: all 5,832 Tainan road arm caps now match their associated connector heights. Avoids original sloped hull height mismatches at omitted convex-hull vertices without creating local steep ramps.
- Re-tessellated estimated approach ramps (35,018 3D triangles) while preserving the Overture XY, clipped chainages, connectors and vehicle physics. Flat path XY/index regression against V1.9.5 still passes after a legacy Y baseline normalization.
- Added visual, noncolliding low-rise approach fill and revised underpass retaining-wall crossing clearance for the new ground datum.
- Added offline V1.9.7.1 tests, Windows QA runner, docs and fixed UI/package version metadata. Real Rapier dynamic and Vite/WebGL integration still need Windows QA due missing npm archive cache.

## V1.9.7 — 2026-10-22 — Elevated Road Structures and Safety Edges

- Added `city-road-structures.mjs` as a pure, deterministic 3D geometry generator; V1.9.6 asphalt buffers, Overture XY/source-level mapping and chassis controls remain unchanged.
- Added visual bridge slabs and undersides, guardrails with physical closed triangle meshes, below-grade retaining walls with physical colliders, crossing-aware inferred bridge supports, caps and roadside reflectors.
- Added a Y-aware road-triangle collision exclusion so normal grade-separated roads don't erase each other's railing, and support avoidance for lower active roads and imported building footprints.
- Added Three material/tile lifecycle, `railHandles` and `barrierHandles` classification, cleanup and independent diagnostic statistics, without adding wheel raycast targets.
- New offline `qa:city:structures` PASS and Windows QA helper; V1.9.6 elevation, V1.9.5 flat hash, powertrain, steering and chassis Node regression PASS. Native Rapier/Vite/WebGL acceptance blocked by npm DNS restrictions and must be performed on Windows.
- All construction dimensions and bridge pier locations are estimated, not source-surveyed; fine materials, lighting and accurate building facades remain V1.9.8 scope.

## V1.9.6 — 2026-10-22 — Topological Elevation / Bridge and Underpass Physics

- Kept exact Overture XY/connector/width inputs; stored original normalized chainage for clipped features (`sourceRange`) so partial `level_rules.between` remain traceable.
- Raised/lowered road decks derived from Overture level ordering with clearly labeled estimated 5.25m/level heights and topology-connected graded transitions. Nonconnected XY crossings can exist on two distinct physical decks.
- Road geometry and Rapier contact use the same XYZ triangle buffers. Junctions with elevation changes use connector-centred 3D fans to prevent detached ramps; at-grade v1.9.5 geometry hash remains available in flat regression mode.
- Removed solid soil obstruction from below-grade roads via a conservative shared render/physics terrain mesh with local excavation and separate bottom recovery floor. Never generate a fake Overture tunnel geometry.
- Paint, curbs and estimated sidewalks follow parent road Y while remaining noncolliding; city HUD and QA export label unsurveyed relative heights/grades.
- Added `tests/validate-city-elevation-v196.mjs` and optional Rapier contact test; retained legacy v195 hash test unchanged in flat mode. No road-source geometry displaced.
- Unverified: npm/Rapier+WebGL driver integration in this DNS-restricted Linux runner; road levels are not DEM, bridge piers/guardrails and tunnel portals remain future work.

## V1.9.5 — 2026-10-22 — Roads, Junctions and Diagnostics

- Connector-consistent dashed-line spacing; setback of markings from complex intersections.
- Visible sidewalk/curb corner returns, with asphalt-overlap rejection (visual only).
- Junction angle/short-link/hull-width candidate QA; metric wheel-track support check and separate narrow-road classification.
- Concave/holed building footprint overlap accuracy improvement; width-evidence annotation.
- Dedicated offline report, city debug markers and Node regression; existing Rapier asphalt hashes preserved.
- No new fake streets, collision rails or auto-repaired widths; full browser/WebGL driving acceptance pending Windows.

# V1.9.4 · Street Geometry and Diagnostic QA (2026-10-22)

- 實作可切換的估算式標線／路緣／人行道視覺層；不加入不可信的道路碰撞體。
- 新增道路三角形／10 公尺參考尺／建築疑似重疊 QA 與匯出。
- 將道路寬度規則來源與分類估算分別統計；街廓比對含多邊形內院孔洞。
- 新增 36,349 個路口進出中心線的純幾何覆蓋 QA（0 漏點）、可於 Windows 直接執行的離線 JSON 診斷工具。
- 保留 V1.9.3.1 的建築資料下載修復、自排、手排、四輪物理及所有原圖資。
- 詳見 `V194_IMPLEMENTATION.md`、`V194_QA.md`。

---

## V1.9.3.1 (2026-10-22) — 建築官方 GeoJSON 相容性 Hotfix

- 修正 overturemaps-py 官方 GeoJSON 不含 `properties.theme/type` 而被誤判的 bug；新增有效 `version` 檢核、維持錯誤分類拒絕。
- 下載後轉檔失敗不再刪掉原始 `.download`；優先使用快取，加入 `--reconvert-only`、`--refresh` 與 SHA256 來源 release 紀錄。
- 官方 writer 格式與 4,985 筆合成 fixture 離線重轉及失敗復原測試。
- 不變更道路、車輛模型或遊戲引擎；沒有偽造或內附真實台南建築圖資。

## 2026-10-22 · V1.9.3 臺南真實建築量體

- 新增官方 Overture buildings/building 下載、WGS84/2km 裁切、3D Polygon/MultiPolygon/內院、建築分區 Rapier 碰撞、可追溯高度估算、城市介面讀取/匯入。
- 保留 V1.9.2 的真實道路、道路碰撞、路口和原車輛物理。建築資料尚未成功下載，**不內附虛構地理位置建築**；請在自己的 Windows 上執行 FETCH_TAINAN_BUILDINGS_WINDOWS.cmd。
- 新增 V193_IMPLEMENTATION.md／V193_QA.md／V193_QA_RESULT.log；新增 v1.9.3 GeoJSON 與 Rapier 回歸測試。

# SHIFT LAB V1.9.2 — 臺南車站真實道路物理接入（2026-10-22）

- 真實 Overture 1,342 筆車行道路建立 3,196 個道路路廊、962 個 T 字路口、295 個四向路口；以實際 connector 座標剔除裁切後無效關聯。
- Three.js 路面和 Rapier 路面 collider 共用 30,168 個路面三角面；分成 291 批碰撞網格，另有 1 個較低的越野緩衝地面。
- 原四輪 Rapier 車輛可以在真實道路上使用原油門、煞車、左右轉與 PRND／手排機制；停用程序化單一路線對城市位姿的重置限制。
- 真實圖資有效時預設進入台南駕駛；保留程序化測試地圖，支援兩種地圖雙向切換及碰撞資源清理，駕駛畫面常駐 Overture／OSM 署名。
- `npm run qa:all` 全部通過；1,257 個 T／四向路口中心與 35,098 個實際中心線出入口 Rapier 射線取樣全通過，並完成動態剛體落地與資源回收測試。
- 本輪 Chromium 本機瀏覽器遭管理政策阻擋，3D 開車端到端測試與 Linux production build 未驗；真實建築、路權、高程及上下層立交橋留到後續版本。

---

# V1.9.1 — 臺南車站 Overture 真實道路資料管線與 3D 預覽（2026-10-22）

- 固定臺南車站 22.9972062216332°N, 120.212369589515°E 為城市區域中心，以局部公尺座標定義 2×2 km 方形邊界。
- 新增 Overture road segment/connector 官方資料匯入、保留 GERS IDs / connector references、嚴格局部範圍裁切及授權資訊。
- 新增獨立 Three.js 城市預覽及資料重新載入；舊程序化 v1/v2、PRND 和固定物理測試未修改。
- 新增無外網依賴的城市資料 QA 和官方 Overture CLI 下載腳本。
- 地理上真實的路口和真實道路碰撞延後至 V1.9.2；橋梁／地下道高度延後至 V1.9.4。
- **受執行環境網路限制，未能隨 ZIP 收錄台南車站實際 Overture 資料；僅交付匯入工具及預覽模組，實際地圖與 3D 結果仍待驗收。**

---

# SHIFT LAB v1.9.0 — 程序化道路生成器 v2（2026-10-22）

- 新增 `road-generator-v2.js`：完整髮夾彎折返路段、成對平滑彎道、獨立坡度控制及確定性的路線延伸。
- 空間網格檢查非相鄰道路取樣點的水平間距；加入坡度、曲率、取樣連續性與非有限值稽核，不讓失敗幾何進入新場景。
- 舊版 v1 生成器保持原始演算法，原有 v1 JSON／瀏覽器存檔維持原版地圖；新使用者預設 v2，可在統一設定中選回 v1。
- 新增 v2 種子大量回歸、增量延伸一致性、Chromium 原始物理頁面實測，以及玩家／測試地圖互相切換測試。
- 1,000 種子 × 96 路段幾何測試全通過；110 項 Python／Chromium 回歸（108 通過／2 跳過），Node 原有物理及 PRND 測試通過；正式 WebGL/Rapier 3D 驗收待完成。
- 車輛、手排、自排、PRND 與四輪動力學不做重新調校；3D 地形、優化場景串流及真實 Overture 圖資不屬於本版範圍。

---

# SHIFT LAB v1.8.9.3 — PRND 自排倒車與安全換檔（2026-10-22）

- 修復自排缺少倒車範圍及倒檔離合器無法接合的問題。
- 加入 P/R/N/D 選檔，P 採用四輪駐車制動的物理近似，N 保持脫開，D 繼續六速 AMT 自動升降檔。
- 換 R/P/D 須完全停穩且踩住煞車；在暫停的設定介面停穩時允許選擇。N 可於移動中使用。禁止 R/D/P 不安全跨向切換，原始同步器仍主導實際齒輪。
- 儀表盤 PRND 輕量操作、設定統一選項、鍵盤 P/R/N/F；手排 Shift + R、0～6 保留。
- 原四輪模型實測、10 組 Node 模組驗證、110 項 Python/Chromium 回歸（108 通過／2 跳過）；WebGL/Rapier 驗收待實機執行。

---

# SHIFT LAB v1.8.9.2 — 3D 物理整合穩定候選版（2026-10-21）

- **手排設定修復**：停車且處於手排時，設定畫面選檔由原始離合器斜率、同步器及 `requestGear` 完成；移動中不強制入檔，保留倒檔安全鎖定。
- **自排驗證**：新增四車型連續減速回一檔與既有油門／煞車／自排鍵盤隔離的回歸；保留 v1.8.9.1 的 AMT 物理方式。
- **車型統一**：將 2.2L 柴油車加入單頁設定。
- **道路生命週期**：清空並檢核舊 Rapier Collider 與 Three.js 道路資源；測試路障材質一併釋放；重建失敗嘗試回復原地圖。
- **數值安全**：每次物理步進檢查剛體姿態、速度、傳動與四輪數值；異常即明確報告 FAIL／停止駕駛並提供重載。
- **瀏覽器自動化**：更新舊測試進入單頁自由駕駛的方式；新增 `browser_v1892.py`，可執行真實 WebGL 五項驗收與 30 分鐘耐久測試。
- **測試結果**：Node 九組模組測試通過；103 項分段 Python／Chromium 回歸中 101 通過、2 跳過；實際 Three.js／Rapier WASM 建置及端到端驗收因 npm DNS 失敗仍待用戶本機完成。
- **架構保留**：原四輪 `physics.html`、程序化生成器與測試工況不重寫，仍維持原生網頁版本。

---

# SHIFT LAB v1.8.9.1 — 自排換檔修補（2026-10-21）

- **修正**：自排降檔不再僅看 `engine RPM < 1200` 加速條件，而根據輪速／各檔齒比推算工作轉速，結合制動、油門、回差與換檔冷卻判斷。
- **修正**：接近停車時直接回 1 檔、低轉速自動分離離合器避免熄火，維持原手排同步器和傳動物理。
- **隔離**：自排時忽略 `Shift`（手排離合器）、數字鍵／小鍵盤檔位、`R`，並停用手排檔位下拉選單；不再因更改下拉檔位偷偷切成手排。
- **保留**：手排模式完整的 Shift、1–6、0、R 換檔操作；單頁網頁、地圖、四輪力學、Rapier 碰撞和五項 QA 情境保持不變。
- **驗證**：Node 四車型獨立自排策略測試、Chromium 真鍵盤隔離測試，以及真實 SHIFT LAB 引擎加速／制動／再加速回歸；3D WASM 仍需用戶瀏覽器複驗。

---

# SHIFT LAB v1.8.9 · 程序化地圖與遊戲模式介面

- **新增**：全螢幕自由駕駛（速度／RPM／檔位 HUD）、集中設定與獨立 QA 測試抽屜。
- **新增**：沿用舊 seeded route generator 的 3D 隨機道路選單（種子／彎道／坡度／JSON／路線預覽）。
- **新增**：更換地圖即移除老道路網格及碰撞體，重新建立 Three.js／Rapier 所需場景與護欄。
- **新增**：固定 QA 路線與玩家隨機路線分離，測完自動還原玩家地圖。
- **新增**：路面柏油／路肩／草地外觀及低多邊形路邊植栽（視覺專用）。
- **保留**：v1.8.8 的四輪物理核心、底盤受力、ESC、鍵盤轉向、五項固定測試腳本；手機最佳化仍延後。
- **已測試**：92 項單元/Chromium 程式測試中 90 通過、2 跳過；真實 Rapier WASM／WebGL 待使用者複驗。

---

# v1.8.8 — 單頁桌面網頁駕駛 + 左右轉修正

- **修正**：3D 世界 +Z 車頭方向與 Three.js chase 視角的 X 軸水平投影不一致，致 A/D 及搖桿的畫面左右顛倒。只在 UI-to-core bridge 校正，不更動輪胎力、車身力矩和 Rapier 剛體。
- **整合**：玩家只需進入 3D 頁面；舊 2D 控制頁改為歷史測試資料與不可見計算引擎，合併車型／路況／ABS／TCS／ESC／駕駛輔助等控制。
- **網頁優先**：根目錄只提供單一 3D 導引；一鍵 Windows/Unix 本機啟動與正式靜態網頁發佈腳本。
- **可用性**：可收合監測、車型重置、控制設定記憶、QA 與玩家設定隔離。
- **驗證**：84 項回歸測試（82 pass、2 optional skip），且底層車輛求解器與 3D 碰撞程式與 v1.8.7.2 位元相同。
- **限制**：本環境沒有 npm registry 連線，尚無實際 v1.8.8 3D/WebGL WASM 重新驗收或 production dist build。

---

# v1.8.7.2 — Force lifecycle and stationary stability candidate

- Rapier forces and torques now reset per physics microstep and during scene teleports.
- 3-second stationary mock-dynamics regression: 1,440 successful force/torque clearing cycles.
- Added current-step external force/torque monitoring and force-lifecycle grading.
- Full suite stops on stationary failure, avoiding invalid high-speed results.
- Legacy wheel/transmission HTML unchanged; actual browser/Rapier WASM validation still pending.

---

## v1.8.7.1 (2026-10-21) — Desktop 3D hotfix (browser re-acceptance pending)

- Fix invalid `hit.toi` access: Rapier 0.18 `RayColliderHit` reports `timeOfImpact`; invalid/missing rays cannot produce silent NaN wheel normal forces.
- Track suspension ray hits, invalid load samples and time with wheel contacts in QA; tighten stationary/ramp gates.
- Test-only transverse barrier and ramp are now created only when the matching scenario is loaded; free drive is no longer blocked 34 m ahead.
- Add clear one-click free drive, canvas keyboard focus, paused-state recovery, quick assisted engine/clutch/gear option; retain full original manual driving mode and physics solver.
- Full inherited source/regression test suite passes with original optional authentic data skips, but real Rapier/WASM/WebGL acceptance must be run again on a desktop browser.

# SHIFT//LAB V1.8.6 — Desktop handling, roadway collision and experimental 3D bridge

- ESC intervenes on centered steering/undesired yaw; split-μ braking trim on high-adhesion side adds yaw control while preserving ABS wheel-lock pressure logic.
- 1.65 rad/s yaw hard ceiling removed; tire solver stays force/moment based even through low-longitudinal-speed spins; emergency numerical guard widened.
- Keyboard opposite-lock response improved and analog stick center hysteresis added; historical keyboard/gamepad calibration and manual shift workflow retained.
- Selectable post-peak tire recovery in balanced/sport/raw modes, without increasing the tire force peak or bypassing friction-combined-force caps.
- Original 2D Canvas simulator road barriers now use geometric rigid-body *planar impulse*, not speed/yaw multipliers.
- Optional `desktop3d/` Vite/Three/Rapier single-authority vehicle adapter with static road meshes, 3D guardrail colliders, four spring raycasts and Rapier CCD. **Experimental: runtime dependencies unavailable for local browser validation.**
- Desktop only. Phone UI, touch and mobile performance work deferred.
- 61 inherited+new software tests; 59 pass and 2 optional original MAT-data tests skip.

---

# SHIFT//LAB V1.8.5

- New gasoline combustion vehicle **BMW M235i** original CAN source analysis and structured holdout benchmark, compared with a simple baseline. The 0.10s-lag training-selected model **underperforms** the no-lag baseline on untouched BMW data.
- Confirmed independent Ford Fiesta Titanium IO-VNBD source has steering, engine rpm, gear, clutch and yaw but CSV files require Git LFS; no fabricated Ford fitting.
- Validated P1 six 500Hz source sessions' wheel-normal-load channels and found **0/6 runs passed** paired positive-load quality gate. No fitting from unverified Fy/Fz/Mz.
- V1.8.5 read-only in-game benchmark and developer-accessible source metadata; no drivetrain, tire, suspension, ESC, keyboard, gamepad or physics integrator changes.
- Reproducible Python tools, exact source hashes, licensing caveats, chart/QA updates.

## v1.8.7 (2026-10-21) — Desktop 3D collision acceptance beta

- Added real-3D-browser acceptance UI, static transverse barrier/ramp, deterministic collision presets, finite-state/impulse/penetration gates, full-suite button, CSV-free JSON export, and Playwright browser automation entrypoint.
- Fixed missing gamepad mapping dropdowns in v1.8.6 Three.js host, included run helpers, updated relative static asset paths.
- Zero changes to inherited four-wheel physics and standalone offline driver; v1.8.6 root `index.html` remains identical.
- All 71 source/regression tests complete: 69 pass, 2 original-data skips; actual Vite/Rapier WASM browser test is blocked by offline npm registry and remains pending.
