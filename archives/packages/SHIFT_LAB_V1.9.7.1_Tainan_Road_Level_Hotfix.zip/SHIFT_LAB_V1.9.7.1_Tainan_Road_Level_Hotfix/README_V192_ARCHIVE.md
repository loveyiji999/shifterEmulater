# SHIFT LAB V1.9.2 — 臺南火車站真實街道駕駛原型

基於 V1.9.1 已取得的 **Overture Maps 真實道路**，在台南火車站 2×2 km 區域建立可供 Three.js 觀看、Rapier 車輛實際接觸的道路表面和路口。本版仍是**網頁遊戲原型**，不是已完成實際高程、建築、交通規則或量產效能驗收的商用城鎮。

## Windows 啟動

1. 將壓縮檔解壓縮到新資料夾，不要直接從 ZIP 中雙擊 HTML。
2. 安裝 Node.js 22 或 20.19 以上，雙擊根目錄 `START_WEB_WINDOWS.cmd`。首次啟動會自動安裝 npm 套件；或自行執行：

   ```sh
   cd desktop3d
   npm install
   npm run dev
   ```

3. 用 Chrome／Edge 打開 **http://127.0.0.1:5173/**。程式載入內建真實台南道路 JSON 後，預設切入**台南真實道路駕駛**，不需要先重新下載地圖。可在 `Esc` 主選單改用程序化測試地圖，或切回台南。

Unix / macOS：在根目錄執行 `sh START_WEB_UNIX.sh`。正式發佈前在 `desktop3d/` 執行 `npm install && npm run build`，將完整 `dist/` 放在能提供 JS／WASM 與地圖 JSON 的靜態 HTTPS 站台即可；玩家不需安裝 Node.js。

## 駕駛控制

預設**自排 P 檔**：按住 `S` 煞車，再按 `F` 切 D 前進，放開煞車後按 `W` 油門；`A/D` 左右轉，`R` 倒車，`N` 空檔、`P` 駐車。D／R／P 切換需符合原安全檔位條件。`I` 啟動引擎（自排輔助也可自動發動）。在選單／設定選手排後，`Shift` 踩離合器、數字 `1–6` 排檔、`0` 空檔、`R` 倒檔。`M` 快速切換自排／手排，`Space` 暫停，`Backspace` 重置，`Esc` 選單，`F1` 設定，`F2` 固定物理測試。

**主選單**提供「開始駕駛台南真實街道」「使用程序化測試道路」「臺南車站 · 路網俯瞰」。同一輛車的原 Rapier 物理與變速箱模型跨地圖保留；城市路口不使用程序化道路的單一路徑強迫吸附。

## 本版包含的真實道路與物理幾何

- 地理中心：臺南火車站（22.9972062216332° N，120.212369589515° E），座標 x 朝東、z 朝北。
- 發行包**已內含** `desktop3d/public/data/tainan-station-roads.json`，其原始資料為 Overture Transportation `segment` / `connector`；車行道路 1,342 筆，其他行人道路 1,166 筆，軌道 9 筆。
- 道路沿 Overture 真的彎曲中心線建模，使用有效的 connector 建立路口連接；識別 962 個 T 字與 295 個四向路口，產生 30,168 個柏油三角面、291 個道路 trimesh 碰撞批次與 1 個越野緩衝地面。
- Render 與 collision 使用同一份路面頂點／三角面，支援在路口自然打方向轉彎。駕駛地圖會顯示 © OpenStreetMap contributors, Overture Maps Foundation / ODbL 署名。
- 資料仍是**平面道路**，橋與地下道尚未處理分層；路口面積、道路寬度是遊戲工程近似，不等同真實車道尺寸、路權或行車規則。

## 驗證指令與狀態

```sh
cd desktop3d
npm install
npm run qa:all
npm run qa:city:drive
npm run build
```

這次開發環境的**全部 Node QA 通過**，其中包括 1,257 個 T／十字路口的中心 Rapier 射線接觸與 35,098 個真實路口連接臂取樣。此執行環境的瀏覽器受政策限制，未完成真實 WebGL2 開車 E2E 測試；Linux 建置因既有 Windows-only node_modules 缺少平台 native binary 未能完成，應在 Windows 原生 `npm install` 後重跑。詳細見 `V192_QA.md`，不可據此聲稱全功能／效能完成。

## 文件與後續工作

- `V192_IMPLEMENTATION.md`：架構、碰撞及資料轉換、版本限制。
- `V192_QA.md`：可重現的 Node/Rapier 結果，以及瀏覽器手動驗收。
- `DATA_PROVENANCE.md`：官方資料與 ODbL 授權來源。
- `V191_IMPLEMENTATION.md`、`V191_QA.md`、`README_V191_ARCHIVE.md`：原 V1.9.1 導入階段的**歷史**文件；關於 ZIP 未附真實資料等舊敘述不適用於當前 V1.9.2。
- 下一階段優先處理真實建築／建築輪廓、道路高度／立交橋上下層，以及可擴充的 tile 串流和道路交通規則。

此專案發行包有原始 GeoJSON 和轉換後的可駕駛地圖；原始 Overture `source.release` 欄是當時的 `latest-via-STAC`，商業化前仍需重新固定 release、確認 ODbL 衍生資料庫分享義務及地圖資料來源授權。
