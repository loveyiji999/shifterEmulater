## V1.9.7.1 shared local Y reference (2026-10-22)

- The original Overture WGS84/XY road, connector and building footprint files are not changed.
- Local game terrain/building base Y=0 and ordinary paved road Y=+.025 m are **renderer/physics engineering datums only**; not geodetic elevations, DEM or observed road levels.
- Grade-separated `level_rules`, road transitions, inferred piers, ramp-side visual fill and retaining wall estimates are not surveyed and must not be published as such.

## V1.9.7 道路附屬結構的資料來源聲明

本版橋面邊梁、護欄、擋土壁、柱位、支座與反光件**均為程序化推估的遊戲模型**，只取用既有 Overture 道路中心線、寬度和 `level_rules` 相對層級；來源未提供各座橋墩 CAD/BIM、現場測繪高程或地下道施工圖。不要引用本版生成構件作為臺南真實道路設施清冊或工程位置。現有 Overture／OSM ODbL 署名與資料保留規則不變。

---

## V1.9.6 — Road-level provenance and uncertainty (2026-10-22)

- Official XY road geometry, original feature ID, connector links, class and width rules are unchanged from the included V1.9.5 source. The Overture GeoJSON originals were already in the uploaded ZIP; no fresh internet fetch or terrain DEM was used.
- The new `segment.sourceRange=[startFraction,endFraction]` is an **internally derived** fractional distance on the original, uncut segment centerline. It is needed so `level_rules.between` still addresses the original feature interval after cropping the 2×2km city square. It is not an Overture property and is not another source dataset.
- Overture `level_rules` express a relative vertical layer. There is no evidenced road-surface WGS84-Z/sea-level elevation or validated local DEM in this package. `LEVEL_HEIGHT_ESTIMATE_METERS=5.25`, `MAX_ESTIMATED_GRADE=0.075` and soil cut-outs are **simulator estimates**, not measured Tainan bridge/tunnel dimensions. Opposing signed ramps may produce a combined grade near 15%; QA flags the exact maximum.
- Below-grade cut-outs in the formerly solid placeholder soil exist to prevent false collision with the driving surface; the recovery floor is synthetic gameplay safety. Do not infer tunnel portals, flood depths, embankment geometry or actual overhead clearance from them.
- V1.9.5 flat geometry remains exactly available via `elevationMode:'flat'`; all source-provenance and ODbL duties remain unchanged. New derived 3D model is subject to attribution/license review before commercial redistribution.

## V1.9.5 addendum — QA Evidence

Underlying transportation segments/connectors and building source formats remain identical to V1.9.4. `sourceStartMeters` derives from the current local line distances and is not a new Overture field. Painted dashes, estimated curb returns, sidewalk panel suppression and junction risk thresholds are **engineered visualization/QA**, not measured map content. Wheel-track 1.56m is the simulator's nominal axle track proxy, not a guarantee for every selectable vehicle preset. Narrow 1.5m service roads are copied from source width rules; do not widen them to silence an automatic test. If original user buildings are missing, a report must explicitly say `buildingSource=null` and `buildingAudit=null`.

# External vehicle research data provenance — V1.8.5

| Evidence | Original published source | Recorded vehicle and format | Verified access | License / transfer decision |
|---|---|---|---|---|
| Gasoline lateral/acceleration data | https://github.com/cloudpose/smartphone_driving_dataset (`dataset1_car.csv`) | BMW M235i, original 2018-04-08 CAN, 4,708 rows, around 342 s; 11 columns | Raw file fully fetched via GitHub connector, Git blob SHA1 `9fb7b829265b9e94a09bbc188740dd7d350b0245`; derived metrics computed directly on source | No explicit data re-distribution license discovered; **do not redistribute 4708 raw rows**; observational proxy only |
| Conventional-car gearbox + vehicle dynamics | https://github.com/onyekpeu/IO-VNBD ; https://doi.org/10.1016/j.dib.2021.106885 | Ford Fiesta Titanium, ECU with 29 vehicle signals, 10Hz (published paper), CSV stored with Git LFS | Repo README/source schema and pointer checked. `V-Vta1a.csv` is an LFS pointer (sha256 object `9522a6f4...`, original 5,444,513 bytes). **Original bytes NOT fetched** | Academic open publication does not imply repository datasets can be bundled. Fuel/gearbox exact variant unverified; no derived Ford fit claimed |
| Full vehicle lateral/yaw runs | https://www.projects.bucknell.edu/Beal_Automotive/ | Bucknell P1 research EV, original `craig_2018-07-19_aa/ab/ac/ad/ai/ak.mat`, 500Hz | 6 originals in developer environment; SHA256 checked per `calibration/fit_p1_real_runs.py`. New wheel sensor gate read original `y` matrices | University download publicly accessible; no clear redistribution permission; raw sources absent from ZIP. P1 is NOT a production combustion vehicle. |
| Previous measured sensor checks | https://github.com/MB-Team-THI/UAHL-RevStED | ADMA/OBD sensor samples | Previously compared/retained in V1.8.3 reports | Do not treat same-sensor correspondence as full real vehicle model proof |

## Scientific levels of trust

- **Measured:** raw BMW CAN speed, steering angle, lateral acceleration, RPM and throttle; P1 500Hz original instrumented channels.
- **Derived from measured:** BMW surrogate model coefficients and holdout errors; P1 force-channel plausibility statistics. Not identical to independently measured vehicle sub-system constants.
- **Not measured / not verified:** steering-wheel ratio and tire forces for BMW; the exact gasoline/diesel/gearbox configuration in Ford; right-front P1 sensor calibration. No claim to identify full engine torque curves or lateral tire characteristics.
- **Unchanged:** the V1.8.4 full driving simulator's four-wheel integrator and default vehicle parameters.

## Rights

There is no source raw BMW/Ford/P1 vehicle data in the output ZIP. The code and derived aggregate result files have been authored for this project. For distribution in a commercial game, revisit any data-dependent model transfer and attribution requirements; obtain express source permissions for raw data reuse if necessary.


## V1.9.1 真實地理資料來源

- 城市中心點：文化部國家文化記憶庫「臺南火車站」，`https://tcmb.culture.tw/zh-tw/detail?id=19981218000001&indexCode=BOCH_CountryCulture_11`，(22.9972062216332°N, 120.212369589515°E)。
- 官方地理資料：Overture Maps Foundation `theme=transportation`, `type=segment` / `type=connector`；官方指南 `https://docs.overturemaps.org/guides/transportation/`；下載工具 `https://docs.overturemaps.org/getting-data/overturemaps-py/`。
- 道路來源與權利：Overture Transportation 主要由 OpenStreetMap 衍生、含其他權利來源，採 ODbL 1.0；展示署名 `© OpenStreetMap contributors, Overture Maps Foundation`，依 `https://docs.overturemaps.org/attribution/`。
- V1.9.1 建檔初期曾**未含實際 GeoJSON 或衍生地圖 JSON**；V1.9.2 的使用者提供 ZIP 已包含原始 GeoJSON 與編譯後台南道路 JSON。`desktop3d/scripts/fetch-tainan-overture.py` 在使用者環境執行後，實際 release 會寫入 `source.release`。不得將單元測試 fixture 視為台南地圖資料。

## V1.9.2 實際轉換資料的發布與授權

- 已將使用者上傳的官方原始 `desktop3d/overture_raw/tainan_segment.geojson`、`tainan_connector.geojson` 和轉換後的 `desktop3d/public/data/tainan-station-roads.json` 一起納入專案壓縮檔；不宣稱重新下載或新調查取得。
- 來源資料記錄 `source.provider="Overture Maps Foundation"`, `source.theme="transportation"`, `source.license="ODbL-1.0"`, `source.release="latest-via-STAC"`, `source.downloadedAt="2026-10-22T03:25:06.973Z"`。最後兩項來自**原始檔內容**，不是新的實地或官方版本驗證。
- ODbL 署名在台南城鎮俯瞰及台南駕駛畫面中顯示。正式商業發布仍需針對 ODbL 資料庫公開義務、其他覆蓋來源及固定的官方 release 識別完整審查。
- `V192_IMPLEMENTATION.md` 與 `V192_QA.md` 為本版實作與驗證邊界，**不能**將路口 collider 可落地等同真實路權或高程驗證。

## V1.9.3 新增 Overture Buildings 來源及缺檔界線

- 官方類型：`theme=buildings`, `type=building`，WGS84 GeoJSON，支援 Polygon/MultiPolygon，現有資訊欄包含 `height`, `num_floors`, `min_height`, `subtype`, `names`, `has_parts`。官方指南：<https://docs.overturemaps.org/guides/buildings/>；欄位定義：<https://docs.overturemaps.org/schema/reference/buildings/building/>。
- 官方 Python 下載 API：<https://docs.overturemaps.org/getting-data/overturemaps-py/>。本專案 `desktop3d/scripts/fetch-tainan-buildings.py` 使用官方 `record_batch_reader` 取得 2×2 公里資料，再產生 `overture_raw/tainan_building.geojson` 與 `public/data/tainan-station-buildings.json`。`source.release` 嘗試以 STAC `latest` 確認，失敗時明確保留 `latest-via-STAC` 未固定版本標示。
- `buildings` Overture 發布版本為 **ODbL-1.0**；包含 OpenStreetMap、Esri Community Maps、Microsoft Global ML Building Footprints、Google Open Buildings、東亞建物向量資料等多個來源，詳見 <https://docs.overturemaps.org/attribution/>。展示署名 `© OpenStreetMap contributors, Overture Maps Foundation`；正式商用仍須審查該授權義務、對應來源及地圖衍生資料庫公開條件。
- **本次執行環境沒有網路：未取得臺南真實 building 檔。ZIP 中沒有新的 Overture building 地圖，也沒有可用於遊玩之合成台南建築資料。** 測試用建築 fixture 僅在 `desktop3d/tests/validate-city-buildings-v193.mjs` 內，供幾何與 Rapier 回歸檢查，不得當成地理來源。
- 高度 `height` 是官方來源欄位，不能稱為現場量測；樓層與預設估高為專案演算法，必須明確區分。部分 ML 屋頂輪廓或地籍轉繪幾何與交通道路存在誤差；不得藉程序化位移當作校正過的真實位置。

## V1.9.3.1 建築下載來源紀錄補充

- 官方 `overturemaps.record_batch_reader('building')` + `get_writer('geojson')` 輸出可能省略每筆 feature 的 `theme`/`type`，因資料集本身已由 Overture 分區固定。只因這兩欄缺少而拒絕資料是 V1.9.3 的誤判。
- V1.9.3.1 成功下載後於 `desktop3d/overture_raw/tainan_building.source.json` 或暫存 `.download.source.json` 記錄 SHA256、下載時 STAC release、bbox 及取得管道。不能將此當成 Overture 提供的密碼學簽章：它是本地可追溯證據。
- 本次 ZIP 仍未附台南建築本體；只在使用者 Windows 電腦下載成功後產生 `tainan-station-buildings.json`。來源建築高度與工程推估的差別不變。

## V1.9.4 視覺道路細節與幾何診斷的來源界線

- 附帶的原始／衍生 Overture 道路資料和台南地理範圍 **沒有變更**。這次新增的 `city-street-details.mjs` 描繪線條、0.075 m 高路緣、1.12 m 寬的人行道都是專案工程估算，**不是** Overture 建議的真實車道劃設、路緣石或人行道配置；它們沒有獨立 Rapier 碰撞。
- 道路的 `width_rules` 在部分區段可能提供可用寬度值；其他區段是既有的 `approximateRoadWidth()` 類別估算。新增來源標記讓使用者可分開看。
- `city-street-audit.mjs` 以遊戲同一批道路實體曲面三角形與官方建築 Polygon 外環／內孔做二維相交分析。樓高、橋梁與高程沒有聯合驗證；列出的侵入個案僅是人工審核候選，不能據此擅自更動官方足跡或宣稱來源錯誤。
- 用於驗證的 4,985 棟**合成矩形壓力樣本**不代表、也沒有任何來自台南的建築位置，不得與使用者實際下載的 4,985 筆官方資料混淆；合成輸入未加入 ZIP 的地圖 JSON。
