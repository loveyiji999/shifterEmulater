# Overture 臺南火車站 2×2 km 真實資料

- `tainan-station-roads.json`: V1.9.6 依已內附的官方 transportation segment/connector 再轉換結果，格式仍是 `shiftlab.city.roads.v1`。保留完全相同的 ID、道路 XY、路幅與 connector；新增各裁切路段原始距離比例 `sourceRange` 供 `level_rules.between` 精確對位（**不是實際海拔**）。
- `tainan-station-buildings.json`: V1.9.3 新增的真實 building 轉換結果，格式 `shiftlab.city.buildings.v1`。**此 ZIP 未附檔案**；只能透過正式 Overture 下載腳本取得，或匯入官方資料，不能以合成輪廓冒充。

Windows：執行 `desktop3d/FETCH_TAINAN_BUILDINGS_WINDOWS.cmd`，下載時會建立原始 `overture_raw/tainan_building.geojson` 並產生瀏覽器精簡 JSON；完成後重新整理頁面。參見專案 `README.md`、`DATA_PROVENANCE.md`。

授權：ODbL 1.0。© OpenStreetMap contributors, Overture Maps Foundation。建築的 `height` 是**來源欄位**，不是獨立量測；`num_floors × 3.2 m` 與預設估高都不是真實高度。
