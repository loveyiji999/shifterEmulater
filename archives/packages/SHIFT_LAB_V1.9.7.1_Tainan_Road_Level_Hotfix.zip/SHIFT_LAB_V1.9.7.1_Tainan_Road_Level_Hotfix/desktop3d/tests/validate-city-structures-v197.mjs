// V1.9.7 offline geometry and regressions. No third-party imports.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {buildCityRoadGeometry} from '../src/city-road-geometry.mjs';
import {buildCityTerrainGeometry} from '../src/city-terrain-geometry.mjs';
import {buildCityRoadStructures} from '../src/city-road-structures.mjs';

const road=(id,coordinates,level=0)=>({id,sourceId:id,subtype:'road',use:'vehicle',
  roadClass:'secondary',name:id,widthMeters:8,widthRules:[],connectorRefs:[],
  sourceRange:[0,1],levelRules:level?[{value:level,between:null}]:[],coordinates});
const synthetic={segments:[
  road('bridge',[[-100,0],[120,0]],1),
  road('ground-below',[[-75,-50],[-75,50]]),
  road('underpass',[[270,0],[490,0]],-1),
  road('ground-above',[[370,-50],[370,50]])
],connectors:[]};
const model=buildCityRoadGeometry(synthetic),soil=buildCityTerrainGeometry(model);
const structures=buildCityRoadStructures(model,{terrain:soil}),stats=structures.stats;
assert.ok(stats.bridgeDeckMeters>170);
assert.ok(stats.guardrailMeters>300);
assert.ok(stats.retainingWallMeters>300);
assert.ok(stats.piers>0,'unobstructed bridge sections must get inferred supports');
assert.ok(stats.skippedPiersForRoad>0,'lower drivable crossing excludes bridge support');
assert.ok(stats.reflectors>0);
assert.ok(stats.collisionTiles>0);
assert.equal(stats.surveyedStructureLocations,false);
assert.deepEqual(structures.physicalKinds.sort(),['guardrail','pier','retainingWall'].sort());
let physical=0,decorative=0,triangles=0;
const fingerprint=createHash('sha256');
for(const tile of structures.tiles.values()){
  assert.ok(tile.indices.length>0);
  assert.equal(tile.vertices.length,tile.indices.length*3);
  assert.ok(tile.vertices.every(Number.isFinite));
  for(let i=0;i<tile.indices.length;i+=3){
    const a=tile.indices[i]*3,b=tile.indices[i+1]*3,c=tile.indices[i+2]*3;
    const ux=tile.vertices[b]-tile.vertices[a],uy=tile.vertices[b+1]-tile.vertices[a+1],uz=tile.vertices[b+2]-tile.vertices[a+2];
    const vx=tile.vertices[c]-tile.vertices[a],vy=tile.vertices[c+1]-tile.vertices[a+1],vz=tile.vertices[c+2]-tile.vertices[a+2];
    assert.ok(Math.hypot(uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx)>1e-7,'no degenerate physical faces');
  }
  if(tile.physical)physical++;else decorative++;
  triangles+=tile.indices.length/3;
  fingerprint.update(tile.key);fingerprint.update(JSON.stringify(tile.vertices));
  fingerprint.update(JSON.stringify(tile.indices));
}
assert.equal(stats.collisionTiles,physical);
assert.equal(stats.renderTiles,physical+decorative);
assert.equal(stats.renderTriangles,triangles);
assert.ok([...structures.tiles.values()].some(t=>t.kind==='deckUnderside'&&!t.physical));
// The piers and guardrails leave all original asphalt triangles untouched.
assert.equal(model.stats.triangles,buildCityRoadGeometry(synthetic).stats.triangles);
const allOfKind=k=>[...structures.tiles.values()].filter(t=>t.kind===k);
const rail=allOfKind('guardrail');
assert.ok(rail.length);
const guardNearCrossing=rail.some(t=>{
  for(let i=0;i<t.vertices.length;i+=3){
    const [x,y,z]=t.vertices.slice(i,i+3);
    if(Math.abs(x+75)<2.5 && Math.abs(z)>4 && Math.abs(z)<6 && y>5)return true;
  }
  return false;
});
assert.ok(guardNearCrossing,'grade-separated bridge rail must not disappear above a lower street');
const retaining=allOfKind('retainingWall');
assert.ok(retaining.length);
assert.ok(retaining.some(t=>t.vertices.some((x,i)=>i%3===0&&Math.abs(x-370)<3)),
  'retaining wall may remain below a separate above-grade crossing');
const supportTiles=allOfKind('pier');
for(const t of supportTiles){
  for(let i=0;i<t.vertices.length;i+=3){
    const x=t.vertices[i],y=t.vertices[i+1],z=t.vertices[i+2];
    assert.ok(y<model.corridors[0].heightAt(0)-.3,'pier ends below asphalt');
    assert.ok(Math.hypot(x+75,z)>3,'no pier intersecting ground crossing');
  }
}
// Importing real building footprints must suppress an estimated support.
const buildings={buildings:[{id:'known-footprint',polygons:[{outer:
  [[-37,-6],[-27,-6],[-27,6],[-37,6]],holes:[]}]}]};
const withBuildings=buildCityRoadStructures(model,{terrain:soil,buildingMap:buildings});
assert.ok(withBuildings.stats.skippedPiersForBuilding>0);
assert.ok(withBuildings.stats.piers<stats.piers);
// The flat compatibility path must not create fake structural elements.
const flat=buildCityRoadGeometry(synthetic,{elevationMode:'flat'});
const none=buildCityRoadStructures(flat,{terrain:buildCityTerrainGeometry(flat)});
assert.equal(none.tiles.size,0);
assert.equal(none.stats.collisionTiles,0);

const cityData=JSON.parse(readFileSync(new URL('../public/data/tainan-station-roads.json',import.meta.url),'utf8'));
const cityRoad=buildCityRoadGeometry(cityData),citySoil=buildCityTerrainGeometry(cityRoad);
const actual=buildCityRoadStructures(cityRoad,{terrain:citySoil});
assert.equal(cityRoad.stats.corridors,3196);
assert.ok(cityRoad.stats.triangles>=33610,'V1971 adds ramp tessellation without removing drivable roads');
assert.ok(actual.stats.piers>0);
assert.ok(actual.stats.bridgeDeckMeters>2000);
assert.ok(actual.stats.guardrailMeters>3000);
assert.ok(actual.stats.retainingWallMeters>3000);
assert.ok(actual.stats.collisionTiles>15);
assert.ok(actual.stats.renderTriangles>50000);
assert.ok(actual.stats.skippedBarrierPanels>0,
  'some overlapping road-edge positions should be prudently avoided');
// Check every real-world structure triangle: no nonfinite vertices / tiny
// fragments, and no rail/wall surface passing through a live road centre.
let checkedRealTriangles=0,nearAsphaltCentre=0;
for(const tile of actual.tiles.values()){
  assert.equal(tile.vertices.length,tile.indices.length*3);
  assert.ok(tile.vertices.every(Number.isFinite));
  for(let i=0;i<tile.indices.length;i+=3){
    const ids=tile.indices.slice(i,i+3);
    assert.ok(ids.every(k=>k>=0&&k*3+2<tile.vertices.length));
    const [a,b,c]=ids.map(k=>tile.vertices.slice(k*3,k*3+3));
    const u=b.map((x,j)=>x-a[j]),v=c.map((x,j)=>x-a[j]);
    assert.ok(Math.hypot(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])>1e-7);
    if(!['guardrail','retainingWall'].includes(tile.kind))continue;
    const xyz=[(a[0]+b[0]+c[0])/3,(a[1]+b[1]+c[1])/3,(a[2]+b[2]+c[2])/3];
    const nearest=cityRoad.closestRoad(xyz[0],xyz[2],30,xyz[1]);
    if(nearest&&nearest.distance<Math.min(1,nearest.widthMeters*.5-.4) &&
      Math.abs(xyz[1]-nearest.y)<.1)nearAsphaltCentre++;
    checkedRealTriangles++;
  }
}
assert.equal(nearAsphaltCentre,0,'no structural collision surface on the actual road centre/height');
assert.ok(checkedRealTriangles>20000);

// Determinism, required to reproduce bad placements from a QA export.
const again=buildCityRoadStructures(cityRoad,{terrain:citySoil});
assert.deepEqual(again.stats,actual.stats);
assert.deepEqual([...again.tiles.keys()],[...actual.tiles.keys()]);
console.log(`PASS V1.9.7 structural geometry: Tainan bridge fascia ${actual.stats.bridgeDeckMeters.toFixed(0)}m, `+
  `physical guardrails ${actual.stats.guardrailMeters.toFixed(0)}m, `+
  `retaining walls ${actual.stats.retainingWallMeters.toFixed(0)}m, `+
  `${actual.stats.piers} inferred piers, ${actual.stats.collisionTiles} collider tiles, `+
  `${actual.stats.renderTriangles} rendered triangles. `+
  `Stacked road crossing, pier/building exclusion, flat mode, finite meshes and repeatability passed. `+
  `Fixture SHA256: ${fingerprint.digest('hex').slice(0,16)}.`);
