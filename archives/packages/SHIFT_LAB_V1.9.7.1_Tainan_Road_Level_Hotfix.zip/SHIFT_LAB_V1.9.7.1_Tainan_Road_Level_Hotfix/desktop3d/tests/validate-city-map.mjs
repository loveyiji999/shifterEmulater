import assert from 'node:assert/strict';
import {mkdtempSync, writeFileSync, readFileSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {
  TAINAN_STATION, areaBounds, longitudeLatitudeToMeters, metersToLongitudeLatitude,
  clipLineToSquare, clipPolylineToSquare, prepareOvertureCityMap,
  validateCityMap, cityStatistics, CITY_MAP_FORMAT
} from '../src/city-geo.mjs';

const near=(a,b,tol=0.015)=>assert.ok(Math.abs(a-b)<tol,`${a} vs ${b}`);
const bounds=areaBounds();
for(const [position,expected] of [
  [[bounds.west,TAINAN_STATION.latitude],[-1000,0]],
  [[bounds.east,TAINAN_STATION.latitude],[1000,0]],
  [[TAINAN_STATION.longitude,bounds.south],[0,-1000]],
  [[TAINAN_STATION.longitude,bounds.north],[0,1000]]]){
  const found=longitudeLatitudeToMeters(position);
  near(found[0],expected[0]);near(found[1],expected[1]);
  const round=metersToLongitudeLatitude(found);
  near(round[0],position[0],1e-9);near(round[1],position[1],1e-9);
}
assert.deepEqual(longitudeLatitudeToMeters([TAINAN_STATION.longitude,TAINAN_STATION.latitude]),[0,0]);
assert.equal(clipLineToSquare([1200,100],[2200,200]),null);
assert.deepEqual(clipLineToSquare([-1100,0],[1100,0]),[[-1000,0],[1000,0]]);
assert.deepEqual(clipPolylineToSquare([[-1200,50],[-600,50],[600,50],[1200,50]]),
  [[[-1000,50],[-600,50],[600,50],[1000,50]]]);

const points=(array)=>array.map(xz=>metersToLongitudeLatitude(xz));
const segmentFeature=(id,coords,refId)=>({type:'Feature',geometry:{type:'LineString',coordinates:points(coords)},
  properties:{id,theme:'transportation',type:'segment',subtype:'road',class:'residential',
    names:{primary:'Regression Fixture / NOT REAL TAINAN'},
    connectors:[{connector_id:refId,at:0.5}]}});
const connectorFeature=id=>({type:'Feature',geometry:{type:'Point',coordinates:metersToLongitudeLatitude([0,0])},
  properties:{id,theme:'transportation',type:'connector'}});
const line1=segmentFeature('test-segment-a',[[-1400,0],[0,0],[1400,0]],'test-connector-a');
const line2=segmentFeature('test-segment-b',[[0,-1300],[0,1300]],'test-connector-b');
const rawSegments={type:'FeatureCollection',features:[line1,line2]};
const rawConnectors={type:'FeatureCollection',features:[connectorFeature('test-connector-a')]};
const map=prepareOvertureCityMap(rawSegments,rawConnectors,{release:'TEST-FIXTURE'});
assert.equal(map.format,CITY_MAP_FORMAT);
assert.equal(map.segments.length,2);
assert.equal(map.connectors.length,1);
assert.equal(map.source.license,'ODbL-1.0');
assert.equal(map.source.release,'TEST-FIXTURE');
assert.equal(cityStatistics(map).vehicular,2);
assert.ok(map.segments[0].coordinates.every(p=>Math.abs(p[0])<=1000&&Math.abs(p[1])<=1000));
// Geometric crossing is NOT a routable intersection. Preserve Overture ref IDs.
assert.deepEqual(map.segments[0].connectorRefs,[{id:'test-connector-a',at:0.5}]);
assert.deepEqual(map.segments[1].connectorRefs,[{id:'test-connector-b',at:0.5}]);
assert.ok(!map.connectors.some(c=>c.id==='test-connector-b'));
// Official GeoJSON writers may expose GERS IDs at top-level Feature.id.
const alternateLine={...line1,id:'envelope-segment',properties:{...line1.properties,id:undefined}};
const alternateConnector={...connectorFeature('envelope-connector'),id:'envelope-connector',
  properties:{theme:'transportation',type:'connector'}};
const alternate=prepareOvertureCityMap({type:'FeatureCollection',features:[alternateLine]},
  {type:'FeatureCollection',features:[alternateConnector]});
assert.equal(alternate.segments[0].sourceId,'envelope-segment');
assert.equal(alternate.connectors[0].id,'envelope-connector');

assert.throws(()=>prepareOvertureCityMap({type:'FeatureCollection',features:[{
  ...line1,properties:{...line1.properties,theme:'not-overture'}}]},rawConnectors),/非 Overture/);
assert.throws(()=>validateCityMap({...map,area:{...map.area,longitude:121}}),/臺南/);
assert.throws(()=>validateCityMap({...map,source:{}}),/授權/);
assert.throws(()=>validateCityMap({...map,segments:map.segments.map((s,i)=>i?{...s,coordinates:[[1002,0],[0,1]]}:s)}),/裁切/);
assert.throws(()=>prepareOvertureCityMap({type:'FeatureCollection',features:[]},rawConnectors),/車行道路/);

const tmp=mkdtempSync(join(tmpdir(),'shiftlab-v191-'));
try{
  const a=join(tmp,'segments.geojson'),b=join(tmp,'connectors.geojson'),out=join(tmp,'output.json');
  writeFileSync(a,JSON.stringify(rawSegments));writeFileSync(b,JSON.stringify(rawConnectors));
  const command=spawnSync(process.execPath,['scripts/prepare-tainan-overture.mjs',a,b,
    '--release=TEST-FIXTURE','--output='+out],{cwd:new URL('../',import.meta.url).pathname,encoding:'utf8'});
  assert.equal(command.status,0,command.stdout+command.stderr);
  const exported=validateCityMap(JSON.parse(readFileSync(out,'utf8')));
  assert.equal(exported.source.release,'TEST-FIXTURE');
  assert.equal(exported.segments.length,2);
}finally{rmSync(tmp,{recursive:true,force:true});}
console.log('PASS v1.9.1 Tainan WGS84 projection / exact 2x2km clip / Overture topology / provenance / JSON compiler');
