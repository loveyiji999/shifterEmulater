// Pure Node geometry QA: synthetic buildings are never bundled in game data.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {buildCityRoadGeometry,CITY_ROAD_Y} from '../src/city-road-geometry.mjs';
import {buildCityStreetDetails,metricScaleGeometry} from '../src/city-street-details.mjs';
import {buildCityStreetAudit,auditCityRoadCoverage,polygonRoadOverlapMeters2} from '../src/city-street-audit.mjs';

const segment=(id,a,b,widthMeters=8)=>({id,sourceId:id,name:id,
  subtype:'road',use:'vehicle',roadClass:'secondary',widthMeters,
  connectorRefs:[],widthRules:[],coordinates:[a,b]});
const simple=buildCityRoadGeometry({segments:[segment('east',[-12,0],[12,0])],connectors:[]});
const visual=buildCityStreetDetails(simple);
assert.ok(visual.stats.visualTriangles>0);
assert.ok(visual.stats.estimatedSidewalkCorridors===1);
assert.ok(visual.stats.paintedCenterMeters>0);
assert.equal(visual.stats.corridorsWithEstimatedWidth,1);
for(const [type,batch] of Object.entries(visual.groups)){
  assert.equal(batch.vertices.length,batch.triangles*9,`invalid triangle layout: ${type}`);
  assert.ok(batch.vertices.every(Number.isFinite),`nonfinite positions: ${type}`);
}
const marker=metricScaleGeometry(15,40);
assert.equal(marker.vertices.length,126); // 42 vertices x 3 values
assert.equal(marker.lengthMeters,10);
assert.equal(Math.hypot(marker.vertices[0]-marker.vertices[3],marker.vertices[2]-marker.vertices[5]),1);
const rectangle=(minX,minZ,maxX,maxZ)=>[[minX,minZ],[maxX,minZ],[maxX,maxZ],[minX,maxZ]];
const building=(id,outer,holes=[],baseMeters=0)=>({id,baseMeters,heightMeters:10,heightSource:'estimated',
  polygons:[{outer,holes}]});
const overlap=building('occupies-asphalt',rectangle(-4,-4,4,4));
const external=building('away-from-road',rectangle(-5,22,5,25));
const hole=building('courtyard-road',rectangle(-20,-20,20,20),[rectangle(-15,-15,15,15)]);
const result=buildCityStreetAudit(simple,{buildings:[overlap,external]}, {overlapThreshold:.2});
assert.equal(result.stats.buildingsChecked,2);
assert.equal(result.stats.overlappingBuildings,1);
assert.equal(result.issues[0].id,overlap.id);
assert.ok(result.issues[0].maxTriangleOverlapSqm>0);
const insideHole=buildCityStreetAudit(simple,{buildings:[hole]});
assert.equal(insideHole.stats.overlappingBuildings,0,'open courtyard should not flag asphalt beneath hole');
assert.ok(Math.abs(polygonRoadOverlapMeters2(
  {outer:rectangle(-10,-10,10,10),holes:[rectangle(-5,-5,5,5)]},
  [[-3,-3],[3,-3],[0,3]]))<.001,'hole subtracts intersection area');
const lifted=buildCityStreetAudit(simple,{buildings:[building('elevated',rectangle(-4,-4,4,4),[],4)]});
assert.equal(lifted.issues[0].isElevated,true,'elevated footprint reported as uncertain, not repaired');
const real=JSON.parse(readFileSync(new URL('../public/data/tainan-station-roads.json',import.meta.url),'utf8'));
const cityModel=buildCityRoadGeometry(real);
const cityDetails=buildCityStreetDetails(cityModel);
const coverage=auditCityRoadCoverage(cityModel);
assert.ok(coverage.samples>35000);
assert.equal(coverage.missesCount,0,'all sampled real T/cross connector centreline points must be on asphalt');
assert.equal(cityModel.stats.tJunctions,962);
assert.equal(cityModel.stats.crossJunctions,295);
assert.ok(cityDetails.stats.visualTriangles>15000);
assert.equal(cityDetails.stats.corridorsWithSourceWidth+cityDetails.stats.corridorsWithEstimatedWidth,cityModel.corridors.length);
for(const group of Object.values(cityDetails.groups)){
  assert.equal(group.vertices.length,group.triangles*9);
  assert.ok(group.vertices.every(Number.isFinite));
}
console.log(`PASS V1.9.4 metric street visual and overlap audit; real Tainan ${cityModel.corridors.length} corridors, ${cityDetails.stats.visualTriangles} visual triangles, ${coverage.samples} collision-centreline samples, source-width corridors ${cityDetails.stats.corridorsWithSourceWidth}; synthetic overlap/hole/scale accepted`);
