// V1.9.7.1 regression: grounded at-grade datum, physical 3D junction seams,
// slope-limited landings, below-grade terrain, no bridge/underpass flattening.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {buildCityRoadGeometry,atDistance,CITY_ROAD_Y} from '../src/city-road-geometry.mjs';
import {CITY_GROUND_Y} from '../src/city-vertical-datum.mjs';
import {buildCityTerrainGeometry} from '../src/city-terrain-geometry.mjs';
import {buildCityRoadStructures} from '../src/city-road-structures.mjs';
import {buildingHeight} from '../src/city-buildings-geo.mjs';
import {MAX_ESTIMATED_GRADE,LEVEL_HEIGHT_ESTIMATE_METERS} from '../src/city-road-elevation.mjs';

const close=(a,b,t=.00001)=>assert.ok(Math.abs(a-b)<=t,`${a} !== ${b} (limit ${t})`);
assert.equal(CITY_GROUND_Y,0);
assert.ok(CITY_ROAD_Y>0 && CITY_ROAD_Y-CITY_GROUND_Y<=.03,
  'at-grade road must be visually level with Overture building bases');
assert.equal(buildingHeight({}).baseMeters,CITY_GROUND_Y);
const segment=(id,coordinates,rules=[],refs=[])=>({id,sourceId:id,subtype:'road',
  use:'vehicle',roadClass:'secondary',widthMeters:8,widthRules:[],name:id,
  connectorRefs:refs,sourceRange:[0,1],levelRules:rules,coordinates});

// An actual three-arm connector forces one physical height on all incoming
// cap edges, rather than relying on the convex hull to contain cap corners.
const junctionMap={segments:[
  segment('deck',[[-100,0],[0,0]],[{value:1,between:[0,.95]}],[{id:'hub',at:1}]),
  segment('east',[[0,0],[110,0]],[],[{id:'hub',at:0}]),
  segment('north',[[0,0],[0,90]],[],[{id:'hub',at:0}])
],connectors:[{id:'hub',coordinates:[0,0]}]};
const local=buildCityRoadGeometry(junctionMap),hub=local.junctions.find(j=>j.id==='hub');
assert.ok(hub&&hub.degree===3);
for(const arm of hub.node.arms){
  const e=arm.edge,cap=e.caps[arm.fromStart?0:1];
  close(e.heightAt(arm.fromStart?0:e.length),hub.height);
  close(cap.height,hub.height);
  close(e.heightAt(arm.fromStart?e.trims[0]:e.length-e.trims[1]),hub.height);
}
assert.ok(local.stats.levelJunctionCaps);
const deck=local.corridors.find(e=>e.sourceId==='deck');
assert.ok(deck.heightAt(0)>CITY_GROUND_Y+LEVEL_HEIGHT_ESTIMATE_METERS*.5);
// The original source-levels are untouched when roads have no shared node.
const isolated=buildCityRoadGeometry({segments:[
  segment('over',[[-100,0],[100,0]],[{value:1,between:null}]),
  segment('under',[[0,-100],[0,100]])],connectors:[]});
const over=isolated.corridors.find(e=>e.sourceId==='over');
const under=isolated.corridors.find(e=>e.sourceId==='under');
close(over.heightAt(over.length/2)-under.heightAt(under.length/2),LEVEL_HEIGHT_ESTIMATE_METERS);

const cityData=JSON.parse(readFileSync(new URL('../public/data/tainan-station-roads.json',import.meta.url),'utf8'));
const city=buildCityRoadGeometry(cityData),soil=buildCityTerrainGeometry(city);
assert.equal(city.stats.corridors,3196);
assert.equal(city.stats.junctions,2094);
assert.equal(city.stats.levelJunctionCaps,true);
assert.equal(city.stats.sourceHeightSurveyed,false);
assert.equal(soil.groundY,CITY_GROUND_Y);
assert.ok(city.stats.minimumOffsetMeters<-4 && city.stats.maximumOffsetMeters>5);
assert.ok(city.stats.measuredMaxGrade<=MAX_ESTIMATED_GRADE*2+.001);
let seams=0,missingCapPoints=0,maxCapMismatch=0,atGrade=0;
for(const j of city.junctions){
  for(const arm of j.node.arms){
    const e=arm.edge,cap=e.caps[arm.fromStart?0:1];
    const nodeHeight=e.heightAt(arm.fromStart?0:e.length);
    const capS=arm.fromStart?e.trims[0]:e.length-e.trims[1];
    maxCapMismatch=Math.max(maxCapMismatch,Math.abs(j.height-nodeHeight),
      Math.abs(j.height-cap.height),Math.abs(e.heightAt(capS)-cap.height));
    for(const p of [cap.left,cap.right])if(j.polygon&&
      !j.polygon.some(q=>Math.hypot(p[0]-q[0],p[1]-q[1])<.0001)){
      missingCapPoints++;
      // Missing 2D hull vertices are now strictly level with the fan surface.
      close(cap.height,j.height,.00002);
    }
    seams++;
  }
}
assert.ok(seams>4000 && missingCapPoints>100);
assert.ok(maxCapMismatch<.00002,'all road/hull connector joins must share the same physical Y');
let maxGrade=0,underground=0,misses=0;
for(const e of city.corridors){
  const samples=Math.max(2,Math.ceil(e.length/.8));
  let prev=e.heightAt(0);
  for(let i=1;i<=samples;i++){
    const s=e.length*i/samples,y=e.heightAt(s);
    maxGrade=Math.max(maxGrade,Math.abs(y-prev)*samples/e.length);
    prev=y;
  }
  const cutSamples=Math.max(1,Math.ceil(e.length/4));
  for(let i=0;i<=cutSamples;i++){
    const s=e.length*i/cutSamples,y=e.heightAt(s);
    if(y>=CITY_GROUND_Y+(CITY_ROAD_Y-CITY_GROUND_Y)*.5)continue;
    const p=atDistance(e.line,s);
    // Border samples exactly x/z=+1000 are outside the terrain grid.
    if(Math.abs(p[0])>=999.999||Math.abs(p[1])>=999.999)continue;
    underground++;
    if(!soil.cutAt(...p))misses++;
  }
}
assert.ok(maxGrade<=MAX_ESTIMATED_GRADE*2+.002,
  `junction landings must not introduce a new steep ramp (grade ${maxGrade})`);
assert.ok(underground>500&&misses===0);
// Ensure terrain is NOT erroneously excavated around ordinary at-grade roads.
const normal=city.corridors.find(e=>Math.abs(e.heightOffsetAt(e.length*.5))<1e-8 &&
  Math.hypot(...atDistance(e.line,e.length*.5))<400 && e.length>30 &&
  !soil.cutAt(...atDistance(e.line,e.length*.5)));
assert.ok(normal,'ordinary roads retain a shared, continuous ground plane');
const structures=buildCityRoadStructures(city,{terrain:soil});
const fills=[...structures.tiles.values()].filter(t=>t.kind==='approachFill');
assert.ok(structures.stats.approachFillMeters>100&&fills.length>0,
  'small inferred ramps need supported side geometry, not floating asphalt');
assert.ok(fills.every(t=>!t.physical), 'fill is visual-only and must not block wheels');
assert.ok(structures.stats.guardrailMeters>2000&&structures.stats.retainingWallMeters>2000);
assert.ok([...structures.tiles.values()].some(t=>t.kind==='guardrail'&&t.physical));
const level=buildCityRoadGeometry(cityData,{elevationMode:'flat'});
assert.equal(buildCityRoadStructures(level,{terrain:buildCityTerrainGeometry(level)}).tiles.size,0);
assert.ok(level.corridors.every(e=>Math.abs(e.heightAt(0)-CITY_ROAD_Y)<1e-8));
console.log(`PASS V1.9.7.1: ground/building datum Y=${CITY_GROUND_Y}; asphalt Y=${CITY_ROAD_Y}; `+
  `${seams} exact road-junction cap joins (${missingCapPoints} omitted 2D hull corners now height-correct), `+
  `maximum join height error ${maxCapMismatch.toExponential(2)}m, worst grade ${(maxGrade*100).toFixed(2)}%; `+
  `${underground} underground samples without ground blockers; `+
  `${structures.stats.approachFillMeters.toFixed(1)}m grounded ramp-side fill; `+
  `XY network unchanged and graded bridge/underpass levels retained.`);
