// Official-writer-shaped synthetic fixtures only: no fake Tainan buildings
// should ever be published to the game's bundled data/ folder by this QA.
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,existsSync,copyFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {metersToLongitudeLatitude} from '../src/city-geo.mjs';
import {prepareOvertureBuildingMap} from '../src/city-buildings-geo.mjs';

const base=resolve(fileURLToPath(new URL('..',import.meta.url)));
// Python 3.13 on Windows normally exposes `py` or `python`, not `python3`.
const pythonCommands=process.platform==='win32'?['py','python','python3']:['python3','python'];
const python=pythonCommands.find(cmd=>spawnSync(cmd,['--version'],{encoding:'utf8'}).status===0);
if(!python)throw Error('此 QA 需要 Python 3；請改用 node 轉檔測試');
const testDir=mkdtempSync(join(tmpdir(),'shiftlab-v1931-'));
const quad=(x,z)=>{const points=[[x,z],[x+5,z],[x+5,z+6],[x,z+6],[x,z]];
  return points.map(p=>metersToLongitudeLatitude(p));};
const features=Array.from({length:4985},(_,i)=>{
  const x=-960+(i%86)*22,z=-945+Math.floor(i/86)*32;
  const id=`deadbeef-${String(i).padStart(4,'0')}-4000-8000-${String(i).padStart(12,'0')}`;
  return {type:'Feature',id,geometry:{type:'Polygon',coordinates:[quad(x,z)]},
    properties:{version:1,sources:[{dataset:'OpenStreetMap'}],has_parts:false,num_floors:3}};
});
const writerOutput={type:'FeatureCollection',features};
const good=prepareOvertureBuildingMap(writerOutput,{release:'2026-10-21.0'});
assert.equal(good.buildings.length,4985);
assert.equal(good.source.theme,'buildings');
try{
  mkdirSync(join(testDir,'scripts'),{recursive:true});
  mkdirSync(join(testDir,'src'),{recursive:true});
  mkdirSync(join(testDir,'overture_raw'),{recursive:true});
  for(const name of ['city-geo.mjs','city-buildings-geo.mjs'])
    copyFileSync(join(base,'src',name),join(testDir,'src',name));
  copyFileSync(join(base,'scripts','prepare-tainan-buildings.mjs'),join(testDir,'scripts','prepare-tainan-buildings.mjs'));
  copyFileSync(join(base,'scripts','fetch-tainan-buildings.py'),join(testDir,'scripts','fetch-tainan-buildings.py'));
  writeFileSync(join(testDir,'overture_raw','tainan_building.geojson.download'),JSON.stringify(writerOutput));
  const retry=spawnSync(python,[join(testDir,'scripts','fetch-tainan-buildings.py'),'--reconvert-only'],{encoding:'utf8'});
  assert.equal(retry.status,0,`offline retry should work, got:\n${retry.stdout}\n${retry.stderr}`);
  const published=join(testDir,'public','data','tainan-station-buildings.json');
  const raw=join(testDir,'overture_raw','tainan_building.geojson');
  assert.ok(existsSync(raw),'downloaded raw GeoJSON must be retained on success');
  assert.equal(JSON.parse(readFileSync(published,'utf8')).buildings.length,4985);
  assert.equal(JSON.parse(readFileSync(published,'utf8')).source.release,'unknown-cached-release');
  // After an official SDK fetch, the persisted checksum must recover release
  // metadata without consulting the network during the offline retry.
  const sha=createHash('sha256').update(readFileSync(raw)).digest('hex');
  writeFileSync(join(testDir,'overture_raw','tainan_building.source.json'),JSON.stringify({
    fetchApi:"overturemaps.record_batch_reader('building', bbox=BBOX)",sha256:sha,release:'2026-10-21.0'}));
  const rechecked=spawnSync(python,[join(testDir,'scripts','fetch-tainan-buildings.py'),'--reconvert-only'],{encoding:'utf8'});
  assert.equal(rechecked.status,0,`checksum-backed cache should convert: ${rechecked.stderr}`);
  assert.equal(JSON.parse(readFileSync(published,'utf8')).source.release,'2026-10-21.0');
  // A bad raw input must never replace an existing valid output.
  const before=readFileSync(published,'utf8');
  writeFileSync(join(testDir,'overture_raw','tainan_building.geojson.download'),
    JSON.stringify({type:'FeatureCollection',features:[{...features[0],properties:{version:1,theme:'transportation'}}]}));
  const fail=spawnSync(python,[join(testDir,'scripts','fetch-tainan-buildings.py'),'--reconvert-only'],{encoding:'utf8'});
  assert.notEqual(fail.status,0,'mislabelled dataset must still be rejected');
  assert.ok(existsSync(join(testDir,'overture_raw','tainan_building.geojson.download')),
    'failed conversion must retain downloaded file for retry');
  assert.equal(readFileSync(published,'utf8'),before,'failed conversion must keep the last good buildings');
  // If neither cache exists, offline retry must not access network or fabricate buildings.
  rmSync(join(testDir,'overture_raw','tainan_building.geojson.download'));
  rmSync(raw);
  const none=spawnSync(python,[join(testDir,'scripts','fetch-tainan-buildings.py'),'--reconvert-only'],{encoding:'utf8'});
  assert.notEqual(none.status,0,'empty cache must yield explicit failure');
  assert.equal(readFileSync(published,'utf8'),before,'empty cache must not clear last valid output');
  console.log('PASS v1.9.3.1: 4,985 synthetic SDK-style features, offline retry, raw preservation, data integrity on conversion failure');
}finally{
  rmSync(testDir,{force:true,recursive:true});
}
