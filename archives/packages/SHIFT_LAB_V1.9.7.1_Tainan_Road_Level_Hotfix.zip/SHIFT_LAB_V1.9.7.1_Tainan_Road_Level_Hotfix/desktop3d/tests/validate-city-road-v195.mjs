// V1.9.5: real Tainan road geometry regression + synthetic-only focused cases.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {buildCityRoadGeometry,CITY_ROAD_Y} from '../src/city-road-geometry.mjs';
import {buildCityStreetDetails} from '../src/city-street-details.mjs';
import {assessCityJunctionQuality,auditCityWheelTrackSupport} from '../src/city-junction-quality.mjs';
import {auditCityRoadCoverage,polygonRoadOverlapMeters2,createRoadTriangleIndex,pointOnAsphalt,
  buildCityStreetAudit} from '../src/city-street-audit.mjs';

const data=JSON.parse(readFileSync(new URL('../public/data/tainan-station-roads.json',import.meta.url),'utf8'));
// The legacy v1.9.5 regression is explicitly flat. V1.9.6 adds optional
// source-level geometry while retaining identical base XY / flat buffers.
const model=buildCityRoadGeometry(data,{elevationMode:'flat'}),appearance=buildCityStreetDetails(model);
const quality=assessCityJunctionQuality(model),wheel=auditCityWheelTrackSupport(model);
const centre=auditCityRoadCoverage(model),hash=createHash('sha256');
for(const tile of model.tiles.values()){
  // Historical baseline uses Y=.16. Validate that ALL XY and triangle indices
  // remain bit-identical, while the intentionally corrected shared local
  // vertical datum is allowed to change from .16 to CITY_ROAD_Y.
  const historicalVertices=tile.vertices.map((v,i)=>i%3===1 ? .16 : v);
  assert.ok(tile.vertices.every((v,i)=>i%3!==1 || v===CITY_ROAD_Y));
  hash.update(tile.key);hash.update(JSON.stringify(historicalVertices));hash.update(JSON.stringify(tile.indices));
}
assert.equal(hash.digest('hex'),'691b7c36f5fff9ca51ac7fa4189702f6036d7fc11ac6e56296d210fbe39bbd91',
  'V1.9.4 asphalt XY and triangle indices must remain identical after datum normalization');
assert.equal(model.stats.corridors,3196);
assert.equal(model.stats.tJunctions,962);
assert.equal(model.stats.crossJunctions,295);
assert.equal(centre.missesCount,0);
assert.ok(wheel.samples>39000);
assert.equal(wheel.missesCount,0,'all passable wheel-centre trajectories must intersect asphalt');
assert.equal(wheel.narrowCorridors.length,2,'two 1.5 m source-width service roads must be flagged separately');
assert.ok(wheel.narrowCorridors.every(c=>c.widthMeters===1.5&&c.widthEvidence==='source-rule'));
assert.equal(quality.stats.junctionsChecked,model.stats.junctions);
assert.ok(quality.stats.reviewJunctions>0);
assert.equal(quality.issues.length,500,'top review locations capped for browser export');
assert.ok(quality.issues[0].reasons.length>0);
assert.ok(appearance.stats.junctionCornerPanels>0);
assert.ok(appearance.stats.suppressedSidewalkPanels>0);
assert.ok(appearance.stats.suppressedCornerPanels>0);
assert.equal(appearance.stats.phaseAlignedMarkings,true);
const idx=createRoadTriangleIndex(model),sidewalk=appearance.groups.sidewalk.vertices;
for(let i=0;i<sidewalk.length;i+=9){
  const p=[(sidewalk[i]+sidewalk[i+3]+sidewalk[i+6])/3,
    (sidewalk[i+2]+sidewalk[i+5]+sidewalk[i+8])/3];
  assert.equal(pointOnAsphalt(p,idx),false,'estimated sidewalk must not sit on known drivable asphalt');
}
// Concave building "U": the central open notch is not a building footprint.
const U={outer:[[0,0],[10,0],[10,10],[7,10],[7,3],[3,3],[3,10],[0,10]],holes:[]};
assert.ok(polygonRoadOverlapMeters2(U,[[4,6],[6,6],[5,9]])<1e-7);
assert.ok(Math.abs(polygonRoadOverlapMeters2(U,[[1,6],[2,6],[1.5,8]])-1)<1e-7);
const syntheticSegment={id:'phase-probe',sourceId:'phase-probe',name:'probe',roadClass:'secondary',
  subtype:'road',use:'vehicle',widthMeters:8,widthRules:[],
  coordinates:[[0,0],[160,0]],connectorRefs:[{id:'node50',at:50/160},{id:'node100',at:100/160}]};
const probe=buildCityRoadGeometry({segments:[syntheticSegment],connectors:[
  {id:'node50',coordinates:[50,0]},{id:'node100',coordinates:[100,0]}]});
assert.deepEqual(probe.corridors.map(e=>e.sourceStartMeters),[0,50,100]);
const paint=buildCityStreetDetails(probe).groups.centerPaint.vertices;
assert.ok(paint.length>0);
let h=2166136261;for(const c of 'phase-probe')h=Math.imul(h^c.charCodeAt(0),16777619);
const phase=(h>>>0)%800/100;
for(let i=0;i<paint.length;i+=3){
  const offset=((paint[i]-phase)%8+8)%8;
  assert.ok(offset<=3.0001||offset>=7.9999,
    'one source road must share a constant dash cadence across connector splits');
}
const profile=buildCityStreetAudit(probe,{buildings:[{
  id:'synthetic-testing-only',baseMeters:0,heightMeters:10,heightSource:'estimated',
  polygons:[{outer:[[75,-3],[85,-3],[85,3],[75,3]],holes:[]}]}
]});
assert.equal(profile.stats.overlappingBuildings,1);
assert.equal(profile.issues[0].roadWidthEvidence,'estimated-class');
assert.equal(profile.issues[0].reviewReason,'overlap-with-estimated-width');
console.log(`PASS V1.9.5: unchanged asphalt XY / indices, shared datum aligned (${model.stats.triangles} triangles), `+
  `${centre.samples} centreline + ${wheel.samples} wheel-track samples, 0 geometry misses; `+
  `${wheel.narrowCorridors.length} separately flagged narrow roads; `+
  `${quality.stats.reviewJunctions} junction review candidates; `+
  `${appearance.stats.visualTriangles} visual triangles; concave footprint, connector-phase and walkway exclusion passed.`);
