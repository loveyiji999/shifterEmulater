// Deterministic synthetic Overture-SCHEMA fixtures test geometry; they are NOT
// distributed as actual Tainan buildings and are never loaded in gameplay.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import RAPIER from '@dimforge/rapier3d-compat';
import {metersToLongitudeLatitude} from '../src/city-geo.mjs';
import {prepareOvertureBuildingMap,validateBuildingMap,buildingStatistics,
  clipBuildingRing,ringArea} from '../src/city-buildings-geo.mjs';
import {buildCityBuildingGeometry} from '../src/city-building-geometry.mjs';
import {CityRoadWorld} from '../src/city-world.mjs';

const meters=ring=>[...ring.map(p=>metersToLongitudeLatitude(p)),metersToLongitudeLatitude(ring[0])];
const polygon=(x,z,width,height)=>meters([[x-width/2,z-height/2],
  [x+width/2,z-height/2],[x+width/2,z+height/2],[x-width/2,z+height/2]]);
const feature=(id,geometry,props={})=>({type:'Feature',geometry,properties:{id,theme:'buildings',type:'building',version:1,...props}});
const input={type:'FeatureCollection',features:[
  // Measured-height building with a 6x6m open courtyard.
  feature('actual-A',{type:'Polygon',coordinates:[polygon(0,0,30,30),
    polygon(0,0,6,6)]},{height:13.5,names:{primary:'QA only'}}),
  feature('floor-B',{type:'MultiPolygon',coordinates:[[polygon(100,25,22,12)],
    [polygon(140,25,20,12)]]},{num_floors:4,subtype:'residential'}),
  feature('default-C',{type:'Polygon',coordinates:[polygon(996,0,32,17)]},
    {subtype:'industrial',min_height:3}),
  feature('skip-under',{type:'Polygon',coordinates:[polygon(-100,-100,6,6)]},
    {is_underground:true})]};
const map=prepareOvertureBuildingMap(input,{release:'2026-09-23.1',downloadedAt:'2026-10-22T00:00:00Z'});
const stats=buildingStatistics(map);
assert.equal(stats.buildings,3);assert.equal(stats.polygons,4);
assert.equal(stats.sourceHeight,1);assert.equal(stats.floorEstimated,1);
assert.equal(stats.defaultEstimated,1);
// The official overturemaps-py writer (v1.0.2 included) may omit
// partition theme/type and puts feature.id on the GeoJSON envelope.
const sdkStyle={type:'FeatureCollection',features:[
  {type:'Feature',id:'2017fc10-4cf1-4784-b79e-9306d5020991',
    geometry:{type:'Polygon',coordinates:[polygon(-80,65,9,12)]},
    properties:{version:1,sources:[{dataset:'OpenStreetMap'}],has_parts:false,height:null}}
]};
const sdkParsed=prepareOvertureBuildingMap(sdkStyle,{release:'2026-10-21.0'});
assert.equal(sdkParsed.buildings.length,1,'official SDK GeoJSON lacking theme/type must work');
assert.equal(sdkParsed.buildings[0].id,sdkStyle.features[0].id);
assert.equal(sdkParsed.source.release,'2026-10-21.0');
assert.throws(()=>prepareOvertureBuildingMap({type:'FeatureCollection',features:[
  {...sdkStyle.features[0],properties:{...sdkStyle.features[0].properties,type:'building_part'}}
]}),/非 Overture/);
assert.throws(()=>prepareOvertureBuildingMap({type:'FeatureCollection',features:[
  {...sdkStyle.features[0],properties:{sources:[]}}
]}),/version/);

assert.equal(map.buildings[0].heightMeters,13.5);
assert.equal(map.buildings[1].heightMeters,12.8);
assert.equal(map.buildings[2].baseMeters,3);
assert.equal(map.buildings[2].heightMeters,7);
assert.equal(map.conversion.skippedFeatures,1);
assert.equal(validateBuildingMap(JSON.parse(JSON.stringify(map))).format,'shiftlab.city.buildings.v1');
assert.ok(map.buildings[2].polygons[0].outer.some(p=>Math.abs(p[0]-1000)<.001));
assert.ok(Math.abs(ringArea(clipBuildingRing([[-10,-10],[10,-10],[10,10],[-10,10]])))-400<.01);
assert.throws(()=>prepareOvertureBuildingMap({type:'FeatureCollection',features:[
  feature('not-buildings',{type:'Polygon',coordinates:[polygon(0,0,30,20)]},{theme:'transportation'})]}));
assert.throws(()=>validateBuildingMap({...map,area:{...map.area,latitude:1}}));
const model=buildCityBuildingGeometry(map);
assert.ok(model.stats.buildingTriangles>50);
assert.ok(model.tiles.size>=2);
for(const tile of model.tiles.values()) {
  assert.equal(tile.vertices.length,tile.colors.length);
  assert.equal(tile.indices.length%3,0);
  assert.ok(tile.indices.every(i=>Number.isInteger(i)&&i>=0&&i<tile.vertices.length/3));
  assert.ok(tile.vertices.every(Number.isFinite));
  for(let i=0;i<tile.indices.length;i+=3){
    const v=tile.vertices,idx=tile.indices.slice(i,i+3);
    if(idx.every(j=>Math.abs(v[j*3+1]-v[idx[0]*3+1])<.00001)) {
      const [a,b,c]=idx;
      const upward=(v[b*3+2]-v[a*3+2])*(v[c*3]-v[a*3])-
        (v[b*3]-v[a*3])*(v[c*3+2]-v[a*3+2]);
      assert.ok(upward>=-.0001,'roof triangle normal must point up');
    }
  }
}
await RAPIER.init();
const roads=JSON.parse(readFileSync(new URL('../public/data/tainan-station-roads.json',import.meta.url),'utf8'));
const scene=new CityRoadWorld();
scene.setData(roads);
const buildingStats=scene.setBuildings(map);
assert.equal(buildingStats.buildings,3);
assert.equal(scene.buildingLayers.children.length,scene.buildingModel.tiles.size);
const world=new RAPIER.World({x:0,y:-9.81,z:0});
const num=scene.createColliders(RAPIER,world);
assert.equal(num,scene.groundHandles.size+scene.buildingHandles.size);
assert.ok(scene.buildingHandles.size>0);
world.step();
const vertical=(x,z)=>world.castRay(new RAPIER.Ray({x,y:50,z},{x:0,y:-1,z:0}),60,true);
const roof=vertical(8,0);
assert.ok(Math.abs((50-roof.timeOfImpact)-13.5)<.015,`building roof collision at ${(50-roof.timeOfImpact).toFixed(3)}`);
const hole=vertical(0,0);
assert.ok(50-hole.timeOfImpact<2,'open courtyard must not be capped with fake roof');
const wall=world.castRay(new RAPIER.Ray({x:23,y:5,z:0},{x:-1,y:0,z:0}),40,true);
assert.ok(Math.abs(wall.timeOfImpact-8)<.025,'front wall must collide');
const ownBody=world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(8,17,0));
const ownCollider=world.createCollider(RAPIER.ColliderDesc.cuboid(.3,.35,.3),ownBody);
for(let i=0;i<240;i++)world.step();
assert.ok(Math.abs(ownBody.translation().y-(13.5+.35))<.06,'dynamic physics body settles on roof');
// Unload the building tiles far from the car and reload upon approaching.
scene.syncBuildingColliders(-800,-800,245,true);
assert.equal(scene.buildingHandles.size,0);
scene.syncBuildingColliders(0,0,245,true);
assert.ok(scene.buildingHandles.size>0);
scene.clearColliders();
assert.equal(scene.buildingHandles.size,0);
assert.equal(world.colliders.len(),1,'no tile colliders leaked into the procedural world');
scene.clearBuildings();
assert.equal(scene.buildingLayers.children.length,0);
assert.equal(scene.buildingModel,null);
assert.ok(ownCollider.handle>=0);
scene.dispose();
console.log(`PASS v1.9.3 official-schema buildings; ${stats.buildings} fixture buildings; ${model.stats.buildingTriangles} triangles, holes, multipart, bbox, heights, Rapier walls/roofs, streamed cleanup`);
