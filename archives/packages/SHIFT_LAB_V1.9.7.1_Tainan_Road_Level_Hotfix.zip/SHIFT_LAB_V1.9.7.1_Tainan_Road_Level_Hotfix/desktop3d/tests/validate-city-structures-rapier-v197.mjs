// Requires installed npm packages; run on Windows after npm ci.
// Validates actual Rapier queries, dynamic contact and collider registration.
import assert from 'node:assert/strict';
import RAPIER from '@dimforge/rapier3d-compat';
import {buildCityRoadGeometry,CITY_ROAD_Y} from '../src/city-road-geometry.mjs';
import {buildCityTerrainGeometry} from '../src/city-terrain-geometry.mjs';
import {buildCityRoadStructures} from '../src/city-road-structures.mjs';
const road=(id,coordinates,level=0)=>({id,sourceId:id,subtype:'road',use:'vehicle',
  roadClass:'secondary',name:id,widthMeters:8,widthRules:[],connectorRefs:[],
  sourceRange:[0,1],levelRules:level?[{value:level,between:null}]:[],coordinates});
const model=buildCityRoadGeometry({segments:[
  road('bridge',[[-100,0],[120,0]],1),road('below',[[0,-50],[0,50]]),
  road('trench',[[270,0],[490,0]],-1),road('above',[[370,-50],[370,50]])
],connectors:[]});
const terrain=buildCityTerrainGeometry(model),structures=buildCityRoadStructures(model,{terrain});
await RAPIER.init();
const physics=new RAPIER.World({x:0,y:-9.81,z:0});
const resources=[],handles=new Map();
const add=(kind,tile)=>{
  const collider=physics.createCollider(RAPIER.ColliderDesc.trimesh(
    new Float32Array(tile.vertices),new Uint32Array(tile.indices)).setFriction(.72));
  resources.push(collider);handles.set(collider.handle,kind);
};
add('terrain',terrain);
for(const tile of model.tiles.values())add('asphalt',tile);
for(const tile of structures.tiles.values())if(tile.physical)add(tile.kind,tile);
const recovery=physics.createCollider(RAPIER.ColliderDesc.cuboid(1000,.1,1000)
  .setTranslation(0,terrain.recoveryY-.10,0));resources.push(recovery);
physics.step();physics.updateSceneQueries?.();
const cast=(origin,direction,distance)=>physics.castRay(new RAPIER.Ray(origin,direction),distance,true);
const bridge=model.corridors.find(e=>e.sourceId==='bridge').heightAt(80);
const under=model.corridors.find(e=>e.sourceId==='trench').heightAt(100);
const nearRoad=cast({x:0,y:12,z:0},{x:0,y:-1,z:0},20);
assert.ok(nearRoad);assert.equal(handles.get(nearRoad.collider.handle),'asphalt');
assert.ok(Math.abs(12-nearRoad.timeOfImpact-bridge)<.05);
// From ABOVE the flyover, first hit is the separate ground crossing.
const aboveUnder=cast({x:370,y:3,z:0},{x:0,y:-1,z:0},15);
assert.ok(aboveUnder);assert.equal(handles.get(aboveUnder.collider.handle),'asphalt');
assert.ok(Math.abs(3-aboveUnder.timeOfImpact-CITY_ROAD_Y)<.05);
// From BELOW that crossing, the drivable underpass is reached directly.
const insideUnder=cast({x:370,y:under+1.5,z:0},{x:0,y:-1,z:0},4);
assert.ok(insideUnder);assert.equal(handles.get(insideUnder.collider.handle),'asphalt');
assert.ok(Math.abs(under+1.5-insideUnder.timeOfImpact-under)<.05);
const sideRail=cast({x:0,y:bridge+.55,z:0},{x:0,y:0,z:1},12);
assert.ok(sideRail,'horizontal bridge barrier hit');
assert.equal(handles.get(sideRail.collider.handle),'guardrail');
const trenchWall=cast({x:370,y:under+.40,z:0},{x:0,y:0,z:1},12);
assert.ok(trenchWall,'horizontal tunnel side-wall hit');
assert.equal(handles.get(trenchWall.collider.handle),'retainingWall');
// An upper asphalt deck is still drivable: guardrail must not replace ground.
const rb=physics.createRigidBody(RAPIER.RigidBodyDesc.dynamic()
  .setTranslation(12,bridge+1.5,0).setCanSleep(false));
physics.createCollider(RAPIER.ColliderDesc.cuboid(.35,.3,.5).setFriction(.75),rb);
for(let k=0;k<280;k++)physics.step();
const y=rb.translation().y;
assert.ok(Math.abs(y-bridge-.3)<.11,`dynamic body must settle on original road: ${y}`);
for(const c of resources)physics.removeCollider(c,true);
assert.equal(physics.colliders.len(),1,'only dynamic test collider remains');
console.log(`PASS V1.9.7 Rapier: asphalt wheel support, bridge rail and underpass wall horizontal cast, dynamic settling, collider teardown. Structure colliders ${structures.stats.collisionTiles}.`);
