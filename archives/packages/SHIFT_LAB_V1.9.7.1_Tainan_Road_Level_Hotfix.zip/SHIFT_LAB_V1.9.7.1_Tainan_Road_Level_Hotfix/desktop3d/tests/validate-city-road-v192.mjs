import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import RAPIER from '@dimforge/rapier3d-compat';
import {CityRoadWorld} from '../src/city-world.mjs';
import {CITY_ROAD_Y, buildCityRoadGeometry} from '../src/city-road-geometry.mjs';
import {validateCityMap} from '../src/city-geo.mjs';

const segment = (id, coordinates, refs, roadClass='residential') => ({id, sourceId:id,
  roadClass, use:'vehicle', subtype:'road', coordinates, connectorRefs:refs,
  widthMeters:6.2, name:id, levelRules:[], widthRules:[]});
const crossPoint={id:'central',coordinates:[0,0]};
const horizontal=segment('east-west',[[-35,0],[35,0]],[{id:'central',at:.5}]);
const north=segment('north',[[0,0],[0,35]],[{id:'central',at:0}]);
const south=segment('south',[[0,-35],[0,0]],[{id:'central',at:1}]);
const synthetic = members => ({segments:members,connectors:[crossPoint]});
for(const [segments,expected] of [[ [horizontal,north],'T' ], [[horizontal,north,south],'cross']]) {
  const result=buildCityRoadGeometry(synthetic(segments));
  const central=result.junctions.find(j=>j.id==='central');
  assert.equal(central?.type,expected,`expected ${expected}`);
  assert.equal(central?.degree,expected==='T'?3:4);
  assert.ok(result.tiles.size);
  assert.ok(result.stats.triangles > 20);
  assert.ok(result.closestRoad(0,0));
  assert.equal(result.stats.ignoredConnectorRefs,0);
}
// A connector ref can survive geographic clipping while its REAL point is
// outside the clipped geometry. Never use fractional 'at' to fake a junction.
const stale=buildCityRoadGeometry(synthetic([
  segment('clipped',[[-35,10],[35,10]],[{id:'central',at:.5}]),north]));
assert.ok(stale.stats.ignoredConnectorRefs>=1);
assert.equal(stale.stats.tJunctions,0);

const map = validateCityMap(JSON.parse(readFileSync(
  new URL('../public/data/tainan-station-roads.json',import.meta.url),'utf8')));
// Legacy 2D physics regression stays available independently of 3D elevation.
const city = new CityRoadWorld({elevationMode:'flat'});
const result = city.setData(map);
assert.equal(result.segments,2517);assert.equal(result.vehicular,1342);
assert.ok(result.tJunctions>400 && result.crossJunctions>150);
assert.ok(result.validatedConnectorRefs>3500);
assert.ok(result.triangles>20000);
assert.ok(result.collisionTiles>40);
assert.equal(city.layers.children.length,city.roadModel.tiles.size+2); // foot and rail visuals
const spawn=city.spawnPoint();
assert.ok(spawn.name && Number.isFinite(spawn.heading));
assert.ok(Math.hypot(spawn.x,spawn.z)<350, 'vehicle spawns near Tainan Station');
assert.ok(city.closestRoad(spawn.x,spawn.z).distance<.05);
for(const batch of city.roadModel.tiles.values()) {
  assert.equal(batch.vertices.length, batch.indices.length*3);
  for(const v of batch.vertices) assert.ok(Number.isFinite(v));
  for(let i=0;i<batch.indices.length;i+=3){
    const tri=batch.indices.slice(i,i+3);
    const pts=tri.map(idx=>batch.vertices.slice(idx*3,idx*3+3));
    const [a,b,c]=pts;
    const up=(b[2]-a[2])*(c[0]-a[0])-(b[0]-a[0])*(c[2]-a[2]);
    assert.ok(up>=-0.0001,'mesh triangles must have upward or zero normals');
  }
}
await RAPIER.init();
const world=new RAPIER.World({x:0,y:-9.81,z:0});
const colliders=city.createColliders(RAPIER,world);
assert.equal(colliders,result.collisionTiles+2,'road tiles + upper soil + recovery floor');
assert.equal(city.groundHandles.size,colliders);
world.step(); // Rapier 0.18 rebuilds the query pipeline at the first world.step.
const roadRay=(x,z)=>world.castRay(new RAPIER.Ray({x,y:3,z},{x:0,y:-1,z:0}),5,true);
const onAsphalt=(x,z)=>Math.abs((roadRay(x,z)?.timeOfImpact??100)-(3-CITY_ROAD_Y))<.025;
assert.ok(onAsphalt(spawn.x,spawn.z),'vehicle must spawn on a physical asphalt surface');
for (const type of ['T','cross']) {
  const nodes=city.roadModel.junctions.filter(j=>j.type===type);
  for(const junction of nodes) {
    assert.ok(onAsphalt(...junction.point),`${type} physical junction hole at ${junction.point}`);
  }
}
const junction=city.roadModel.junctions.find(j=>j.type==='cross'&&Math.abs(j.point[0])<500&&Math.abs(j.point[1])<500);
assert.ok(junction);
// Sample 4 arms from the connector, including the transition from junction
// surface to trimmed road strip. The wheel ray must never fall into a seam.
for(const arm of junction.node.arms) {
  const node=junction.point;
  for(const offset of [0,.5,1,2,3]) {
    const dist=Math.min(offset,arm.edge.length*.22);
    const x=node[0]+arm.direction[0]*dist,z=node[1]+arm.direction[1]*dist;
    assert.ok(onAsphalt(x,z),'missing asphalt inside a junction approach at '+x+','+z);
  }
}
// Use actual arc-length positions of each connected Overture centerline.
// A straight projected tangent can leave the asphalt on sharply curved roads;
// the test follows the mapped street itself instead of inventing straight lanes.
function armCenterAt(edge, fromStart, travel) {
  const pts=fromStart?edge.points:[...edge.points].reverse();
  let remaining=travel;
  for(let i=1;i<pts.length;i++) {
    const [ax,az]=pts[i-1], [bx,bz]=pts[i];
    const length=Math.hypot(bx-ax,bz-az);
    if(remaining<=length)return [ax+(bx-ax)*remaining/length,az+(bz-az)*remaining/length];
    remaining-=length;
  }
  return pts.at(-1);
}
let checkedArms=0;
for(const node of city.roadModel.junctions.filter(j=>j.type==='T'||j.type==='cross')) {
  for(const arm of node.node.arms) for(const offset of [.25,.75,1.5,2,3,4,5,6,8,10]) {
    if(offset>arm.edge.length*.5)continue;
    const [x,z]=armCenterAt(arm.edge,arm.fromStart,offset);
    // Input centerlines are clipped at exactly +/-1000 m; at the map edge
    // a drivable wheel track can legitimately extend beyond the downloaded data.
    if(Math.abs(x)>998||Math.abs(z)>998)continue;
    assert.ok(onAsphalt(x,z), `real ${node.type} arm collision seam at ${x},${z}`);
    checkedArms++;
  }
}
assert.ok(checkedArms>30000,'real-network junction transition coverage');
// Real Rapier dynamic body must settle on the same junction collider.
const body=world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(
  junction.point[0],1.7,junction.point[1]));
world.createCollider(RAPIER.ColliderDesc.cuboid(.48,.3,.65).setFriction(.72),body);
for(let i=0;i<220;i++)world.step();
assert.ok(Math.abs(body.translation().y-(CITY_ROAD_Y+.3))<.035,
  `dynamic body should settle on junction, y=${body.translation().y}`);
city.setDrivingView(true);
assert.equal(city.grid.visible,false);
city.setDrivingView(false);
assert.equal(city.grid.visible,true);
city.clearColliders();
assert.equal(world.colliders.len(),1,'only the separate test body collider remains');
assert.equal(city.groundHandles.size,0,'no stale collider handles');
city.dispose();
console.log(`PASS v1.9.2 Overture street geometry, ${result.tJunctions} T / ${result.crossJunctions} crosses, ${result.triangles} triangles, ${colliders} Rapier colliders, real contact and cleanup; ${checkedArms} arm samples`);
