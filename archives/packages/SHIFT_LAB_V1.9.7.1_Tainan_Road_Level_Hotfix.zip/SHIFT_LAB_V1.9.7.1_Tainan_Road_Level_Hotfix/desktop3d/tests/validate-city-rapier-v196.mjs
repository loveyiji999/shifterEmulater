// V1.9.6 optional engine-integrated QA, requires npm dependencies.
// Synthetic local fixtures only; does NOT assert surveyed Tainan elevations.
import assert from 'node:assert/strict';
import RAPIER from '@dimforge/rapier3d-compat';
import {buildCityRoadGeometry} from '../src/city-road-geometry.mjs';
import {buildCityTerrainGeometry} from '../src/city-terrain-geometry.mjs';
const make=(id,coordinates,levelRules=[])=>({id,sourceId:id,subtype:'road',
  roadClass:'secondary',use:'vehicle',name:id,sourceRange:[0,1],widthMeters:8,
  widthRules:[],connectorRefs:[],coordinates,levelRules});
await RAPIER.init();
const map={segments:[
  make('overpass',[[-80,0],[80,0]],[{value:1,between:null}]),
  make('ground-crossing',[[0,-80],[0,80]]),
  make('underpass',[[280,0],[440,0]],[{value:-1,between:null}])
],connectors:[]};
const roads=buildCityRoadGeometry(map),terrain=buildCityTerrainGeometry(roads);
const world=new RAPIER.World({x:0,y:-9.81,z:0});
const colliders=[];
const addTrimesh=(vertices,indices)=>world.createCollider(RAPIER.ColliderDesc.trimesh(
  new Float32Array(vertices),new Uint32Array(indices)).setFriction(.8));
colliders.push(addTrimesh(terrain.vertices,terrain.indices));
for(const tile of roads.tiles.values())colliders.push(addTrimesh(tile.vertices,tile.indices));
colliders.push(world.createCollider(RAPIER.ColliderDesc.cuboid(1000,.10,1000)
  .setTranslation(0,terrain.recoveryY-.10,0).setFriction(.8)));
world.updateSceneQueries?.();
world.step(); // Rapier 0.18 refreshes broadphase / query pipeline on first step.
function hitY(x,z,originY=12){
  const hit=world.castRay(new RAPIER.Ray({x,y:originY,z},{x:0,y:-1,z:0}),30,true);
  assert.ok(hit,`no downward collider at ${x},${z}`);
  return originY-hit.timeOfImpact;
}
const bridge=roads.corridors.find(e=>e.sourceId==='overpass');
const street=roads.corridors.find(e=>e.sourceId==='ground-crossing');
const tunnel=roads.corridors.find(e=>e.sourceId==='underpass');
const bridgeY=bridge.heightAt(bridge.length*.5),streetY=street.heightAt(street.length*.5);
const tunnelY=tunnel.heightAt(tunnel.length*.5);
assert.ok(bridgeY>streetY+5);
assert.ok(tunnelY < -4);
assert.ok(terrain.cutAt(360,0));
assert.ok(!terrain.cutAt(0,0));
assert.ok(Math.abs(hitY(0,0,12)-bridgeY)<.025,'bridge should be the upper road collider');
assert.ok(Math.abs(hitY(0,0,3)-streetY)<.025,'ground road remains independently collidable');
assert.ok(Math.abs(hitY(360,0,6)-tunnelY)<.025,'upper soil must not block underpass');

// Rapier dynamic settling tests a real contact response, beyond 2D ray hits.
const box=(x,z,height)=>{
  const body=world.createRigidBody(RAPIER.RigidBodyDesc.dynamic()
    .setTranslation(x,height+1.5,z).setCanSleep(false));
  world.createCollider(RAPIER.ColliderDesc.cuboid(.35,.30,.50).setFriction(.75),body);
  return body;
};
const upperBox=box(0,0,bridgeY),lowerBox=box(360,0,tunnelY);
for(let i=0;i<300;i++)world.step();
for(const [body,target,label] of [[upperBox,bridgeY,'upper'],[lowerBox,tunnelY,'lower']]){
  const p=body.translation();
  assert.ok([p.x,p.y,p.z].every(Number.isFinite),`${label}: nonfinite Rapier pose`);
  assert.ok(Math.abs(p.y-(target+.30))<.08,`${label}: did not settle on deck ${p.y} vs ${target+.30}`);
}
console.log(`PASS V1.9.6 Rapier real trimesh raycasts: upper bridge Y=${bridgeY.toFixed(2)}, `+
  `ground Y=${streetY.toFixed(2)}, underpass Y=${tunnelY.toFixed(2)}, `+
  `soil cutouts=${terrain.holes}; dynamic solid contacts and gravity settles passed.`);
