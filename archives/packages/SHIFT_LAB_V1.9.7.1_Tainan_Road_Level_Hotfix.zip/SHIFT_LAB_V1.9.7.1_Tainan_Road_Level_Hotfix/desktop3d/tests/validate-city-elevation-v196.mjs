// V1.9.6 pure Node: road levels, source-range clipping, ramp continuity,
// bridge-vs-ground separation, underpass terrain, shared render/collider XYZ.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {buildCityRoadGeometry,atDistance,CITY_ROAD_Y} from '../src/city-road-geometry.mjs';
import {clipPolylineWithSourceRanges,clipPolylineToSquare} from '../src/city-geo.mjs';
import {buildCityTerrainGeometry} from '../src/city-terrain-geometry.mjs';
import {buildCityStreetDetails} from '../src/city-street-details.mjs';
import {MAX_ESTIMATED_GRADE,LEVEL_HEIGHT_ESTIMATE_METERS} from '../src/city-road-elevation.mjs';
const close=(a,b,tol=.00001)=>assert.ok(Math.abs(a-b)<tol,`${a} vs ${b} (tol ${tol})`);
const road=(id,coords,rules=[],refs=[],width=8)=>({id,sourceId:id,subtype:'road',
  use:'vehicle',roadClass:'secondary',name:id,widthMeters:width,
  widthRules:[],connectorRefs:refs,levelRules:rules,coordinates:coords,sourceRange:[0,1]});

// Same horizontal clipping as V1.9.1, with original fraction for between rules.
const original=[[-1400,0],[-600,0],[0,0],[600,0],[1400,0]];
const pieces=clipPolylineWithSourceRanges(original);
assert.deepEqual(pieces.map(p=>p.coordinates),clipPolylineToSquare(original));
close(pieces[0].sourceRange[0],400/2800);
close(pieces[0].sourceRange[1],2400/2800);
const annotated={...road('clipped',pieces[0].coordinates,[{value:1,between:[.45,.55]}]),
  sourceRange:pieces[0].sourceRange};
const clipped=buildCityRoadGeometry({segments:[annotated],connectors:[]});
const clipEdge=clipped.corridors[0];
close(clipEdge.heightOffsetAt(clipEdge.length*.5),LEVEL_HEIGHT_ESTIMATE_METERS);
close(clipEdge.levelIntervals[0].from,clipEdge.length*(.45-pieces[0].sourceRange[0])/
  (pieces[0].sourceRange[1]-pieces[0].sourceRange[0]));
assert.ok(clipEdge.heightOffsetAt(0)<.001);

// Crossings with NO shared Overture connector must not be glued together.
const over=road('bridge',[[-80,0],[80,0]],[{value:1,between:null}]);
const below=road('street',[[0,-80],[0,80]]);
const crossing=buildCityRoadGeometry({segments:[over,below],connectors:[]});
const bridge=crossing.corridors.find(e=>e.id.startsWith('bridge@'));
const street=crossing.corridors.find(e=>e.id.startsWith('street@'));
close(bridge.heightAt(bridge.length/2)-street.heightAt(street.length/2),LEVEL_HEIGHT_ESTIMATE_METERS);
const upper=crossing.closestRoad(.5,.5,10,6),lower=crossing.closestRoad(.5,.5,10,.2);
assert.equal(upper.sourceId,'bridge');assert.equal(lower.sourceId,'street');
assert.ok(bridge.heightAt(0)>street.heightAt(0));
const elevatedStreet=buildCityStreetDetails(crossing);
assert.ok(elevatedStreet.stats.followsRoad3D);
const asphaltYs=[...crossing.tiles.values()].flatMap(t=>t.vertices.filter((_,i)=>i%3===1));
assert.ok(Math.max(...asphaltYs)-Math.min(...asphaltYs)>5,'render/collider road buffers must be separated in Y');
const paintYs=elevatedStreet.groups.centerPaint.vertices.filter((_,i)=>i%3===1);
assert.ok(paintYs.some(y=>y>5),'paint has to follow elevated road');
assert.ok(paintYs.some(y=>y<1),'street paint must stay at grade when not on bridge');

// Explicit connector joins the bridge to a 130m approach with no fictional
// extra road. The shared node has one Y; maximum isolated grade is bounded.
const start=road('bridge',[[-60,20],[0,20]],[{value:1,between:null}],
  [{id:'joint',at:1}]);
const approach=road('approach',[[0,20],[140,20]],[],[{id:'joint',at:0}]);
const slope=buildCityRoadGeometry({segments:[start,approach],connectors:[{id:'joint',coordinates:[0,20]}]});
const j=slope.junctions.find(j=>j.id==='joint');
assert.ok(j);
for(const arm of j.node.arms)close(arm.edge.heightAt(arm.fromStart?0:arm.edge.length),j.height);
const approachEdge=slope.corridors.find(e=>e.id.startsWith('approach@'));
close(approachEdge.heightAt(0),j.height);
close(approachEdge.heightAt(140),CITY_ROAD_Y);
assert.ok(Math.abs(approachEdge.gradeAt(30)) <= MAX_ESTIMATED_GRADE+1e-5);

// A real underpass cannot share an uncut, all-covering topsoil collider.
const sub=road('underpass',[[0,0],[100,0]],[{value:-1,between:[.25,.75]}]);
const holeModel=buildCityRoadGeometry({segments:[sub],connectors:[]});
const terrain=buildCityTerrainGeometry(holeModel);
assert.ok(terrain.holes>0);
assert.ok(terrain.cutAt(50,0));
assert.ok(!terrain.cutAt(900,900));
assert.ok(terrain.recoveryY<holeModel.pickSpawn().y);
assert.ok(holeModel.corridors[0].heightAt(50) < terrain.groundY);

const real=JSON.parse(readFileSync(new URL('../public/data/tainan-station-roads.json',import.meta.url),'utf8'));
assert.equal(real.segments.filter(s=>Array.isArray(s.sourceRange)).length,2517,
  'all real clipped centerlines retain the original Overture chainage');
const city=buildCityRoadGeometry(real),soil=buildCityTerrainGeometry(city);
assert.equal(city.stats.corridors,3196);
assert.equal(city.stats.tJunctions,962);
assert.equal(city.stats.crossJunctions,295);
assert.ok(city.stats.annotatedCorridors>=28);
assert.ok(city.stats.elevatedCorridors>0);
assert.ok(city.stats.depressedCorridors>0);
assert.equal(city.stats.maximumOffsetMeters,LEVEL_HEIGHT_ESTIMATE_METERS*2);
assert.equal(city.stats.minimumOffsetMeters,-LEVEL_HEIGHT_ESTIMATE_METERS);
assert.equal(city.stats.sourceHeightSurveyed,false);
assert.ok(city.stats.measuredMaxGrade<=MAX_ESTIMATED_GRADE*2+.001);
let checkedJunctions=0;
for(const junction of city.junctions){
  for(const arm of junction.node.arms)close(arm.edge.heightAt(arm.fromStart?0:arm.edge.length),junction.height,.00001);
  checkedJunctions++;
}
let allTriangles=0,slopingTriangles=0;
for(const tile of city.tiles.values()){
  assert.equal(tile.vertices.length,tile.indices.length*3);
  assert.ok(tile.vertices.every(Number.isFinite));
  for(let i=0;i<tile.indices.length;i+=3){
    const a=tile.indices[i]*3,b=tile.indices[i+1]*3,c=tile.indices[i+2]*3;
    const y=[tile.vertices[a+1],tile.vertices[b+1],tile.vertices[c+1]];
    const up=(tile.vertices[b+2]-tile.vertices[a+2])*(tile.vertices[c]-tile.vertices[a])-
      (tile.vertices[b]-tile.vertices[a])*(tile.vertices[c+2]-tile.vertices[a+2]);
    assert.ok(up>0,'triangle winding must face +Y');
    if(Math.max(...y)-Math.min(...y)>.001)slopingTriangles++;
    allTriangles++;
  }
}
assert.ok(slopingTriangles>0);
let undergroundSamples=0,carveMisses=0;
for(const e of city.corridors){
  const steps=Math.max(1,Math.ceil(e.length/4));
  for(let k=0;k<=steps;k++){
    const s=e.length*k/steps,y=e.heightAt(s);
    if(y>=soil.groundY+(CITY_ROAD_Y-soil.groundY)*.5)continue;
    undergroundSamples++;
    if(!soil.cutAt(...atDistance(e.line,s)))carveMisses++;
  }
}
assert.ok(undergroundSamples>500);
assert.equal(carveMisses,0,'the soil must NOT obstruct any below-grade asphalt path');
assert.ok(soil.stats.terrainTriangles>0);
assert.ok(soil.stats.excavatedCells>0);
console.log(`PASS V1.9.6 source chainage and level_rules; ${city.stats.elevatedCorridors} elevated / `+
  `${city.stats.depressedCorridors} below-grade corridors; ${allTriangles} XYZ triangles (`+
  `${slopingTriangles} sloped); ${checkedJunctions} seamless junctions; `+
  `${undergroundSamples} underground samples with zero upper-soil obstructions; `+
  `${soil.holes} terrain cells excavated; stacked crossing and visual paint heights passed.`);
