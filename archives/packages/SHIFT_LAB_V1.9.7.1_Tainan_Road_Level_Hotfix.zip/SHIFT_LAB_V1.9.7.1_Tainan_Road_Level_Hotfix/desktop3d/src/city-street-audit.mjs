// V1.9.4 geospatial QA, not a geometry repair tool. Flags possible overlap
// between real building footprints and the CURRENT drivable asphalt polygons.
// Both buildings and road widths have unequal precision: these are review
// candidates, never assertions that the Overture input is wrong.
import {atDistance} from './city-road-geometry.mjs';
const CELL=45,EPS=1e-9;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
function area(polygon){
  let sum=0;for(let i=0;i<polygon.length;i++){
    const a=polygon[i],b=polygon[(i+1)%polygon.length];
    sum+=a[0]*b[1]-a[1]*b[0];
  }return Math.abs(sum)*.5;
}
function cross(a,b,p){return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]);}
function clipConvex(subject,triangle){
  if(subject.length<3)return [];
  const orient=Math.sign(cross(triangle[0],triangle[1],triangle[2]));
  if(!orient)return [];
  let poly=subject;
  for(let k=0;k<3&&poly.length;k++){
    const a=triangle[k],b=triangle[(k+1)%3];const next=[];
    for(let i=0;i<poly.length;i++){
      const p=poly[i],q=poly[(i+1)%poly.length];
      const cp=orient*cross(a,b,p),cq=orient*cross(a,b,q);
      const inP=cp>=-EPS,inQ=cq>=-EPS;
      if(inP)next.push(p);
      if(inP!==inQ){const t=clamp(cp/(cp-cq),0,1);
        next.push([p[0]+(q[0]-p[0])*t,p[1]+(q[1]-p[1])*t]);}
    }
    poly=next;
  }
  return poly;
}
// Overture building outlines may be concave. Clipping the entire ring as a
// single polygon against each asphalt triangle (V1.9.4) can incorrectly join
// separated intersections. Ear-triangulate the ring once, clip convex pieces.
const ringTriangles=new WeakMap();
function triangulateRing(ring){
  if(ringTriangles.has(ring))return ringTriangles.get(ring);
  const clean=[];
  for(const p of ring){
    if(!clean.length||Math.hypot(p[0]-clean.at(-1)[0],p[1]-clean.at(-1)[1])>1e-7)clean.push(p);
  }
  if(clean.length>2&&Math.hypot(clean[0][0]-clean.at(-1)[0],clean[0][1]-clean.at(-1)[1])<1e-7)clean.pop();
  let signed=0;
  for(let i=0;i<clean.length;i++){
    const a=clean[i],b=clean[(i+1)%clean.length];signed+=a[0]*b[1]-a[1]*b[0];
  }
  const orientation=Math.sign(signed),tris=[],indices=clean.map((_,i)=>i);
  if(!orientation||clean.length<3){ringTriangles.set(ring,[]);return [];}
  function inside(p,a,b,c){
    return orientation*cross(a,b,p)>=-1e-9&&orientation*cross(b,c,p)>=-1e-9&&
      orientation*cross(c,a,p)>=-1e-9;
  }
  let guard=0;
  while(indices.length>3&&guard++<clean.length*clean.length){
    let found=false;
    for(let k=0;k<indices.length;k++){
      const p=indices[(k+indices.length-1)%indices.length],
        q=indices[k],r=indices[(k+1)%indices.length];
      const a=clean[p],b=clean[q],c=clean[r];
      if(orientation*cross(a,b,c)<=1e-10)continue;
      if(indices.some(idx=>idx!==p&&idx!==q&&idx!==r&&inside(clean[idx],a,b,c)))continue;
      tris.push([a,b,c]);indices.splice(k,1);found=true;break;
    }
    if(!found)break;
  }
  if(indices.length===3)tris.push(indices.map(i=>clean[i]));
  // Invalid/self-intersecting polygons cannot be assigned a precise area.
  // Fall back to the old conservative candidate algorithm rather than crash
  // the game and block otherwise valid city imports.
  const answer=indices.length>3?null:tris;
  ringTriangles.set(ring,answer);
  return answer;
}
function clippedRingArea(ring,roadTriangle){
  const triangles=triangulateRing(ring);
  if(triangles===null)return area(clipConvex(ring,roadTriangle));
  let total=0;
  for(const ear of triangles)total+=area(clipConvex(ear,roadTriangle));
  return total;
}
export function polygonRoadOverlapMeters2(polygon,roadTriangle){
  const outer=clippedRingArea(polygon.outer,roadTriangle);
  if(outer<EPS)return 0;
  const holes=(polygon.holes||[]).reduce((n,ring)=>n+clippedRingArea(ring,roadTriangle),0);
  return Math.max(0,outer-holes);
}

function rect(points){
  const xs=points.map(p=>p[0]),zs=points.map(p=>p[1]);
  return {minX:Math.min(...xs),maxX:Math.max(...xs),minZ:Math.min(...zs),maxZ:Math.max(...zs)};
}
function overlapping(a,b){return a.maxX>b.minX+EPS && b.maxX>a.minX+EPS &&
  a.maxZ>b.minZ+EPS && b.maxZ>a.minZ+EPS;}
function eachCell(bounds,visit){
  const xmin=Math.floor(bounds.minX/CELL),xmax=Math.floor(bounds.maxX/CELL);
  const zmin=Math.floor(bounds.minZ/CELL),zmax=Math.floor(bounds.maxZ/CELL);
  for(let x=xmin;x<=xmax;x++)for(let z=zmin;z<=zmax;z++)visit(`${x}:${z}`);
}
export function createRoadTriangleIndex(roadModel){
  const index=new Map(),triangles=[];
  for(const tile of roadModel.tiles.values()){
    const {vertices,indices}=tile;
    for(let i=0;i<indices.length;i+=3){
      const t=[];
      for(let j=0;j<3;j++){
        const k=indices[i+j]*3;
        t.push([vertices[k],vertices[k+2]]);
      }
      const bounds=rect(t);
      const id=triangles.push({points:t,bounds})-1;
      eachCell(bounds,key=>{if(!index.has(key))index.set(key,[]);index.get(key).push(id);});
    }
  }
  return {index,triangles};
}
export function pointOnAsphalt(point,roadIndex){
  const {index,triangles}=roadIndex;
  const key=`${Math.floor(point[0]/CELL)}:${Math.floor(point[1]/CELL)}`;
  for(const id of index.get(key)||[]){
    const triangle=triangles[id].points;
    const first=cross(triangle[0],triangle[1],point),
      second=cross(triangle[1],triangle[2],point),
      third=cross(triangle[2],triangle[0],point);
    if((first>=-1e-5&&second>=-1e-5&&third>=-1e-5)||
       (first<=1e-5&&second<=1e-5&&third<=1e-5))return true;
  }
  return false;
}
export function auditCityRoadCoverage(roadModel,{missLimit=100}={}){
  if(!roadModel?.tiles||!roadModel.junctions)throw Error('路面覆蓋檢測需要完整道路曲面');
  const grid=createRoadTriangleIndex(roadModel);
  const misses=[];let samples=0;
  const check=(point,context)=>{
    const [x,z]=point;
    if(!Number.isFinite(x)||!Number.isFinite(z)||Math.abs(x)>998||Math.abs(z)>998)return;
    samples++;
    if(!pointOnAsphalt(point,grid)&&misses.length<missLimit)misses.push({x,z,context});
  };
  for(const j of roadModel.junctions){
    if(!['T','cross'].includes(j.type))continue;
    check(j.point,j.type+' junction');
    for(const arm of j.node.arms)for(const distance of [.25,.75,1.5,2,3,4,5,6,8,10]){
      if(distance>arm.edge.length*.5)continue;
      const along=arm.fromStart?distance:arm.edge.length-distance;
      check(atDistance(arm.edge.line,along),j.type+' arm');
    }
  }
  return {samples,missesCount:misses.length,misses,roadTriangles:grid.triangles.length,
    limitation:'2D geometry test of junction centreline only; physical wheel contact still requires Rapier/WebGL QA'};
}
export function buildCityStreetAudit(roadModel,buildingMap,{overlapThreshold=0.35,limit=500}={}){
  if(!roadModel?.tiles||!roadModel.closestRoad)throw Error('城市檢測需要現有道路實體曲面');
  if(!Number.isFinite(overlapThreshold)||overlapThreshold<0 || !Number.isInteger(limit)||limit<1)
    throw Error('城市檢測參數無效');
  const {index,triangles}=createRoadTriangleIndex(roadModel);
  const candidates=[],details={buildingsChecked:buildingMap?.buildings?.length??0,
    roadTrianglesIndexed:triangles.length,buildingPolygonsChecked:0,
    overlappingBuildings:0,overlappingPolygons:0,overlapTrianglePairs:0,
    estimatedWidthCorridors:roadModel.stats?.corridorsWithEstimatedWidth??0,
    sourceRuleWidthCorridors:roadModel.stats?.corridorsWithSourceWidth??0,
    thresholdSquareMeters:overlapThreshold,limitations:
    '道路寬度多為分類估算；結果只代表二維投影疑似侵入，不代表實測建築碰撞錯誤。'};
  for(const building of buildingMap?.buildings||[]){
    let pairs=0,largest=0,centroid=null,polygonsHit=0;
    for(const polygon of building.polygons){
      details.buildingPolygonsChecked++;
      if(!polygon.outer?.length)continue;
      const bounds=rect(polygon.outer),nearby=new Set();
      eachCell(bounds,key=>{for(const idx of index.get(key)||[])nearby.add(idx);});
      let thisPoly=false;
      for(const idx of nearby){
        const tri=triangles[idx];
        if(!overlapping(bounds,tri.bounds))continue;
        const sqm=polygonRoadOverlapMeters2(polygon,tri.points);
        if(sqm<=overlapThreshold)continue;
        pairs++;details.overlapTrianglePairs++;
        if(sqm>largest){largest=sqm;
          centroid=[(tri.points[0][0]+tri.points[1][0]+tri.points[2][0])/3,
            (tri.points[0][1]+tri.points[1][1]+tri.points[2][1])/3];}
        thisPoly=true;
      }
      if(thisPoly){details.overlappingPolygons++;polygonsHit++;}
    }
    if(pairs){
      details.overlappingBuildings++;
      const nearest=roadModel.closestRoad(centroid[0],centroid[1],80);
      candidates.push({id:building.id,x:centroid[0],z:centroid[1],
        pairs,polygonsHit,maxTriangleOverlapSqm:Number(largest.toFixed(2)),
        nearestRoadName:nearest?.roadClass||'unknown',
        nearestRoadWidthMeters:nearest?.widthMeters??null,
        isElevated:building.baseMeters>2.0,source:building.heightSource,
        roadWidthEvidence:nearest?.widthSource??'unknown',
        reviewReason:building.baseMeters>2.0?'possibly-separated-by-height':
          nearest?.widthSource==='source-rule'?'overlap-with-sourced-width':'overlap-with-estimated-width'});
    }
  }
  candidates.sort((a,b)=>b.maxTriangleOverlapSqm-a.maxTriangleOverlapSqm || b.pairs-a.pairs || a.id.localeCompare(b.id));
  details.issuesTruncated=Math.max(0,candidates.length-limit);
  return {stats:details,issues:candidates.slice(0,limit)};
}
