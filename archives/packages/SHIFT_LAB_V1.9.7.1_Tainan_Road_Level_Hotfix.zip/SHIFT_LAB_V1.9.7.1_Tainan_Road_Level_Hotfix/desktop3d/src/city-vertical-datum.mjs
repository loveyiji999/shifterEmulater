// V1.9.7.1: one local Y datum for city surface, building footings and roads.
// This is a relative game-space datum, NOT a surveyed altitude/DEM.
// Buildings without Overture min_height begin at Y=0; roads use a minimal
// rendering clearance above the same ground rather than an artificial curb.
export const CITY_GROUND_Y = 0;
export const CITY_ROAD_Y = CITY_GROUND_Y + 0.025;
