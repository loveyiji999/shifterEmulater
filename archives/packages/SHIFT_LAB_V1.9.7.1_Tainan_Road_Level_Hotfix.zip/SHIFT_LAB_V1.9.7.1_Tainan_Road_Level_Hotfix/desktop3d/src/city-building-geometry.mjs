// Batched real Overture footprints: indexed Three.js meshes and Rapier triangles.
// No synthetic building locations. Source height/floor/estimated categories are
// intentionally different colors so the 3D view is not mistaken for survey.
import * as THREE from 'three';
import {validateBuildingMap} from './city-buildings-geo.mjs';

export const BUILDING_TILE_METERS=200;
const palette={height:[0x899dab,0xb3c3cb],floors:[0x9c958a,0xc4b9a7],estimated:[0x7d8589,0xa6aaad]};
function hash(id){let n=2166136261;for(let i=0;i<id.length;i++)n=Math.imul(n^id.charCodeAt(i),16777619);return n>>>0;}
function putVertex(batch,x,y,z,color){
  const index=batch.vertices.length/3;
  batch.vertices.push(x,y,z);
  batch.colors.push(color.r,color.g,color.b);
  batch.bounds.minX=Math.min(batch.bounds.minX,x);batch.bounds.maxX=Math.max(batch.bounds.maxX,x);
  batch.bounds.minZ=Math.min(batch.bounds.minZ,z);batch.bounds.maxZ=Math.max(batch.bounds.maxZ,z);
  return index;
}
function emitPolygon(batch,polygon,building){
  const rings=[polygon.outer,...polygon.holes];
  const contour=polygon.outer.map(p=>new THREE.Vector2(...p));
  const holes=polygon.holes.map(r=>r.map(p=>new THREE.Vector2(...p)));
  const points=[...polygon.outer,...polygon.holes.flat()];
  let tris;
  try{tris=THREE.ShapeUtils.triangulateShape(contour,holes);}
  catch{return false;}
  if(!tris.length)return false;
  const top=building.baseMeters+building.heightMeters,base=building.baseMeters;
  const [facade,roof]=palette[building.heightSource];
  const variation=((hash(building.id)%11)-5)*.011;
  const wallColor=new THREE.Color(facade).multiplyScalar(1+variation);
  const roofColor=new THREE.Color(roof).multiplyScalar(1+variation);
  // One indexed roof vertex per unique ring corner, shared by adjacent roof
  // triangles. Wall vertices are separated per edge for crisp flat shading.
  const roofIndices=points.map(([x,z])=>putVertex(batch,x,top,z,roofColor));
  for(const tri of tris){
    const [a,b,c]=tri;
    if(!points[a]||!points[b]||!points[c])continue;
    const va=points[a],vb=points[b],vc=points[c];
    const upward=(vb[1]-va[1])*(vc[0]-va[0])-(vb[0]-va[0])*(vc[1]-va[1]);
    if(Math.abs(upward)<1e-9)continue;
    if(upward>0)batch.indices.push(roofIndices[a],roofIndices[b],roofIndices[c]);
    else batch.indices.push(roofIndices[a],roofIndices[c],roofIndices[b]);
  }
  for(let ringIndex=0;ringIndex<rings.length;ringIndex++){
    const ring=rings[ringIndex];
    for(let i=0;i<ring.length;i++){
      const a=ring[i],b=ring[(i+1)%ring.length];
      if(Math.hypot(a[0]-b[0],a[1]-b[1])<1e-5)continue;
      const ba=putVertex(batch,a[0],base,a[1],wallColor),
        ta=putVertex(batch,a[0],top,a[1],wallColor),
        bb=putVertex(batch,b[0],base,b[1],wallColor),
        tb=putVertex(batch,b[0],top,b[1],wallColor);
      // Outside wall: right side of CCW exterior. Hole wall faces inward.
      if(!ringIndex)batch.indices.push(ba,ta,tb,ba,tb,bb);
      else batch.indices.push(ba,tb,ta,ba,bb,tb);
    }
  }
  return true;
}
export function buildCityBuildingGeometry(buildingMap){
  validateBuildingMap(buildingMap);
  const tiles=new Map();let renderedPolygons=0;
  for(const building of buildingMap.buildings)for(const polygon of building.polygons){
    // Assign a polygon by its original footprint, not an inferred street/block.
    const vertex=polygon.outer[0],tx=Math.floor((vertex[0]+1000)/BUILDING_TILE_METERS),
      tz=Math.floor((vertex[1]+1000)/BUILDING_TILE_METERS);
    const key=tx+':'+tz;
    if(!tiles.has(key))tiles.set(key,{key,vertices:[],indices:[],colors:[],
      bounds:{minX:Infinity,maxX:-Infinity,minZ:Infinity,maxZ:-Infinity}});
    if(emitPolygon(tiles.get(key),polygon,building))renderedPolygons++;
  }
  for(const [key,tile] of tiles)if(!tile.indices.length)tiles.delete(key);
  return {tiles,stats:{buildings:buildingMap.buildings.length,renderedPolygons,
    buildingTiles:tiles.size,buildingTriangles:[...tiles.values()].reduce((s,t)=>s+t.indices.length/3,0)}};
}
export function createBuildingTileMesh(tile,material){
  const geo=new THREE.BufferGeometry();
  geo.setAttribute('position',new THREE.Float32BufferAttribute(tile.vertices,3));
  geo.setAttribute('color',new THREE.Float32BufferAttribute(tile.colors,3));
  geo.setIndex(tile.indices);geo.computeVertexNormals();geo.computeBoundingSphere();
  const mesh=new THREE.Mesh(geo,material);
  mesh.receiveShadow=true;return mesh;
}
