// Overture buildings -> exact 2x2 km, locally projected, clipped footprints.
// No randomly placed buildings or assumed actual heights are ever generated.
import {TAINAN_STATION, areaBounds, longitudeLatitudeToMeters, OVERTURE_ATTRIBUTION} from './city-geo.mjs';

export const CITY_BUILDING_FORMAT = 'shiftlab.city.buildings.v1';
export const CITY_BUILDING_PATH = './data/tainan-station-buildings.json';
const LIMIT = 100000, MAX_RING = 10000, LIMIT_VERTICES = 1800000;
const HALF = 1000, EPS = 1e-6;
const finite = Number.isFinite;
const same = (a,b) => Math.abs(a[0]-b[0])<EPS && Math.abs(a[1]-b[1])<EPS;

export function ringArea(ring) {
  let sum=0;
  for(let i=0;i<ring.length;i++) {
    const a=ring[i],b=ring[(i+1)%ring.length];sum+=a[0]*b[1]-b[0]*a[1];
  }
  return sum/2;
}
function normalizeRing(ring, ccw) {
  if(!Array.isArray(ring))return [];
  const points=[];
  for(const item of ring) {
    if(!Array.isArray(item)||item.length<2||!item.slice(0,2).every(finite))throw Error('建築輪廓點座標錯誤');
    const p=[item[0],item[1]];
    if(!points.length||!same(points.at(-1),p))points.push(p);
  }
  if(points.length>1&&same(points[0],points.at(-1)))points.pop();
  if(points.length<3||Math.abs(ringArea(points))<.05)return [];
  if((ringArea(points)>0)!==ccw)points.reverse();
  return points;
}
// Sutherland-Hodgman clips each ring to the closed local metre square.
// For an interior hole touching the clipping edge, reject that polygon rather
// than silently filling the clipped aperture with a false roof/collision.
export function clipBuildingRing(ring, half=HALF) {
  let out=ring;
  for(const [inside,intersection] of [
    [p=>p[0]>=-half-EPS,(a,b)=>[-half,a[1]+(b[1]-a[1])*(-half-a[0])/(b[0]-a[0])]],
    [p=>p[0]<=half+EPS,(a,b)=>[half,a[1]+(b[1]-a[1])*(half-a[0])/(b[0]-a[0])]],
    [p=>p[1]>=-half-EPS,(a,b)=>[a[0]+(b[0]-a[0])*(-half-a[1])/(b[1]-a[1]),-half]],
    [p=>p[1]<=half+EPS,(a,b)=>[a[0]+(b[0]-a[0])*(half-a[1])/(b[1]-a[1]),half]]
  ]) {
    if(!out.length)break;
    const next=[];let a=out.at(-1);
    for(const b of out) {
      const was=inside(a),now=inside(b);
      if(was!==now)next.push(intersection(a,b));
      if(now)next.push(b);
      a=b;
    }
    out=next;
  }
  return out;
}
function onBorder([x,z]) {return Math.abs(Math.abs(x)-HALF)<1e-5||Math.abs(Math.abs(z)-HALF)<1e-5;}
function pointInRing(p,ring) {
  let inside=false;
  for(let i=0,j=ring.length-1;i<ring.length;j=i++) {
    const a=ring[i],b=ring[j];
    if((a[1]>p[1])!==(b[1]>p[1])&&
      p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0])inside=!inside;
  }
  return inside;
}
function extractFootprints(geometry) {
  if(!geometry||!['Polygon','MultiPolygon'].includes(geometry.type))return [];
  const polygons=geometry.type==='Polygon'?[geometry.coordinates]:geometry.coordinates;
  if(!Array.isArray(polygons)||polygons.length>1000)throw Error('建築包含不合法的 MultiPolygon');
  const result=[];
  for(const polygon of polygons) {
    if(!Array.isArray(polygon)||!polygon.length||polygon.length>200)continue;
    const toLocal=raw => {
      if(!Array.isArray(raw)||raw.length>MAX_RING)throw Error('原始建築輪廓節點過多');
      return raw.map(p=>longitudeLatitudeToMeters(p));
    };
    const originalOuter=toLocal(polygon[0]);
    const outer=normalizeRing(clipBuildingRing(originalOuter),true);
    if(outer.length<3||Math.abs(ringArea(outer))<2)continue;
    const holes=[];let uncertain=false;
    for(const raw of polygon.slice(1)) {
      const originalHole=toLocal(raw);
      // Holes crossing the bbox can change topology from ring to notch.
      // Skip the entire uncertain polygon rather than inventing a solid wall.
      const hole=normalizeRing(clipBuildingRing(originalHole),false);
      if(hole.length<3)continue;
      if(hole.some(onBorder)||!hole.every(p=>pointInRing(p,outer))){uncertain=true;break;}
      if(Math.abs(ringArea(hole))>=2)holes.push(hole);
    }
    if(!uncertain)result.push({outer,holes});
  }
  return result;
}
export function buildingHeight(props={}) {
  const floor=Number.isInteger(props.num_floors)&&props.num_floors>0&&props.num_floors<=100
    ? props.num_floors : null;
  const sourceHeight=typeof props.height==='number'&&finite(props.height)&&props.height>=1&&props.height<=350
    ? props.height : null;
  const sourceMin=typeof props.min_height==='number'&&finite(props.min_height)&&props.min_height>=0&&props.min_height<=250
    ? props.min_height : null;
  const baseMeters=sourceMin??(Number.isInteger(props.min_floor)&&props.min_floor>0&&props.min_floor<=80
    ? props.min_floor*3.2 : 0);
  const subtype=typeof props.subtype==='string'?props.subtype:'';
  const guesses={residential:9.6,commercial:12,industrial:7,service:5,transportation:11,
    civic:12,agricultural:5,religious:10,education:12,garage:3.5};
  const heightMeters=sourceHeight??(floor?floor*3.2:guesses[subtype]??9.6);
  return {heightMeters:Number(heightMeters.toFixed(2)),baseMeters:Number(baseMeters.toFixed(2)),
    heightSource:sourceHeight!==null?'height':floor?'floors':'estimated',floors:floor};
}
export function prepareOvertureBuildingMap(input,options={}) {
  if(input?.type!=='FeatureCollection'||!Array.isArray(input.features))throw Error('輸入必須是 Overture building GeoJSON FeatureCollection');
  if(input.features.length>LIMIT)throw Error('Overture building 資料量超過安全限制');
  const buildings=[];const seen=new Set();let skipped=0;
  for(const feature of input.features) {
    if(feature?.type!=='Feature')continue;
    const props=feature.properties||{};
    // overturemaps-py GeoJSON export (including v1.0.2) writes the source
    // partition's theme/type in the dataset path, not always in properties.
    // Treat wrong *present* values as a hard error, but do not require them.
    if((props.theme!==undefined&&props.theme!=='buildings')||
       (props.type!==undefined&&props.type!=='building'))
      throw Error('GeoJSON 含有非 Overture buildings/building 特徵');
    // Overture building has a mandatory numeric schema version; this catches
    // ordinary GeoJSON without accidentally rejecting the official writer.
    // Schema checks cannot authenticate a file's origin: the official fetch
    // path supplies provenance via record_batch_reader('building').
    if(!Number.isSafeInteger(props.version)||props.version<0)
      throw Error('缺少 Overture feature 的有效 version；請使用官方 building GeoJSON');
    const id=props.id??feature.id;
    if(typeof id!=='string'||!id||id.length>300)throw Error('Overture building 缺少有效 id');
    if(seen.has(id))throw Error('重複 Overture building ID: '+id);
    seen.add(id);
    if(props.is_underground===true){skipped++;continue;}
    const polygons=extractFootprints(feature.geometry);
    if(!polygons.length){skipped++;continue;}
    const name=typeof props.names?.primary==='string'?props.names.primary.slice(0,120):null;
    const {heightMeters,baseMeters,heightSource,floors}=buildingHeight(props);
    buildings.push({id,polygons,heightMeters,baseMeters,heightSource,floors,name,
      subtype:typeof props.subtype==='string'?props.subtype.slice(0,48):null,
      buildingClass:typeof props.class==='string'?props.class.slice(0,48):null});
  }
  const result={format:CITY_BUILDING_FORMAT,area:{...TAINAN_STATION},
    source:{provider:'Overture Maps Foundation',theme:'buildings',type:'building',license:'ODbL-1.0',
      attribution:OVERTURE_ATTRIBUTION,release:options.release||'latest-via-STAC',
      downloadedAt:options.downloadedAt||new Date().toISOString(),
      note:'真實輪廓；heightSource=height 為來源高度，floors／estimated 均為工程估高（非實測）'},
    buildings,conversion:{inputFeatures:input.features.length,skippedFeatures:skipped}};
  return validateBuildingMap(result);
}
export function validateBuildingMap(map) {
  if(map?.format!==CITY_BUILDING_FORMAT||!Array.isArray(map.buildings)||
     map.buildings.length>LIMIT||map?.source?.provider!=='Overture Maps Foundation'||
     map.source.theme!=='buildings'||map.source.license!=='ODbL-1.0'||
     !map.source.attribution?.includes('OpenStreetMap'))throw Error('建築資料格式或授權欄位無效');
  if(Math.abs(map.area?.latitude-TAINAN_STATION.latitude)>1e-9||
     Math.abs(map.area?.longitude-TAINAN_STATION.longitude)>1e-9||
     map.area?.widthMeters!==2000||map.area?.heightMeters!==2000)throw Error('建築與道路地理原點不相符');
  const ids=new Set();let vertexCount=0;
  for(const b of map.buildings) {
    if(typeof b?.id!=='string'||!b.id||ids.has(b.id)||!Array.isArray(b.polygons)||
      !b.polygons.length||b.polygons.length>1000||!finite(b.heightMeters)||
      b.heightMeters<1||b.heightMeters>350||!finite(b.baseMeters)||
      b.baseMeters<0||b.baseMeters>250||!['height','floors','estimated'].includes(b.heightSource))
      throw Error('建築識別、海拔、估高來源或輪廓格式不合法');
    ids.add(b.id);
    for(const polygon of b.polygons) {
      if(!Array.isArray(polygon?.outer)||!Array.isArray(polygon.holes)||
        polygon.outer.length<3||polygon.outer.length>MAX_RING||polygon.holes.length>200)
        throw Error('建築多邊形無效');
      const rings=[polygon.outer,...polygon.holes];
      for(const ring of rings){
        if(!Array.isArray(ring)||ring.length<3||ring.length>MAX_RING)throw Error('不合法建築內外環');
        vertexCount+=ring.length;
        for(const pt of ring) if(!Array.isArray(pt)||pt.length!==2||!pt.every(finite)||
          Math.abs(pt[0])>HALF+.001||Math.abs(pt[1])>HALF+.001)
          throw Error('建築座標超出 2x2 公里範圍');
      }
      if(ringArea(polygon.outer)<2||polygon.holes.some(h=>ringArea(h)>-.05))
        throw Error('建築多邊形方向、面積或內院裁切不合法');
    }
    if(vertexCount>LIMIT_VERTICES)throw Error('建築總頂點超出安全限額');
  }
  return map;
}
export function buildingStatistics(map) {
  validateBuildingMap(map);
  const counts={height:0,floors:0,estimated:0};let polygons=0,roofArea=0;
  for(const b of map.buildings){counts[b.heightSource]++;polygons+=b.polygons.length;
    for(const p of b.polygons)roofArea+=Math.abs(ringArea(p.outer))-
      p.holes.reduce((s,h)=>s+Math.abs(ringArea(h)),0);}
  return {buildings:map.buildings.length,polygons,sourceHeight:counts.height,
    floorEstimated:counts.floors,defaultEstimated:counts.estimated,
    roofAreaSqm:Math.round(roofArea)};
}
