// V1.9.6: Overture connector-aware metric XYZ geometry and estimated level profiles.
// No synthetic streets: junctions are created only at validated vehicle connectors.
import {applyCityRoadElevations,corridorLevelIntervals} from './city-road-elevation.mjs';
import {CITY_ROAD_Y} from './city-vertical-datum.mjs';
export {CITY_ROAD_Y} from './city-vertical-datum.mjs';
// This module is independent of Three/Rapier so geometry can be regression tested.

const EPS = 1e-6;
const GRID_METERS = 50;
const TILE_METERS = 180;
const MAX_JOIN_DIST = 0.75; // reject orphaned refs from clipped GeoJSON
const hypot = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
const clamp = (v, low, high) => Math.max(low, Math.min(high, v));

function centerline(path) {
  const points = [];
  for (const value of path) if (!points.length || hypot(points.at(-1), value) > .00001) points.push(value);
  if (points.length < 2) return null;
  const distances = [0];
  for (let i = 1; i < points.length; i++) distances.push(distances.at(-1) + hypot(points[i - 1], points[i]));
  return distances.at(-1) > .2 ? {points, distances, length: distances.at(-1)} : null;
}
export function atDistance(line, s) {
  const pos = clamp(s, 0, line.length);
  let lo = 0, hi = line.distances.length - 1;
  while (lo < hi) {const m = (lo + hi) >> 1; if (line.distances[m] < pos) lo = m + 1; else hi = m;}
  const i = Math.max(1, lo), a = line.points[i - 1], b = line.points[i];
  const len = line.distances[i] - line.distances[i - 1];
  const t = len < EPS ? 0 : (pos - line.distances[i - 1]) / len;
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
}
function projectToLine(line, point) {
  let best = {distance: Infinity, along: 0};
  for (let i = 1; i < line.points.length; i++) {
    const a = line.points[i - 1], b = line.points[i];
    const dx = b[0] - a[0], dz = b[1] - a[1], lensq = dx * dx + dz * dz;
    const t = clamp(lensq > EPS ? ((point[0] - a[0]) * dx + (point[1] - a[1]) * dz) / lensq : 0, 0, 1);
    const x = a[0] + t * dx, z = a[1] + t * dz, distance = Math.hypot(point[0] - x, point[1] - z);
    if (distance < best.distance) best = {distance, along: line.distances[i - 1] + Math.sqrt(lensq) * t};
  }
  return best;
}
export function subline(line, a, b, first, last) {
  const result = [first || atDistance(line, a)];
  for (let i = 1; i < line.points.length - 1; i++) {
    if (line.distances[i] > a + 1e-4 && line.distances[i] < b - 1e-4) result.push(line.points[i]);
  }
  result.push(last || atDistance(line, b));
  return result;
}
function roadCategory(s) {
  if (['motorway', 'trunk', 'primary', 'secondary'].includes(s.roadClass)) return 'major';
  if (['residential', 'tertiary'].includes(s.roadClass)) return 'normal';
  return 'minor';
}
function hull(points) {
  const sorted = [...points].sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cross = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
  const lower = [], upper = [];
  for (const p of sorted) {while (lower.length > 1 && cross(lower.at(-2), lower.at(-1), p) <= 1e-8) lower.pop(); lower.push(p);}
  for (const p of sorted.slice().reverse()) {while (upper.length > 1 && cross(upper.at(-2), upper.at(-1), p) <= 1e-8) upper.pop(); upper.push(p);}
  return lower.slice(0, -1).concat(upper.slice(0, -1));
}
export function regularize(points, step = 10) {
  const out = [points[0]];
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1], b = points[i], dist = hypot(a, b);
    const n = Math.max(1, Math.ceil(dist / step));
    for (let j = 1; j <= n; j++) {
      const t = j / n;
      out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
    }
  }
  return out;
}
export function stripSides(path, half) {
  const left = [], right = [];
  for (let i = 0; i < path.length; i++) {
    const before = path[Math.max(0, i - 1)], current = path[i], after = path[Math.min(path.length - 1, i + 1)];
    const d0x = current[0] - before[0], d0z = current[1] - before[1];
    const d1x = after[0] - current[0], d1z = after[1] - current[1];
    const l0 = Math.hypot(d0x, d0z), l1 = Math.hypot(d1x, d1z);
    const n0 = l0 > EPS ? [-d0z / l0, d0x / l0] : [-d1z / Math.max(EPS, l1), d1x / Math.max(EPS, l1)];
    const n1 = l1 > EPS ? [-d1z / l1, d1x / l1] : n0;
    const midx = n0[0] + n1[0], midz = n0[1] + n1[1];
    const midLen = Math.hypot(midx, midz);
    let offset;
    if (midLen < .08) offset = [n1[0] * half, n1[1] * half];
    else {
      const ux = midx / midLen, uz = midz / midLen;
      const miter = clamp(half / Math.max(.3, ux * n1[0] + uz * n1[1]), half, half * 2.2);
      offset = [ux * miter, uz * miter];
    }
    left.push([current[0] + offset[0], current[1] + offset[1]]);
    right.push([current[0] - offset[0], current[1] - offset[1]]);
  }
  return {left, right};
}
function categoryForJunction(node) {
  return node.arms.some(a => a.category === 'major') ? 'major' :
    node.arms.some(a => a.category === 'normal') ? 'normal' : 'minor';
}

export function buildCityRoadGeometry(map, {elevationMode = 'source-levels'} = {}) {
  const connectors = new Map(map.connectors.map(c => [c.id, c.coordinates]));
  const nodes = new Map(), corridors = [];
  let ignoredConnectorRefs = 0, validatedConnectorRefs = 0;
  function nodeById(id, coordinates) {
    if (!nodes.has(id)) nodes.set(id, {id, point: coordinates, arms: []});
    return nodes.get(id);
  }
  for (const segment of map.segments) {
    if (segment.use !== 'vehicle') continue;
    const line = centerline(segment.coordinates);
    if (!line) continue;
    const stations = [{along: 0, id: null}, {along: line.length, id: null}];
    for (const ref of segment.connectorRefs) {
      const point = connectors.get(ref.id);
      if (!point) {ignoredConnectorRefs++; continue;}
      // A clipped Overture feature can carry connector refs from its ORIGINAL
      // unclipped centerline. Trust the physical location, not the stale 'at'.
      const projected = projectToLine(line, point);
      if (projected.distance > MAX_JOIN_DIST) {ignoredConnectorRefs++; continue;}
      validatedConnectorRefs++;
      stations.push({along: projected.along, id: ref.id, point});
    }
    stations.sort((a, b) => a.along - b.along || Number(Boolean(b.id)) - Number(Boolean(a.id)));
    const selected = [];
    for (const station of stations) {
      const last = selected.at(-1);
      if (last && Math.abs(station.along - last.along) < .08) {
        if (station.id && !last.id) Object.assign(last, station);
      } else selected.push({...station});
    }
    for (let i = 0; i < selected.length; i++) {
      const station = selected[i];
      if (!station.id) station.id = `end:${segment.id}:${i}`;
      if (!station.point) station.point = atDistance(line, station.along);
      nodeById(station.id, station.point);
    }
    for (let i = 1; i < selected.length; i++) {
      const first = selected[i - 1], last = selected[i];
      if (last.along - first.along < .35) continue;
      const points = subline(line, first.along, last.along, first.point, last.point);
      const edgeLine = centerline(points);
      if (!edgeLine || edgeLine.length < .35) continue;
      const corridor = {id: `${segment.id}@${i}`, sourceId: segment.sourceId,
        name: segment.name, roadClass: segment.roadClass, category: roadCategory(segment),
        widthMeters: segment.widthMeters,
        levelIntervals: corridorLevelIntervals(segment,first.along,last.along,line.length),
        widthSource: (segment.widthRules || []).some(rule =>
          Number.isFinite(rule?.value) && !rule.between && !rule.when &&
          Math.abs(rule.value - segment.widthMeters) < 1e-5) ? 'source-rule' : 'estimated-class',
        points, line: edgeLine, length: edgeLine.length,
        // Stable distance on the unpartitioned segment for marking phase.
        sourceStartMeters: first.along,
        from: first.id, to: last.id, trims: [0, 0]};
      corridors.push(corridor);
      const p0 = points[0], p1 = points[1], pn = points.at(-1), prev = points.at(-2);
      const addArm = (id, fromStart, vector) => {
        const mag = Math.hypot(...vector);
        nodes.get(id).arms.push({edge: corridor, fromStart,
          direction: [vector[0] / mag, vector[1] / mag],
          category: corridor.category, widthMeters: corridor.widthMeters});
      };
      addArm(corridor.from, true, [p1[0] - p0[0], p1[1] - p0[1]]);
      addArm(corridor.to, false, [prev[0] - pn[0], prev[1] - pn[1]]);
    }
  }
  // Trims are geometric lengths that a shared junction hull occupies. A ramp
  // cannot spend its available grade INSIDE that landing or its cap and the
  // junction surface would be different heights. Solve elevation afterwards.
  const junctions = [];
  for (const node of nodes.values()) {
    if (node.arms.length < 2) continue;
    const radius = clamp(Math.max(...node.arms.map(a => a.widthMeters)) *
      (node.arms.length >= 3 ? .92 : .53), 2, 11);
    for (const arm of node.arms) {
      const trim = Math.min(radius, arm.edge.length * .36);
      arm.edge.trims[arm.fromStart ? 0 : 1] = trim;
    }
    junctions.push({id: node.id, point: node.point,
      height: CITY_ROAD_Y,
      type: node.arms.length === 3 ? 'T' : node.arms.length === 4 ? 'cross' :
        node.arms.length === 2 ? 'join' : 'complex',
      degree: node.arms.length, category: categoryForJunction(node), node});
  }
  // Connector-linked ramps spend their gradient only OUTSIDE the real
  // geometric junction trim. This makes every approach cap exactly level
  // with its connector without compressing slopes into implausibly steep
  // short segments. Grade-separated XY crossings remain disconnected.
  const elevationStats=applyCityRoadElevations(corridors,{mode:elevationMode});
  for(const junction of junctions)
    junction.height=junction.node.arms[0].edge.heightAt(
      junction.node.arms[0].fromStart?0:junction.node.arms[0].edge.length);
  // Tessellated triangles are partitioned by XY tile. Each physical tile gets
  // one Rapier collider; Three receives the exact same vertex/index buffers.
  const tiles = new Map();
  function pushTri(a, b, c, category, ya=CITY_ROAD_Y, yb=CITY_ROAD_Y, yc=CITY_ROAD_Y) {
    if (![...a, ...b, ...c, ya, yb, yc].every(Number.isFinite)) throw Error('路面含非有限座標');
    // Real centerlines contain acute hairpins; miters can flip triangle
    // orientation. Keep all triangles upward-facing for physical consistency.
    const signed = (b[1] - a[1]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[1] - a[1]);
    if (Math.abs(signed) < 1e-8) return;
    if (signed < 0) {[b, c] = [c, b];[yb, yc] = [yc, yb];}
    const cx = (a[0] + b[0] + c[0]) / 3, cz = (a[1] + b[1] + c[1]) / 3;
    const col = Math.floor((cx + 1100) / TILE_METERS), row = Math.floor((cz + 1100) / TILE_METERS);
    const key = `${col}:${row}:${category}`;
    if (!tiles.has(key)) tiles.set(key, {key, category, vertices: [], indices: []});
    const batch = tiles.get(key), i = batch.vertices.length / 3;
    batch.vertices.push(a[0], ya, a[1], b[0], yb, b[1], c[0], yc, c[1]);
    batch.indices.push(i, i + 1, i + 2);
  }
  for (const edge of corridors) {
    const [start, end] = edge.trims;
    const subset = subline(edge.line, start, edge.length - end);
    // Sample curved ramps more finely; entirely at-grade roads keep V1.9.5
    // triangle counts and XY positions unchanged for compatibility.
    const elevated = elevationMode==='source-levels' &&
      (Math.abs(edge.heightOffsetAt(start))>.001 ||
       Math.abs(edge.heightOffsetAt(edge.length-end))>.001 || edge.levelIntervals.length>0);
    const path = regularize(subset,elevated?4:10);
    const {left, right} = stripSides(path, edge.widthMeters / 2);
    const heights = [edge.heightAt(start)];
    let along = start;
    for (let i = 1; i < path.length; i++) {
      along += hypot(path[i-1],path[i]);
      heights.push(edge.heightAt(Math.min(edge.length,along)));
    }
    for (let i = 1; i < path.length; i++) {
      pushTri(left[i - 1], left[i], right[i - 1], edge.category,
        heights[i-1],heights[i],heights[i-1]);
      pushTri(right[i - 1], left[i], right[i], edge.category,
        heights[i-1],heights[i],heights[i]);
    }
    edge.caps = [{left: left[0], right: right[0],height:heights[0]},
      {left: left.at(-1), right: right.at(-1),height:heights.at(-1)}];
  }
  for (const junction of junctions) {
    const corners = [junction.point];
    for (const arm of junction.node.arms) {
      const cap = arm.edge.caps[arm.fromStart ? 0 : 1];
      corners.push(cap.left, cap.right);
    }
    const polygon = hull(corners);
    if (polygon.length < 3) continue;
    junction.polygon = polygon;
    const heightOf = p => {
      // The convex hull can contain points at different heights: cap edges
      // continue the approach ramp, connector center is topologically shared.
      if (hypot(p,junction.point)<.0001) return junction.height;
      for (const arm of junction.node.arms) {
        const cap=arm.edge.caps[arm.fromStart?0:1];
        if (hypot(p,cap.left)<.0001 || hypot(p,cap.right)<.0001) return cap.height;
      }
      return junction.height;
    };
    const sloped = Math.abs(junction.height-CITY_ROAD_Y)>.0001 ||
      junction.node.arms.some(arm=>Math.abs(arm.edge.caps[arm.fromStart?0:1].height-
        junction.height)>.0001);
    if (sloped) {
      // Join all approaches through the true connector's 3D surface point.
      // A fan anchored to a polygon corner can put a sloped junction centre
      // beneath/above its connector, even though boundary caps match.
      for(let i=0;i<polygon.length;i++){
        const next=(i+1)%polygon.length;
        pushTri(junction.point,polygon[next],polygon[i],junction.category,
          junction.height,heightOf(polygon[next]),heightOf(polygon[i]));
      }
    } else for (let i = 1; i < polygon.length - 1; i++) {
      // Preserve the unchanged V1.9.5 at-grade topology and index buffers.
      pushTri(polygon[0], polygon[i + 1], polygon[i], junction.category);
    }
  }
  // Grid index for local nearest-road projection; no global O(edges) search
  // during each 120 Hz physics step. This does not create or invent routes.
  const cells = new Map(), spans = [];
  for (const edge of corridors) {
    const p = edge.points;
    let traveled = 0;
    for (let i = 1; i < p.length; i++) {
      const a = p[i - 1], b = p[i], len = hypot(a, b);
      if (len < EPS) continue;
      const span = {a, b, dx: b[0] - a[0], dz: b[1] - a[1], length: len,
        edge, traveled};
      const idx = spans.push(span) - 1;
      const margin = Math.max(3, edge.widthMeters / 2);
      const xmin = Math.floor((Math.min(a[0], b[0]) - margin) / GRID_METERS);
      const xmax = Math.floor((Math.max(a[0], b[0]) + margin) / GRID_METERS);
      const zmin = Math.floor((Math.min(a[1], b[1]) - margin) / GRID_METERS);
      const zmax = Math.floor((Math.max(a[1], b[1]) + margin) / GRID_METERS);
      for (let x = xmin; x <= xmax; x++) for (let z = zmin; z <= zmax; z++) {
        const key = x + ':' + z;
        if (!cells.has(key)) cells.set(key, []);
        cells.get(key).push(idx);
      }
      traveled += len;
    }
  }
  function closestRoad(x, z, maxDistance = 90, elevationHint = null) {
    if (!Number.isFinite(x) || !Number.isFinite(z)) return null;
    const gx = Math.floor(x / GRID_METERS), gz = Math.floor(z / GRID_METERS);
    const r = Math.ceil(maxDistance / GRID_METERS);
    let best = null;
    const seen = new Set();
    for (let ix = gx - r; ix <= gx + r; ix++) for (let iz = gz - r; iz <= gz + r; iz++) {
      for (const idx of cells.get(ix + ':' + iz) || []) {
        if (seen.has(idx)) continue;
        seen.add(idx);
        const item = spans[idx], {a, dx, dz, length} = item;
        const t = clamp(((x - a[0]) * dx + (z - a[1]) * dz) / (length * length), 0, 1);
        const px = a[0] + dx * t, pz = a[1] + dz * t;
        const distance = Math.hypot(px - x, pz - z);
        const along=item.traveled + length*t;
        const y=item.edge.heightAt(along);
        // A 2D crossing can contain two decks. When a vehicle's altitude is
        // known, prefer a surface at the same level without snapping a bridge
        // car to the at-grade route underneath.
        const score=distance+(Number.isFinite(elevationHint)?
          Math.max(0,Math.abs(y-elevationHint)-.8)*1.8:0);
        if (!best || score < best.score) {
          const heading = Math.atan2(dx, dz);
          best = {x: px, y, z: pz, heading, grade: item.edge.gradeAt(along),score,
            offset: (x - px) * Math.cos(heading) - (z - pz) * Math.sin(heading),
            distance, widthMeters: item.edge.widthMeters, roadClass: item.edge.roadClass, widthSource: item.edge.widthSource,
            sourceId: item.edge.sourceId, edgeId: item.edge.id,
            s: along};
        }
      }
    }
    return best && best.distance <= maxDistance ? best : null;
  }
  function pickSpawn() {
    const priority = {primary: 0, secondary: 0, tertiary: 0, residential: 0, unclassified: 2, service: 10};
    const suitable = corridors.filter(e => e.length >= 22 && e.widthMeters >= 5.5);
    suitable.sort((a, b) => {
      const score = e => {
        const point = atDistance(e.line, e.length * .5);
        return Math.hypot(...point) + (priority[e.roadClass] ?? 12) * 250 +
          (e.length < 36 ? 150 : 0);
      };
      return score(a) - score(b);
    });
    const edge = suitable[0] || [...corridors].sort((a, b) => b.length - a.length)[0];
    if (!edge) throw Error('無可用的 Overture 車行道路可放置車輛');
    const at = atDistance(edge.line, edge.length * .5);
    const p1 = atDistance(edge.line, Math.max(0, edge.length * .5 - 1));
    const p2 = atDistance(edge.line, Math.min(edge.length, edge.length * .5 + 1));
    return {x: at[0], z: at[1], y: edge.heightAt(edge.length*.5),
      grade: edge.gradeAt(edge.length*.5),
      heading: Math.atan2(p2[0] - p1[0], p2[1] - p1[1]), s: 0,
      name: edge.name, sourceId: edge.sourceId, roadClass: edge.roadClass};
  }
  const stats = {corridors: corridors.length, junctions: junctions.length,
    corridorsWithSourceWidth: corridors.filter(e => e.widthSource === 'source-rule').length,
    corridorsWithEstimatedWidth: corridors.filter(e => e.widthSource !== 'source-rule').length,
    tJunctions: junctions.filter(j => j.type === 'T').length,
    crossJunctions: junctions.filter(j => j.type === 'cross').length,
    complexJunctions: junctions.filter(j => j.type === 'complex').length,
    ignoredConnectorRefs, validatedConnectorRefs,
    ...elevationStats,
    collisionTiles: tiles.size,
    triangles: [...tiles.values()].reduce((sum, t) => sum + t.indices.length / 3, 0)};
  return {corridors, junctions, tiles, stats, closestRoad, pickSpawn};
}
