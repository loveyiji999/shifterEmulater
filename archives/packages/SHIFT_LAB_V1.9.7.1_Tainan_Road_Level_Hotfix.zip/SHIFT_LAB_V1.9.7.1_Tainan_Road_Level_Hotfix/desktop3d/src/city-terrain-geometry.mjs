// V1.9.6: physical ground EXCAVATION around estimated below-grade roads.
// The existing solid 2x2 km ground collider made underpasses impassable.
// A shared, locally cut upper-soil mesh is now used for BOTH Three and Rapier.
// Cut-outs are conservative (wider than the road), not surveyed earthworks.
// Bridge decks have no hidden road-shaped ground volume beneath them.
import {atDistance} from './city-road-geometry.mjs';
import {CITY_GROUND_Y,CITY_ROAD_Y} from './city-vertical-datum.mjs';

const HALF = 1000;
const GROUND_Y = CITY_GROUND_Y;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export function buildCityTerrainGeometry(roadModel, {cellMeters=10} = {}) {
  if (!roadModel?.corridors) throw Error('地面開挖需要有效的 Overture 道路模型');
  if (!Number.isInteger(cellMeters)||cellMeters<5||cellMeters>40||2000%cellMeters!==0)
    throw Error('地面網格步長必須可整除 2000 m，並介於 5 至 40 m');
  const n = 2000/cellMeters;
  const excluded = new Uint8Array(n*n);
  let excavatedRoadSamples=0;
  // Mark entire 10m cells around every below-ground wheel path. The buffer
  // accounts for the whole road half-width, coarse soil triangulation and
  // lateral wheel positions; it is NOT a claim about actual tunnel width.
  for (const edge of roadModel.corridors) {
    const lowSample=Math.min(edge.heightAt(0),edge.heightAt(edge.length*.5),
      edge.heightAt(edge.length));
    if (!edge.levelIntervals.some(rule=>rule.height<0) &&
      lowSample>=GROUND_Y+(CITY_ROAD_Y-GROUND_Y)*.5) continue;
    const samples = Math.max(1,Math.ceil(edge.length/3));
    for (let k=0;k<=samples;k++) {
      const along=edge.length*k/samples;
      const roadY=edge.heightAt(along);
      // Excavation is required only where the driving surface actually
      // approaches/passes the ground plane. Comparing to the old .055m
      // constant would now excavate ordinary Y=0.025m city streets.
      if (roadY >= GROUND_Y+(CITY_ROAD_Y-GROUND_Y)*.5) continue;
      excavatedRoadSamples++;
      const [x,z]=atDistance(edge.line,along);
      const margin=edge.widthMeters*.5+cellMeters*.72+2.5;
      const minX=clamp(Math.floor((x-margin+HALF)/cellMeters),0,n-1);
      const maxX=clamp(Math.floor((x+margin+HALF)/cellMeters),0,n-1);
      const minZ=clamp(Math.floor((z-margin+HALF)/cellMeters),0,n-1);
      const maxZ=clamp(Math.floor((z+margin+HALF)/cellMeters),0,n-1);
      for(let ix=minX;ix<=maxX;ix++)for(let iz=minZ;iz<=maxZ;iz++){
        const cx=-HALF+(ix+.5)*cellMeters,cz=-HALF+(iz+.5)*cellMeters;
        if(Math.hypot(cx-x,cz-z)<=margin+cellMeters*.36)
          excluded[ix*n+iz]=1;
      }
    }
  }
  const vertices=[];
  for(let ix=0;ix<=n;ix++)for(let iz=0;iz<=n;iz++)
    vertices.push(-HALF+ix*cellMeters,GROUND_Y,-HALF+iz*cellMeters);
  const indices=[];
  let holes=0;
  for(let ix=0;ix<n;ix++)for(let iz=0;iz<n;iz++){
    if(excluded[ix*n+iz]){holes++;continue;}
    const a=ix*(n+1)+iz,b=a+1,c=(ix+1)*(n+1)+iz,d=c+1;
    indices.push(a,b,c,c,b,d);
  }
  // The bottom plane is a recovery floor, not a claimed real tunnel lining.
  // It sits below every below-grade roadway; it is the only soil underneath
  // a cut-out, so it cannot obstruct a downward ramp.
  const recoveryY=Math.min(-1.5,roadModel.stats.minimumOffsetMeters-2.0);
  return {vertices,indices,cellMeters,holes,excavatedRoadSamples,recoveryY,
    groundY:GROUND_Y,cutAt(x,z){
      const ix=Math.floor((x+HALF)/cellMeters),iz=Math.floor((z+HALF)/cellMeters);
      return ix>=0&&ix<n&&iz>=0&&iz<n&&!!excluded[ix*n+iz];
    },stats:{terrainTriangles:indices.length/3,excavatedCells:holes,
      recoveryFloorMeters:Number(recoveryY.toFixed(2)),
      terrainEvidence:'estimated soil cutouts; no DEM, tunnel ceiling or surveyed excavation'}};
}
