// V1.9.4 metric street-detail visualisation. These meshes DO NOT introduce
// collision geometry or claim surveyed lanes, curb height or sidewalk widths.
// The original Overture-derived asphalt mesh is the sole Rapier road authority.
import {CITY_ROAD_Y, regularize, stripSides, subline} from './city-road-geometry.mjs';
import {createRoadTriangleIndex, pointOnAsphalt} from './city-street-audit.mjs';

const EPS = 0.000001;
const PAINT_Y = CITY_ROAD_Y + 0.012;
const CURB_TOP = CITY_ROAD_Y + 0.075;
const SIDEWALK_Y = CITY_ROAD_Y + 0.065;
const SIDEWALK_WIDTH = 1.12; // VISUAL engineering estimate, never Overture survey.
const CURB_WIDTH = 0.14;
const DASH_LENGTH = 3.0;
const DASH_REPEAT = 8.0;

function triangle(batch, a, b, c) {
  // Non-indexed triangles: mesh is render-only. Skips degenerate triangles.
  const twiceArea = (b[0] - a[0]) * (c[2] - a[2]) - (b[2] - a[2]) * (c[0] - a[0]);
  if (Math.abs(twiceArea) < EPS) return;
  batch.vertices.push(...a, ...b, ...c);
  batch.triangles++;
}
function ribbon(batch, a, b, c, d) {
  triangle(batch,a,b,c);triangle(batch,c,b,d);
}
function newBatch(){return {vertices:[], triangles:0};}
function stripAt(batch, inSide, outSide, y) {
  for(let i=1;i<inSide.length;i++) ribbon(batch,
    [inSide[i-1][0],y,inSide[i-1][1]],
    [outSide[i-1][0],y,outSide[i-1][1]],
    [inSide[i][0],y,inSide[i][1]],
    [outSide[i][0],y,outSide[i][1]]);
}
function ribbonAt(batch,inner0,outer0,inner1,outer1,y){
  ribbon(batch,[inner0[0],y,inner0[1]],[outer0[0],y,outer0[1]],
    [inner1[0],y,inner1[1]],[outer1[0],y,outer1[1]]);
}
function wallAt(batch,p0,p1){
  ribbon(batch,[p0[0],CITY_ROAD_Y+.002,p0[1]],[p0[0],CURB_TOP,p0[1]],
    [p1[0],CITY_ROAD_Y+.002,p1[1]],[p1[0],CURB_TOP,p1[1]]);
}
const hashText=s=>{let h=2166136261;for(let i=0;i<s.length;i++)h=Math.imul(h^s.charCodeAt(i),16777619);return h>>>0;};
const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
// Decorative ribbons remain collision-free, but their Y now follows the
// EXACT owning asphalt corridor rather than a global flat road constant.
function projectHeight(edge,x,z){
  let best=Infinity,height=CITY_ROAD_Y;
  for(let i=1;i<edge.line.points.length;i++){
    const a=edge.line.points[i-1],b=edge.line.points[i];
    const dx=b[0]-a[0],dz=b[1]-a[1],len=dx*dx+dz*dz;
    const t=clamp(len>EPS?((x-a[0])*dx+(z-a[1])*dz)/len:0,0,1);
    const px=a[0]+dx*t,pz=a[1]+dz*t,d2=(x-px)**2+(z-pz)**2;
    if(d2<best){best=d2;height=edge.heightAt(edge.line.distances[i-1]+Math.sqrt(len)*t);}
  }
  return {height,distanceSquared:best};
}
function appendHeightDeltas(groups,starts,edges){
  for(const [name,batch] of Object.entries(groups)){
    const vertices=batch.vertices;
    for(let i=starts[name];i<vertices.length;i+=3){
      let nearest=null;
      for(const edge of edges){
        const sample=projectHeight(edge,vertices[i],vertices[i+2]);
        if(!nearest||sample.distanceSquared<nearest.distanceSquared)nearest=sample;
      }
      vertices[i+1]+=nearest.height-CITY_ROAD_Y;
    }
  }
}
function batchStarts(groups){return Object.fromEntries(Object.entries(groups).map(([key,v])=>[key,v.vertices.length]));}
function safeEnds(edge,junctionById,kind){
  const clearance=id=>{
    const j=junctionById.get(id);
    if(!j)return 0;
    if(j.degree===2)return kind==='paint' ? .60 : .15;
    const width=Math.max(...j.node.arms.map(a=>a.widthMeters));
    // The source has no surveyed curb radii or junction line markings.
    // Reserve a small unpainted/set-back approach, separate from junction trims.
    return kind==='paint' ? clamp(.75+width*.21,1.1,3.0) : clamp(.15+width*.12,.4,1.4);
  };
  return [Math.min(edge.length*.15,clearance(edge.from)),Math.min(edge.length*.15,clearance(edge.to))];
}
function drawDashes(batch,edge,junctionById){
  const [fromClear,toClear]=safeEnds(edge,junctionById,'paint');
  const first=edge.trims[0]+fromClear+.5,last=edge.length-edge.trims[1]-toClear-.5;
  if(last-first<1.6)return 0;
  // Phase advances across connector-split corridors of the SAME Overture
  // segment. V1.9.4 reset this phase on every corridor at a junction.
  const absoluteStart=edge.sourceStartMeters??0;
  const phase=(hashText(edge.sourceId||edge.id)%800)/100;
  const k0=Math.floor((absoluteStart+first-phase)/DASH_REPEAT);
  let painted=0;
  for(let k=k0;k<k0+Math.ceil((last-first)/DASH_REPEAT)+3;k++){
    const from=Math.max(first,k*DASH_REPEAT+phase-absoluteStart);
    const to=Math.min(last,k*DASH_REPEAT+phase+DASH_LENGTH-absoluteStart);
    if(to-from<.65)continue;
    const pts=regularize(subline(edge.line,from,to),2);
    const {left,right}=stripSides(pts,.055);
    stripAt(batch,left,right,PAINT_Y);painted+=to-from;
  }
  return painted;
}
function hasEstimatedSidewalk(edge) {
  // Do not invent at-grade sidewalks on a raised bridge deck or excavated
  // underpass. V1.9.7 instead places protective structural edge geometry.
  if(Math.max(Math.abs(edge.heightOffsetAt(0)),
    Math.abs(edge.heightOffsetAt(edge.length*.5)),
    Math.abs(edge.heightOffsetAt(edge.length))) > .55)return false;
  return edge.widthMeters>=5.5&&
    ['primary','secondary','tertiary','residential','unclassified'].includes(edge.roadClass);
}
function panelOnAsphalt(a0,b0,a1,b1,roadIndex){
  const inside=(p,q,r)=>pointOnAsphalt([(p[0]+q[0]+r[0])/3,
    (p[1]+q[1]+r[1])/3],roadIndex);
  return inside(a0,b0,a1)||inside(a1,b0,b1);
}
function drawWalkways(groups,edge,roadIndex,junctionById,stats){
  const [fromClear,toClear]=safeEnds(edge,junctionById,'walkway');
  const from=edge.trims[0]+fromClear,to=edge.length-edge.trims[1]-toClear;
  if(to-from<.9)return;
  // 3 m subdivisions keep exclusion samples local around nearby junctions.
  const path=regularize(subline(edge.line,from,to),3);
  const half=edge.widthMeters/2,asphalt=stripSides(path,half);
  const curb=stripSides(path,half+CURB_WIDTH);
  const walk=stripSides(path,half+CURB_WIDTH+SIDEWALK_WIDTH);
  let kept=0;
  for(const side of ['left','right'])for(let i=1;i<path.length;i++){
    const a0=curb[side][i-1],a1=curb[side][i],b0=walk[side][i-1],b1=walk[side][i];
    const midpoint=[(a0[0]+a1[0]+b0[0]+b1[0])*.25,
      (a0[1]+a1[1]+b0[1]+b1[1])*.25];
    // Don't draw a guessed sidewalk ON TOP of an actual drivable junction,
    // secondary road or acute neighbouring asphalt strip. No physical edits.
    if(pointOnAsphalt(midpoint,roadIndex)||panelOnAsphalt(a0,b0,a1,b1,roadIndex)){
      stats.suppressedSidewalkPanels++;continue;
    }
    ribbonAt(groups.sidewalk,a0,b0,a1,b1,SIDEWALK_Y);
    wallAt(groups.curb,asphalt[side][i-1],asphalt[side][i]);
    ribbonAt(groups.curb,asphalt[side][i-1],a0,asphalt[side][i],a1,CURB_TOP);
    kept++;
  }
  if(kept)stats.estimatedSidewalkCorridors++;
}


function drawJunctionCornerReturns(groups,roadModel,roadIndex,stats){
  // Close the visible curb at the exposed bevels BETWEEN road arms.
  // Segments across a single road cap stay open for vehicles. The underlying
  // collision hull, its drivable boundary and topology are untouched.
  const near=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1])<.003;
  for(const j of roadModel.junctions){
    if(!j.polygon?.length||j.degree<2)continue;
    const starts=batchStarts(groups);
    const polygon=j.polygon;
    const whichArm=point=>{
      for(const arm of j.node.arms){
        const cap=arm.edge.caps[arm.fromStart?0:1];
        if(near(point,cap.left)||near(point,cap.right))return arm.edge.id;
      }
      return null;
    };
    for(let i=0;i<polygon.length;i++){
      const p=polygon[i],q=polygon[(i+1)%polygon.length];
      const armA=whichArm(p),armB=whichArm(q);
      if(!armA||!armB||armA===armB)continue;
      const length=Math.hypot(q[0]-p[0],q[1]-p[1]);
      if(length<.8)continue;
      const normal=[(q[1]-p[1])/length,-(q[0]-p[0])/length];
      // Hull is counter-clockwise in the x/z plane, exterior is its RIGHT.
      const inset=Math.min(.24,length*.16);
      const a=[p[0]+(q[0]-p[0])*inset/length,p[1]+(q[1]-p[1])*inset/length];
      const b=[q[0]-(q[0]-p[0])*inset/length,q[1]-(q[1]-p[1])*inset/length];
      const panelNum=Math.max(1,Math.ceil((length-2*inset)/2.5));
      for(let n=0;n<panelNum;n++){
        const t=n/panelNum,u=(n+1)/panelNum;
        const s=[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];
        const e=[a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u];
        const o=v=>[v[0]+normal[0]*CURB_WIDTH,v[1]+normal[1]*CURB_WIDTH];
        const w=v=>[v[0]+normal[0]*(CURB_WIDTH+SIDEWALK_WIDTH),
          v[1]+normal[1]*(CURB_WIDTH+SIDEWALK_WIDTH)];
        const sa=o(s),ea=o(e),sw=w(s),ew=w(e);
        const middle=[(sa[0]+ea[0]+sw[0]+ew[0])*.25,(sa[1]+ea[1]+sw[1]+ew[1])*.25];
        // Real asphalt wins over inferred sidewalks at adjacent junctions.
        if(pointOnAsphalt(middle,roadIndex)||panelOnAsphalt(sa,sw,ea,ew,roadIndex)){
          stats.suppressedCornerPanels++;continue;
        }
        ribbonAt(groups.sidewalk,sa,sw,ea,ew,SIDEWALK_Y);
        ribbonAt(groups.curb,s,sa,e,ea,CURB_TOP);
        wallAt(groups.curb,s,e);
        stats.junctionCornerPanels++;
      }
    }
    appendHeightDeltas(groups,starts,j.node.arms.map(arm=>arm.edge));
  }
}

export function buildCityStreetDetails(roadModel){
  if(!roadModel||!Array.isArray(roadModel.corridors))throw Error('V1.9.6 street details require an Overture road model');
  const groups={sidewalk:newBatch(),curb:newBatch(),edgePaint:newBatch(),centerPaint:newBatch()};
  const stats={paintedCenterMeters:0,roadEdgesPainted:0,estimatedSidewalkCorridors:0,
    corridorsWithSourceWidth:0,corridorsWithEstimatedWidth:0,
    suppressedSidewalkPanels:0,suppressedCornerPanels:0,junctionCornerPanels:0,
    phaseAlignedMarkings:true,visualOnly:true,followsRoad3D:true};
  const junctionById=new Map(roadModel.junctions.map(j=>[j.id,j]));
  const roadIndex=createRoadTriangleIndex(roadModel);
  for(const edge of roadModel.corridors){
    if(edge.widthSource==='source-rule')stats.corridorsWithSourceWidth++;
    else stats.corridorsWithEstimatedWidth++;
    const [fromClear,toClear]=safeEnds(edge,junctionById,'paint');
    const start=edge.trims[0]+fromClear, end=edge.length-edge.trims[1]-toClear;
    if(end-start<=.7)continue;
    const path=regularize(subline(edge.line,start,end),7);
    if(path.length<2)continue;
    const starts=batchStarts(groups);
    if(hasEstimatedSidewalk(edge))drawWalkways(groups,edge,roadIndex,junctionById,stats);
    if(edge.widthMeters>=6.0&&!['motorway','trunk'].includes(edge.roadClass))
      stats.paintedCenterMeters+=drawDashes(groups.centerPaint,edge,junctionById);
    if(edge.widthMeters>=8&&['primary','secondary','tertiary'].includes(edge.roadClass)){
      const half=edge.widthMeters/2,inside=Math.max(.25,half-.25);
      const outer=stripSides(path,inside+.045),inner=stripSides(path,inside-.045);
      stripAt(groups.edgePaint,inner.left,outer.left,PAINT_Y);
      stripAt(groups.edgePaint,outer.right,inner.right,PAINT_Y);
      stats.roadEdgesPainted++;
    }
    appendHeightDeltas(groups,starts,[edge]);
  }
  drawJunctionCornerReturns(groups,roadModel,roadIndex,stats);
  stats.visualTriangles=Object.values(groups).reduce((acc,b)=>acc+b.triangles,0);
  return {groups,stats};
}

export function metricScaleGeometry(x,z,roadY=CITY_ROAD_Y) {
  // 10 metres in the world, one metre per mark. No projection rescaling.
  if(![x,z].every(Number.isFinite))throw Error('無效比例尺位置');
  const y=roadY+0.16,vertices=[];
  for(let m=0;m<10;m++)vertices.push(x+m,y,z,x+m+1,y,z);
  for(let m=0;m<=10;m++){
    const dz=m%5===0?.5:.25;
    vertices.push(x+m,y,z-dz,x+m,y,z+dz);
  }
  return {vertices,lengthMeters:10,tickMeters:1};
}
