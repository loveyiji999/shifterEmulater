// V1.9.7: estimated bridges / guardrails / underpass retaining walls / piers.
// The road surface, its connector topology and 3D wheel-support triangles are
// NEVER modified here. Source level_rules express stack order, not surveyed
// elevations or real-world bridge/retaining-wall inventories.
//
// Collidable structural tiles are the VERY SAME indexed triangle buffers that
// are rendered by Three and submitted to Rapier. Decorative tiles have no
// collider. 2D crossing asphalt, intersections and lower live roads are
// conservatively excluded from side-barrier and support placement.
import {atDistance, CITY_ROAD_Y} from './city-road-geometry.mjs';
import {CITY_GROUND_Y} from './city-vertical-datum.mjs';

const TILE=180;
const STEP=4;
const MIN_BRIDGE_RISE=1.65;
const MIN_GUARD_RISE=2.05;
const MIN_TRENCH_DEPTH=1.05;
const EPS=1e-7;
const PHYSICAL=new Set(['guardrail','retainingWall','pier']);
const finite=p=>p.every(Number.isFinite);
const dist2=(x,z,px,pz)=>(x-px)**2+(z-pz)**2;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

// Buffered render batches are grouped by material and local grid square. In
// contrast to one THREE.Mesh per rail post, this keeps draw calls bounded.
function createWriter(){
  const tiles=new Map();
  function triangle(kind,a,b,c,anchor=null){
    if(!finite(a)||!finite(b)||!finite(c))throw Error(`立體結構 ${kind} 存在非有限座標`);
    const ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2];
    const vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
    if(Math.hypot(uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx)<EPS)return;
    const cx=anchor?.[0]??(a[0]+b[0]+c[0])/3;
    const cz=anchor?.[1]??(a[2]+b[2]+c[2])/3;
    const key=`${Math.floor((cx+1100)/TILE)}:${Math.floor((cz+1100)/TILE)}:${kind}`;
    if(!tiles.has(key))tiles.set(key,{key,kind,physical:PHYSICAL.has(kind),vertices:[],indices:[]});
    const tile=tiles.get(key),i=tile.vertices.length/3;
    tile.vertices.push(...a,...b,...c);tile.indices.push(i,i+1,i+2);
  }
  const quad=(kind,a,b,c,d,anchor=null)=>{
    triangle(kind,a,b,c,anchor);triangle(kind,a,c,d,anchor);};
  // Box with sloping endpoints. All six faces are closed, including end caps.
  // "left" and "right" are world XYZ points; each pair shares elevation.
  function prism(kind,start,end,normal,halfWidth,bottom0,bottom1,top0,top1){
    if(top0<=bottom0+.01||top1<=bottom1+.01)return;
    const h=halfWidth,nx=normal[0]*h,nz=normal[1]*h;
    const a=[start[0]-nx,bottom0,start[1]-nz],b=[start[0]+nx,bottom0,start[1]+nz];
    const c=[start[0]-nx,top0,start[1]-nz],d=[start[0]+nx,top0,start[1]+nz];
    const e=[end[0]-nx,bottom1,end[1]-nz],f=[end[0]+nx,bottom1,end[1]+nz];
    const g=[end[0]-nx,top1,end[1]-nz],h2=[end[0]+nx,top1,end[1]+nz];
    const anchor=[(start[0]+end[0])*.5,(start[1]+end[1])*.5];
    quad(kind,a,e,g,c,anchor);quad(kind,b,d,h2,f,anchor);
    quad(kind,c,g,h2,d,anchor);quad(kind,a,b,f,e,anchor);
    quad(kind,a,c,d,b,anchor);quad(kind,e,f,h2,g,anchor);
  }
  function cuboid(kind,x,y,z,halfX,halfY,halfZ){
    // Two opposite endpoints along Z; world-axis normal is X.
    prism(kind,[x,y-halfY,z-halfZ],[x,y-halfY,z+halfZ],[1,0],halfX,
      y-halfY,y-halfY,y+halfY,y+halfY);
  }
  return {tiles,triangle,quad,prism,cuboid};
}

function tangent(edge,s){
  const d=Math.min(.42,edge.length*.18);
  const a=atDistance(edge.line,Math.max(0,s-d));
  const b=atDistance(edge.line,Math.min(edge.length,s+d));
  const dx=b[0]-a[0],dz=b[1]-a[1],len=Math.hypot(dx,dz);
  return len>EPS?[dx/len,dz/len]:[0,1];
}
function sidePosition(edge,s,side,extra){
  const p=atDistance(edge.line,s),t=tangent(edge,s);
  const off=side*(edge.widthMeters*.5+extra);
  return [p[0]-t[1]*off,p[1]+t[0]*off];
}
// 3D drivable-asphalt index. A 2D-only overlap check would erase guardrails
// exactly above grade-separated crossings even when cars can safely pass below.
// Interpolate each *actual* road triangle's Y to assess vertical clearance.
function buildAsphaltHeightIndex(roadModel){
  const size=35,grid=new Map();
  for(const tile of roadModel.tiles.values()){
    for(let i=0;i<tile.indices.length;i+=3){
      const coords=[];
      for(let j=0;j<3;j++){
        const k=3*tile.indices[i+j];
        coords.push([tile.vertices[k],tile.vertices[k+1],tile.vertices[k+2]]);
      }
      const xs=coords.map(p=>p[0]),zs=coords.map(p=>p[2]);
      const minX=Math.floor(Math.min(...xs)/size),maxX=Math.floor(Math.max(...xs)/size);
      const minZ=Math.floor(Math.min(...zs)/size),maxZ=Math.floor(Math.max(...zs)/size);
      for(let gx=minX;gx<=maxX;gx++)for(let gz=minZ;gz<=maxZ;gz++){
        const key=`${gx}:${gz}`;
        if(!grid.has(key))grid.set(key,[]);
        grid.get(key).push(coords);
      }
    }
  }
  function intersectSurface(x,z,low,high){
    for(const [a,b,c] of grid.get(`${Math.floor(x/size)}:${Math.floor(z/size)}`)||[]){
      const ux=b[0]-a[0],uz=b[2]-a[2],vx=c[0]-a[0],vz=c[2]-a[2];
      const determinant=ux*vz-uz*vx;
      if(Math.abs(determinant)<EPS)continue;
      const px=x-a[0],pz=z-a[2];
      const u=(px*vz-pz*vx)/determinant,v=(ux*pz-uz*px)/determinant;
      if(u<-.00001||v<-.00001||u+v>1.00001)continue;
      const roadY=a[1]+u*(b[1]-a[1])+v*(c[1]-a[1]);
      if(roadY>=low-.07 && roadY<=high+.07)return true;
    }
    return false;
  }
  return (a,b,normal,halfWidth,low,high)=>{
    for(const t of [0,.25,.5,.75,1]){
      const x=a[0]*(1-t)+b[0]*t,z=a[1]*(1-t)+b[1]*t;
      for(const sideways of [0,-halfWidth-.045,halfWidth+.045]){
        if(intersectSurface(x+normal[0]*sideways,z+normal[1]*sideways,low,high))return false;
      }
    }
    return true;
  };
}

// Fast local candidate lists for checking if a lower, drivable crossing road
// would be blocked by an estimated pillar. The own bridge corridor is ignored.
function buildSpanIndex(roadModel){
  const size=45,cells=new Map();
  for(const edge of roadModel.corridors){
    for(let k=1;k<edge.line.points.length;k++){
      const a=edge.line.points[k-1],b=edge.line.points[k];
      const span={edge,a,b,along:edge.line.distances[k-1],length:edge.line.distances[k]-edge.line.distances[k-1]};
      const radius=edge.widthMeters*.5+5;
      const minX=Math.floor((Math.min(a[0],b[0])-radius)/size);
      const maxX=Math.floor((Math.max(a[0],b[0])+radius)/size);
      const minZ=Math.floor((Math.min(a[1],b[1])-radius)/size);
      const maxZ=Math.floor((Math.max(a[1],b[1])+radius)/size);
      for(let ix=minX;ix<=maxX;ix++)for(let iz=minZ;iz<=maxZ;iz++){
        const key=`${ix}:${iz}`;
        if(!cells.has(key))cells.set(key,[]);
        cells.get(key).push(span);
      }
    }
  }
  return (x,z,owner,topY)=>{
    for(const span of cells.get(`${Math.floor(x/size)}:${Math.floor(z/size)}`)||[]){
      if(span.edge.sourceId===owner.sourceId)continue;
      const dx=span.b[0]-span.a[0],dz=span.b[1]-span.a[1],l2=dx*dx+dz*dz;
      const t=clamp(l2>EPS?((x-span.a[0])*dx+(z-span.a[1])*dz)/l2:0,0,1);
      const px=span.a[0]+dx*t,pz=span.a[1]+dz*t;
      const clearance=span.edge.widthMeters*.5+2.2;
      if(dist2(x,z,px,pz)>clearance*clearance)continue;
      const otherY=span.edge.heightAt(span.along+span.length*t);
      // There must be room for the other road and its vehicles. Skip if the
      // support would reach its pavement, even at an unconnected crossing.
      if(otherY<topY+1.7 && otherY>=-1)return true;
    }
    return false;
  };
}
function inRing(x,z,ring){
  let inside=false;
  for(let i=0,j=ring.length-1;i<ring.length;j=i++){
    const a=ring[i],b=ring[j];
    if((a[1]>z)!==(b[1]>z) &&
      x<(b[0]-a[0])*(z-a[1])/(b[1]-a[1])+a[0])inside=!inside;
  }
  return inside;
}
function segmentPointDistanceSq(x,z,a,b){
  const dx=b[0]-a[0],dz=b[1]-a[1],den=dx*dx+dz*dz;
  const t=clamp(den>EPS?((x-a[0])*dx+(z-a[1])*dz)/den:0,0,1);
  return dist2(x,z,a[0]+dx*t,a[1]+dz*t);
}
function buildingGuard(buildingMap){
  if(!buildingMap?.buildings?.length)return ()=>false;
  const step=70,grid=new Map();
  for(const b of buildingMap.buildings)for(const polygon of b.polygons||[]){
    const ring=polygon.outer;
    if(!ring||ring.length<3)continue;
    let minX=Infinity,maxX=-Infinity,minZ=Infinity,maxZ=-Infinity;
    for(const p of ring){minX=Math.min(minX,p[0]);maxX=Math.max(maxX,p[0]);
      minZ=Math.min(minZ,p[1]);maxZ=Math.max(maxZ,p[1]);}
    const item={ring,holes:polygon.holes||[],minX,maxX,minZ,maxZ};
    for(let ix=Math.floor((minX-2)/step);ix<=Math.floor((maxX+2)/step);ix++)
      for(let iz=Math.floor((minZ-2)/step);iz<=Math.floor((maxZ+2)/step);iz++){
        const key=`${ix}:${iz}`;
        if(!grid.has(key))grid.set(key,[]);
        grid.get(key).push(item);
      }
  }
  return (x,z)=>{
    for(const item of grid.get(`${Math.floor(x/step)}:${Math.floor(z/step)}`)||[]){
      if(x<item.minX-1.5||x>item.maxX+1.5||z<item.minZ-1.5||z>item.maxZ+1.5)continue;
      const p=item;
      if(inRing(x,z,p.ring)&&!p.holes.some(hole=>inRing(x,z,hole)))return true;
      // Don't use a neighbouring building face as a pier foundation.
      for(let i=0;i<p.ring.length;i++)if(segmentPointDistanceSq(x,z,p.ring[i],p.ring[(i+1)%p.ring.length])<2.25)return true;
    }
    return false;
  };
}

export function buildCityRoadStructures(roadModel, {terrain=null,buildingMap=null}={}){
  if(!roadModel?.corridors||!roadModel?.tiles)throw Error('道路結構需要有效的三維道路幾何');
  const groundY=terrain?.groundY??CITY_GROUND_Y;
  const writer=createWriter();
  const sideClear=buildAsphaltHeightIndex(roadModel);
  const overlapsLowerRoad=buildSpanIndex(roadModel);
  const overlapsBuilding=buildingGuard(buildingMap);
  const stats={bridgeDeckMeters:0,guardrailMeters:0,retainingWallMeters:0,
    approachFillMeters:0,
    piers:0,reflectors:0,bridgeSegments:0,trenchSegments:0,
    skippedBarrierPanels:0,skippedPiersForRoad:0,skippedPiersForBuilding:0,
    estimatedGeometry:true,surveyedStructureLocations:false};
  const recordRail=(edge,s0,s1,side,y0,y1,n)=>{
    const p0=sidePosition(edge,s0,side,.72),p1=sidePosition(edge,s1,side,.72);
    if(!sideClear(p0,p1,n,.14,Math.min(y0,y1)+.06,Math.max(y0,y1)+1.01)) {stats.skippedBarrierPanels++;return;}
    // Solid 0.28m-wide parapet: this visible tile IS the Rapier barrier.
    writer.prism('guardrail',p0,p1,n,.14,y0+.06,y1+.06,y0+1.01,y1+1.01);
    // Coping, vertical posts, and warning reflector are render-only.
    writer.prism('railCap',p0,p1,n,.195,y0+.94,y1+.94,y0+1.06,y1+1.06);
    stats.guardrailMeters+=s1-s0;
    if(Math.floor(s0/13)!==Math.floor(s1/13)){
      const s=(s0+s1)*.5,p=sidePosition(edge,s,side,.87),h=edge.heightAt(s);
      writer.cuboid('reflector',p[0],h+.68,p[1],.12,.07,.12);
      stats.reflectors++;
    }
  };
  const recordWall=(edge,s0,s1,side,y0,y1,n)=>{
    const p0=sidePosition(edge,s0,side,.74),p1=sidePosition(edge,s1,side,.74);
    // A ground-level crossing is ABOVE the retaining wall, not a reason to
    // remove it. Stop both wall and coping beneath the common ground plane.
    if(!sideClear(p0,p1,n,.18,Math.min(y0,y1)-.48,groundY-.08)){stats.skippedBarrierPanels++;return;}
    const top=groundY-.10;
    const bottom0=y0-.48,bottom1=y1-.48;
    // The wall never extends above unexcavated terrain: an unrelated road
    // crossing overhead stays unobstructed. The vehicle sees a solid wall.
    writer.prism('retainingWall',p0,p1,n,.18,bottom0,bottom1,top,top);
    writer.prism('wallCoping',p0,p1,n,.24,top-.20,top-.20,top+.08,top+.08);
    stats.retainingWallMeters+=s1-s0;
    if(Math.floor(s0/15)!==Math.floor(s1/15)){
      const s=(s0+s1)*.5,p=sidePosition(edge,s,side,.95);
      const h=Math.min(groundY-.28,edge.heightAt(s)+.82);
      writer.cuboid('reflector',p[0],h,p[1],.11,.095,.11);
      stats.reflectors++;
    }
  };
  for(const edge of roadModel.corridors){
    if(edge.widthMeters<2.3)continue;
    const from=edge.trims[0]+2.6,to=edge.length-edge.trims[1]-2.6;
    if(to-from<2)continue;
    const count=Math.max(1,Math.ceil((to-from)/STEP));
    for(let i=0;i<count;i++){
      const s0=from+(to-from)*i/count,s1=from+(to-from)*(i+1)/count;
      const mid=(s0+s1)*.5,y0=edge.heightAt(s0),y1=edge.heightAt(s1);
      const dy=edge.heightOffsetAt(mid),p0=atDistance(edge.line,s0),p1=atDistance(edge.line,s1);
      const dx=p1[0]-p0[0],dz=p1[1]-p0[1],len=Math.hypot(dx,dz);
      if(len<EPS)continue;
      const normal=[-dz/len,dx/len];
      if(dy>MIN_BRIDGE_RISE){
        // Visual slab under the EXACT existing asphalt; not a second wheel
        // supporting surface and not a solid blocker over crossing roads.
        for(const side of [-1,1]){
          const a=sidePosition(edge,s0,side,0),b=sidePosition(edge,s1,side,0);
          writer.quad('deckFascia',[a[0],y0-.39,a[1]],[b[0],y1-.39,b[1]],
            [b[0],y1-.015,b[1]],[a[0],y0-.015,a[1]]);
        }
        writer.quad('deckUnderside',
          [sidePosition(edge,s0,-1,0)[0],y0-.39,sidePosition(edge,s0,-1,0)[1]],
          [sidePosition(edge,s1,-1,0)[0],y1-.39,sidePosition(edge,s1,-1,0)[1]],
          [sidePosition(edge,s1,1,0)[0],y1-.39,sidePosition(edge,s1,1,0)[1]],
          [sidePosition(edge,s0,1,0)[0],y0-.39,sidePosition(edge,s0,1,0)[1]]);
        stats.bridgeDeckMeters+=s1-s0;stats.bridgeSegments++;
        if(dy>MIN_GUARD_RISE && Math.min(y0,y1)-CITY_ROAD_Y>MIN_GUARD_RISE-0.25){
          for(const side of [-1,1])recordRail(edge,s0,s1,side,y0,y1,normal);
        }
      }else if(dy>.065 && Math.min(y0,y1)>groundY+.025){
        // Low-rise connector ramps used to have no visible support before the
        // bridge-fascia threshold, so they looked like slabs suspended over
        // level building foundations. Close the shoulder to the common local
        // ground datum with visual-only graded fill. It is NOT a surveyed
        // embankment and must never create a second wheel-support collider.
        for(const side of [-1,1]){
          const top0=sidePosition(edge,s0,side,0),top1=sidePosition(edge,s1,side,0);
          const foot0=sidePosition(edge,s0,side,clamp((y0-groundY)*1.2,.35,2.7));
          const foot1=sidePosition(edge,s1,side,clamp((y1-groundY)*1.2,.35,2.7));
          writer.quad('approachFill',
            [top0[0],y0-.016,top0[1]],[top1[0],y1-.016,top1[1]],
            [foot1[0],groundY-.012,foot1[1]],[foot0[0],groundY-.012,foot0[1]]);
        }
        stats.approachFillMeters+=s1-s0;
      }else if(dy < -MIN_TRENCH_DEPTH && Math.max(y0,y1)<groundY-.6){
        for(const side of [-1,1])recordWall(edge,s0,s1,side,y0,y1,normal);
        stats.trenchSegments++;
      }
    }
    // Piers are NOT laid out at every bridge crossing. They are skipped
    // wherever a lower driveable corridor or known building could be hit.
    if(to-from>52){
      for(let s=from+22;s<to-17;s+=43){
        const top=edge.heightAt(s)-.52;
        if(top-groundY<2.8)continue;
        const [x,z]=atDistance(edge.line,s);
        if(overlapsLowerRoad(x,z,edge,top)){stats.skippedPiersForRoad++;continue;}
        if(overlapsBuilding(x,z)){stats.skippedPiersForBuilding++;continue;}
        const halfY=(top-groundY)/2;
        writer.cuboid('pier',x,groundY+halfY,z,.88,halfY,.88);
        // Non-colliding bearing shelf stays UNDER the asphalt by 0.12m.
        writer.cuboid('pierCap',x,top+.16,z,1.16,.16,1.18);
        stats.piers++;
      }
    }
  }
  stats.renderTiles=writer.tiles.size;
  stats.collisionTiles=[...writer.tiles.values()].filter(t=>t.physical).length;
  stats.renderTriangles=[...writer.tiles.values()].reduce((sum,t)=>sum+t.indices.length/3,0);
  stats.collisionTriangles=[...writer.tiles.values()].filter(t=>t.physical)
    .reduce((sum,t)=>sum+t.indices.length/3,0);
  return {tiles:writer.tiles,stats,physicalKinds:[...PHYSICAL],
    limitations:'Procedural estimated infrastructure based on Overture level_rules and road width. Not surveyed; no true pier locations, structural design, tunnel roof or DEM.'};
}
