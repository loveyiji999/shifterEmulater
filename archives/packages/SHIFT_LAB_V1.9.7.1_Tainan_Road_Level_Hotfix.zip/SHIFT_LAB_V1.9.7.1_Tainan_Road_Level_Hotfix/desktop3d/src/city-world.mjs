import * as THREE from 'three';
import {cityStatistics, validateCityMap} from './city-geo.mjs';
import {buildCityRoadGeometry, CITY_ROAD_Y} from './city-road-geometry.mjs';
import {CITY_GROUND_Y} from './city-vertical-datum.mjs';
import {buildCityTerrainGeometry} from './city-terrain-geometry.mjs';
import {buildCityRoadStructures} from './city-road-structures.mjs';
import {validateBuildingMap,buildingStatistics} from './city-buildings-geo.mjs';
import {buildCityBuildingGeometry,createBuildingTileMesh} from './city-building-geometry.mjs';
import {buildCityStreetDetails,metricScaleGeometry} from './city-street-details.mjs';
import {buildCityStreetAudit,auditCityRoadCoverage} from './city-street-audit.mjs';
import {assessCityJunctionQuality,auditCityWheelTrackSupport} from './city-junction-quality.mjs';

const prefixedStructureStats=stats=>Object.fromEntries(Object.entries(stats||{})
  .map(([key,value])=>['structure'+key[0].toUpperCase()+key.slice(1),value]));

// V1.9.2: one true Overture mesh source for rendering AND Rapier ground.
// Retains the independent city scene; never mutates a procedural road chunk.
export class CityRoadWorld {
  constructor({elevationMode='source-levels'}={}) {
    this.elevationMode=elevationMode;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0c1924);
    this.scene.add(new THREE.HemisphereLight(0xe6f2f5, 0x253c35, 2.3));
    const light = new THREE.DirectionalLight(0xffffff, 1.3);
    light.position.set(-900, 1800, 850);
    this.scene.add(light);
    this.ground = new THREE.Mesh(new THREE.PlaneGeometry(2000, 2000),
      new THREE.MeshStandardMaterial({color: 0x334d43, roughness: 1, side: THREE.DoubleSide}));
    this.ground.rotation.x = -Math.PI / 2;
    this.ground.position.y = CITY_GROUND_Y;
    this.scene.add(this.ground);
    this.recoveryGround=new THREE.Mesh(new THREE.PlaneGeometry(2000,2000),
      new THREE.MeshStandardMaterial({color:0x293c36,roughness:1,side:THREE.DoubleSide}));
    this.recoveryGround.rotation.x=-Math.PI/2;
    this.scene.add(this.recoveryGround);
    this.terrainModel=null;
    this.grid = new THREE.GridHelper(2000, 8, 0x54716a, 0x37544d);
    this.grid.position.y = CITY_ROAD_Y + 0.018;
    this.scene.add(this.grid);
    const outlinePoints = [[-1000, -1000], [1000, -1000], [1000, 1000], [-1000, 1000], [-1000, -1000]]
      .map(([x, z]) => new THREE.Vector3(x, 0.30, z));
    this.outline = new THREE.Line(new THREE.BufferGeometry().setFromPoints(outlinePoints),
      new THREE.LineBasicMaterial({color: 0xb7dfc5}));
    this.scene.add(this.outline);
    this.stationMarker = new THREE.Mesh(new THREE.ConeGeometry(22, 80, 10),
      new THREE.MeshStandardMaterial({color: 0xffc976, emissive: 0x50330e}));
    this.stationMarker.position.set(0, 55, 0);
    this.scene.add(this.stationMarker);
    this.layers = new THREE.Group();
    this.scene.add(this.layers);
    // Decorative surfaces are explicitly separate from Rapier's asphalt.
    this.streetLayers = new THREE.Group();this.scene.add(this.streetLayers);
    this.diagnosticLayers = new THREE.Group();this.scene.add(this.diagnosticLayers);
    this.streetAppearance = {markings:true,walkways:true,diagnostics:false};
    this.streetDetails = null;this.audit = null;this.coverage = null;
    // Structure rendering is kept outside the original asphalt authority.
    this.structureLayers = new THREE.Group();this.scene.add(this.structureLayers);
    this.structureModel = null;
    this.structureMaterials = {
      deckFascia:new THREE.MeshStandardMaterial({color:0x5d6971,roughness:.98,side:THREE.DoubleSide}),
      deckUnderside:new THREE.MeshStandardMaterial({color:0x414d53,roughness:1,side:THREE.DoubleSide}),
      approachFill:new THREE.MeshStandardMaterial({color:0x576759,roughness:1,side:THREE.DoubleSide}),
      guardrail:new THREE.MeshStandardMaterial({color:0xa8afb2,roughness:.85,side:THREE.DoubleSide}),
      railCap:new THREE.MeshStandardMaterial({color:0xd4d6d1,metalness:.24,roughness:.67,side:THREE.DoubleSide}),
      retainingWall:new THREE.MeshStandardMaterial({color:0x858b87,roughness:1,side:THREE.DoubleSide}),
      wallCoping:new THREE.MeshStandardMaterial({color:0xb8bcb7,roughness:.95,side:THREE.DoubleSide}),
      pier:new THREE.MeshStandardMaterial({color:0x90969a,roughness:1,side:THREE.DoubleSide}),
      pierCap:new THREE.MeshStandardMaterial({color:0x667079,roughness:1,side:THREE.DoubleSide}),
      reflector:new THREE.MeshBasicMaterial({color:0xffd985,side:THREE.DoubleSide})
    };
    this.junctionQuality = null;this.wheelCoverage = null;
    this.streetMaterials = {
      centerPaint:new THREE.MeshBasicMaterial({color:0xe8dcac,side:THREE.DoubleSide,depthWrite:false}),
      edgePaint:new THREE.MeshBasicMaterial({color:0xe2e9e5,side:THREE.DoubleSide,depthWrite:false}),
      sidewalk:new THREE.MeshStandardMaterial({color:0xa8aca9,side:THREE.DoubleSide,roughness:1}),
      curb:new THREE.MeshStandardMaterial({color:0xc6c8bf,side:THREE.DoubleSide,roughness:1})
    };
    this.buildingLayers = new THREE.Group();
    this.scene.add(this.buildingLayers);
    this.buildingMaterial = new THREE.MeshStandardMaterial({vertexColors: true, roughness: .97, side: THREE.DoubleSide});
    this.buildingModel = null;
    this.buildingMap = null;
    this.buildingStats = null;
    this.buildingColliders = new Map();
    this.buildingHandles = new Set();
    this.lastBuildingAnchor = null;
    this.materials = {
      major: new THREE.MeshStandardMaterial({color: 0x7a878c, roughness: 0.95, side: THREE.DoubleSide}),
      normal: new THREE.MeshStandardMaterial({color: 0x667b81, roughness: 0.95, side: THREE.DoubleSide}),
      minor: new THREE.MeshStandardMaterial({color: 0x566a6b, roughness: 0.95, side: THREE.DoubleSide}),
      walking: new THREE.MeshStandardMaterial({color: 0x677f6a, roughness: 1, side: THREE.DoubleSide}),
      rail: new THREE.MeshStandardMaterial({color: 0xaa835d, roughness: 1, side: THREE.DoubleSide})
    };
    this.loaded = false;
    this.stats = null;
    this.roadModel = null;
    this.rapier = null;
    this.world = null;
    this.colliders = [];
    this.groundHandles = new Set();
    this.railHandles = new Set();
    this.barrierHandles = new Set();
    this.obstacleHandles = new Set();
    this.structureHandles = new Set();
  }
  category(s) {
    if (s.use === 'rail') return 'rail';
    if (s.use === 'nonvehicle') return 'walking';
    if (['motorway', 'trunk', 'primary', 'secondary'].includes(s.roadClass)) return 'major';
    if (['residential', 'tertiary'].includes(s.roadClass)) return 'normal';
    return 'minor';
  }
  setData(map) {
    validateCityMap(map);
    if (this.colliders.length) throw Error('駕駛中不可直接更換地圖，請先返回城市預覽');
    // Validate/build BEFORE removing the previous valid map, so an invalid
    // imported dataset does not break the drivable scene.
    const model = buildCityRoadGeometry(map,{elevationMode:this.elevationMode});
    const terrain = buildCityTerrainGeometry(model);
    const structures = buildCityRoadStructures(model,{terrain,buildingMap:this.buildingMap});
    const details = buildCityStreetDetails(model);
    const coverage = auditCityRoadCoverage(model);
    const junctionQuality = assessCityJunctionQuality(model);
    const wheelCoverage = auditCityWheelTrackSupport(model);
    // Diagnose OLD validated buildings against the NEW road, without changing
    // the building data or incorrectly claiming source accuracy.
    const audit = this.buildingMap ? buildCityStreetAudit(model,this.buildingMap) : null;
    const visualBatches = new Map();
    for (const segment of map.segments) {
      if (segment.use !== 'rail' && segment.use !== 'nonvehicle') continue;
      const name = this.category(segment);
      if (!visualBatches.has(name)) visualBatches.set(name, {vertices: [], indices: []});
      const batch = visualBatches.get(name);
      const y = name === 'rail' ? .10 : .055;
      const half = Math.max(.25, segment.widthMeters / 2);
      for (let i = 1; i < segment.coordinates.length; i++) {
        const [ax, az] = segment.coordinates[i - 1], [bx, bz] = segment.coordinates[i];
        const dx = bx - ax, dz = bz - az, len = Math.hypot(dx, dz);
        if (len < .001) continue;
        const offX = -dz / len * half, offZ = dx / len * half;
        const base = batch.vertices.length / 3;
        batch.vertices.push(ax + offX, y, az + offZ, ax - offX, y, az - offZ,
          bx + offX, y, bz + offZ, bx - offX, y, bz - offZ);
        batch.indices.push(base, base + 2, base + 1, base + 1, base + 2, base + 3);
      }
    }
    this.clearRoads();
    this.roadModel = model;
    this.terrainModel = terrain;
    this.installStructures(structures);
    // The visible soil and static Rapier soil will use these EXACT buffers.
    const soilGeometry=new THREE.BufferGeometry();
    soilGeometry.setAttribute('position',new THREE.Float32BufferAttribute(terrain.vertices,3));
    soilGeometry.setIndex(terrain.indices);
    soilGeometry.computeVertexNormals();
    this.ground.geometry.dispose();this.ground.geometry=soilGeometry;
    this.ground.rotation.set(0,0,0);this.ground.position.set(0,0,0);
    this.recoveryGround.position.y=terrain.recoveryY-.002;
    this.streetDetails = details;
    this.audit = audit;this.coverage = coverage;
    this.junctionQuality = junctionQuality;this.wheelCoverage = wheelCoverage;
    const addMesh = (name, batch) => {
      if (!batch.indices.length) return;
      const geom = new THREE.BufferGeometry();
      geom.setAttribute('position', new THREE.Float32BufferAttribute(batch.vertices, 3));
      geom.setIndex(batch.indices);
      geom.computeVertexNormals();
      const mesh = new THREE.Mesh(geom, this.materials[name]);
      mesh.receiveShadow = true;
      mesh.frustumCulled = false;
      this.layers.add(mesh);
    };
    for (const batch of model.tiles.values()) addMesh(batch.category, batch);
    for (const [name, batch] of visualBatches) addMesh(name, batch);
    for(const [kind,batch] of Object.entries(details.groups)) {
      if(!batch.vertices.length)continue;
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position',new THREE.Float32BufferAttribute(batch.vertices,3));
      geometry.computeVertexNormals();
      const mesh = new THREE.Mesh(geometry,this.streetMaterials[kind]);
      mesh.userData.streetKind=kind;mesh.frustumCulled=false;
      this.streetLayers.add(mesh);
    }
    this.setStreetAppearance({});
    this.stats = {...cityStatistics(map), ...model.stats, ...terrain.stats, ...details.stats,
      ...prefixedStructureStats(structures.stats),
      coverageSamples:coverage.samples,coverageMisses:coverage.missesCount,
      wheelSamples:wheelCoverage.samples,wheelMisses:wheelCoverage.missesCount,
      tooNarrowForWheelTrack:wheelCoverage.narrowCorridors.length,
      reviewJunctions:junctionQuality.stats.reviewJunctions};
    this.loaded = true;
    this.setStreetAppearance({});
    return this.stats;
  }
  // Building data are independently validated and swapped atomically.
  // Missing real building data means NO building meshes, not invented blocks.
  setBuildings(map) {
    if(this.colliders.length)throw Error('更換建築資料前請先離開台南駕駛模式');
    const validated=validateBuildingMap(map);
    const model=buildCityBuildingGeometry(validated);
    const stats={...buildingStatistics(validated),...model.stats};
    // Re-evaluate supports against real building footprints. An estimated
    // bridge pier must never be fabricated inside an imported building.
    const structures=this.roadModel?buildCityRoadStructures(this.roadModel,
      {terrain:this.terrainModel,buildingMap:validated}):null;
    const audit=this.roadModel?buildCityStreetAudit(this.roadModel,validated):null;
    const meshes=[];
    try {for(const tile of model.tiles.values())
      meshes.push(createBuildingTileMesh(tile,this.buildingMaterial));}
    catch(error) {for(const mesh of meshes)mesh.geometry.dispose();throw error;}
    this.clearBuildings();
    this.buildingModel=model;this.buildingMap=validated;this.buildingStats=stats;
    this.audit=audit;
    if(structures){
      this.installStructures(structures);
      if(this.stats)Object.assign(this.stats,prefixedStructureStats(structures.stats));
    }
    this.clearDiagnosticGeometry();
    for(const mesh of meshes)this.buildingLayers.add(mesh);
    this.setStreetAppearance({});
    return stats;
  }
  clearBuildings(){
    if(this.buildingColliders.size)throw Error('清除建築前必須釋放 Rapier 建築碰撞');
    for(const mesh of [...this.buildingLayers.children]){
      this.buildingLayers.remove(mesh);mesh.geometry.dispose();
    }
    this.buildingModel=null;this.buildingMap=null;this.buildingStats=null;
    this.audit=null;this.clearDiagnosticGeometry();
  }
  clearStructureGeometry(){
    for(const mesh of [...this.structureLayers.children]){
      this.structureLayers.remove(mesh);
      mesh.geometry.dispose();
    }
    this.structureModel=null;
  }
  installStructures(model){
    if(this.colliders.length)throw Error('駕駛時不得重建道路結構碰撞體');
    this.clearStructureGeometry();
    this.structureModel=model;
    if(!model)return;
    for(const tile of model.tiles.values()){
      if(!tile.indices.length)continue;
      const geometry=new THREE.BufferGeometry();
      geometry.setAttribute('position',new THREE.Float32BufferAttribute(tile.vertices,3));
      geometry.setIndex(tile.indices);
      geometry.computeVertexNormals();
      const mesh=new THREE.Mesh(geometry,this.structureMaterials[tile.kind]);
      mesh.receiveShadow=true;
      mesh.userData.structureKind=tile.kind;
      this.structureLayers.add(mesh);
    }
  }
  setStreetAppearance(changes={}) {
    for(const key of ['markings','walkways','diagnostics'])
      if(Object.hasOwn(changes,key))this.streetAppearance[key]=Boolean(changes[key]);
    for(const mesh of this.streetLayers.children) {
      const kind=mesh.userData.streetKind;
      mesh.visible=['centerPaint','edgePaint'].includes(kind)
        ?this.streetAppearance.markings:this.streetAppearance.walkways;
    }
    if(this.streetAppearance.diagnostics && this.loaded && !this.diagnosticLayers.children.length)
      this.createDiagnosticGeometry();
    this.diagnosticLayers.visible=this.streetAppearance.diagnostics;
    return {...this.streetAppearance};
  }
  clearDiagnosticGeometry(){
    for(const object of [...this.diagnosticLayers.children]){
      this.diagnosticLayers.remove(object);
      object.geometry.dispose();object.material.dispose();
    }
  }
  createDiagnosticGeometry(){
    if(!this.roadModel)return;
    // The wires represent EXACTLY the asphalt triangle coordinates fed to Rapier.
    // They are not a separate collider or a speculative sidewalk barrier.
    const verts=[];
    for(const batch of this.roadModel.tiles.values()) {
      for(let i=0;i<batch.indices.length;i+=3) {
        const points=[];
        for(let j=0;j<3;j++){
          const n=batch.indices[i+j]*3;
          points.push([batch.vertices[n],batch.vertices[n+1]+.018,batch.vertices[n+2]]);
        }
        for(let k=0;k<3;k++)verts.push(...points[k],...points[(k+1)%3]);
      }
    }
    const lines=new THREE.BufferGeometry();
    lines.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));
    const mesh=new THREE.LineSegments(lines,new THREE.LineBasicMaterial({color:0x67d3ff,depthWrite:false}));
    mesh.frustumCulled=false;this.diagnosticLayers.add(mesh);
    const spawn=this.spawnPoint();
    const scale=metricScaleGeometry(spawn.x+8,spawn.z+9,spawn.y);
    const scaleGeo=new THREE.BufferGeometry();
    scaleGeo.setAttribute('position',new THREE.Float32BufferAttribute(scale.vertices,3));
    this.diagnosticLayers.add(new THREE.LineSegments(scaleGeo,
      new THREE.LineBasicMaterial({color:0xffee82,depthTest:false})));
    if(this.junctionQuality?.issues?.length){
      // Amber crosses = geometry review candidates, not an invented repair.
      // The center is the actual Overture connector position in metres.
      const flagged=[];
      for(const issue of this.junctionQuality.issues.slice(0,160)){
        const junction=this.roadModel.junctions.find(j=>j.id===issue.id);
        const size=4.0,y=(junction?.height??CITY_ROAD_Y)+.30;
        flagged.push(issue.x-size,y,issue.z-size,issue.x+size,y,issue.z+size,
          issue.x-size,y,issue.z+size,issue.x+size,y,issue.z-size);
      }
      const geo=new THREE.BufferGeometry();
      geo.setAttribute('position',new THREE.Float32BufferAttribute(flagged,3));
      const marker=new THREE.LineSegments(geo,
        new THREE.LineBasicMaterial({color:0xffc56b,depthTest:false,depthWrite:false}));
      marker.frustumCulled=false;this.diagnosticLayers.add(marker);
    }
    if(this.audit && this.buildingMap){
      const byId=new Map(this.buildingMap.buildings.map(b=>[b.id,b]));
      const suspectVertices=[];
      for(const issue of this.audit.issues.slice(0,100)) {
        for(const polygon of byId.get(issue.id)?.polygons || []){
          const outline=polygon.outer;
          for(let i=0;i<outline.length;i++){
            const a=outline[i],b=outline[(i+1)%outline.length];
            suspectVertices.push(a[0],CITY_ROAD_Y+.22,a[1],b[0],CITY_ROAD_Y+.22,b[1]);
          }
        }
      }
      if(suspectVertices.length){
        const geo=new THREE.BufferGeometry();
        geo.setAttribute('position',new THREE.Float32BufferAttribute(suspectVertices,3));
        this.diagnosticLayers.add(new THREE.LineSegments(geo,
          new THREE.LineBasicMaterial({color:0xff775c,depthTest:false})));
      }
    }
  }
  // Building colliders are streamed around the actual car, not all 2x2 km
  // at once. Render batches are retained for the whole city and are shared
  // with Rapier without regenerating or changing footprint coordinates.
  syncBuildingColliders(x,z,radius=245,force=false){
    if(!this.world||!this.rapier||!this.buildingModel)return 0;
    if(!Number.isFinite(x)||!Number.isFinite(z))throw Error('建築碰撞同步座標無效');
    if(!force&&this.lastBuildingAnchor&&
      Math.hypot(x-this.lastBuildingAnchor[0],z-this.lastBuildingAnchor[1])<60)return this.buildingColliders.size;
    const desired=new Set();
    for(const [key,tile] of this.buildingModel.tiles){
      const {minX,maxX,minZ,maxZ}=tile.bounds;
      const dx=Math.max(minX-x,0,x-maxX),dz=Math.max(minZ-z,0,z-maxZ);
      if(dx*dx+dz*dz<=radius*radius)desired.add(key);
    }
    for(const [key,collider] of this.buildingColliders)if(!desired.has(key)){
      this.world.removeCollider(collider,true);this.buildingHandles.delete(collider.handle);
      this.buildingColliders.delete(key);
    }
    for(const key of desired)if(!this.buildingColliders.has(key)){
      const tile=this.buildingModel.tiles.get(key);
      const collider=this.world.createCollider(this.rapier.ColliderDesc.trimesh(
        new Float32Array(tile.vertices),new Uint32Array(tile.indices)).setFriction(.80));
      this.buildingColliders.set(key,collider);this.buildingHandles.add(collider.handle);
    }
    this.lastBuildingAnchor=[x,z];
    if(typeof this.world.updateSceneQueries==='function')this.world.updateSceneQueries();
    return this.buildingColliders.size;
  }
  // The exact Float32 vertices / Uint32 triangle winding rendered above are
  // passed to Rapier. Only vehicle asphalt gets wheel-supporting colliders.
  createColliders(rapier, world) {
    if (!this.loaded || !this.roadModel) throw Error('真實車行道路尚未載入');
    if (this.colliders.length) return this.colliders.length;
    this.rapier = rapier;this.world = world;
    try {
      // The upper ground is excavated around below-grade road ramps. Its
      // exact triangles match the visible terrain, preventing the previous
      // solid 2km ground cuboid from blocking underpass vehicles.
      const soil=world.createCollider(rapier.ColliderDesc.trimesh(
        new Float32Array(this.terrainModel.vertices),
        new Uint32Array(this.terrainModel.indices)).setFriction(.52));
      this.colliders.push(soil);this.groundHandles.add(soil.handle);
      // Recovery floor below the deepest underpass (not a real map surface).
      const recovery=world.createCollider(rapier.ColliderDesc.cuboid(1000,.10,1000)
        .setTranslation(0,this.terrainModel.recoveryY-.10,0).setFriction(.52));
      this.colliders.push(recovery);this.groundHandles.add(recovery.handle);
      for (const batch of this.roadModel.tiles.values()) {
        const collider = world.createCollider(rapier.ColliderDesc.trimesh(
          new Float32Array(batch.vertices), new Uint32Array(batch.indices)).setFriction(.72));
        this.colliders.push(collider);
        this.groundHandles.add(collider.handle);
      }
      // Barriers / retaining walls / piers are physically distinct from the
      // road: include them in collision-event telemetry, NOT wheel raycasts.
      for(const tile of this.structureModel?.tiles.values()||[]){
        if(!tile.physical)continue;
        const collider=world.createCollider(rapier.ColliderDesc.trimesh(
          new Float32Array(tile.vertices),new Uint32Array(tile.indices))
          .setFriction(tile.kind==='guardrail'?.65:.85));
        this.colliders.push(collider);
        this.structureHandles.add(collider.handle);
        if(tile.kind==='guardrail')this.railHandles.add(collider.handle);
        else this.barrierHandles.add(collider.handle);
      }
      if(this.buildingModel){const spawn=this.spawnPoint();this.syncBuildingColliders(spawn.x,spawn.z,245,true);}
      if (typeof world.updateSceneQueries === 'function') world.updateSceneQueries();
      return this.colliders.length+this.buildingColliders.size;
    } catch (error) {
      this.clearColliders();
      throw error;
    }
  }
  clearColliders() {
    if(this.world) {
      for(const collider of this.buildingColliders.values())this.world.removeCollider(collider,true);
      for (const collider of this.colliders) this.world.removeCollider(collider, true);
    }
    this.buildingColliders.clear();this.buildingHandles.clear();this.lastBuildingAnchor=null;
    this.colliders.length = 0;
    this.groundHandles.clear();
    this.railHandles.clear();this.barrierHandles.clear();this.structureHandles.clear();
    this.world = null;this.rapier = null;
  }
  closestRoad(x, z, maxDistance=90, elevationHint=null) {
    return this.roadModel?.closestRoad(x,z,maxDistance,elevationHint) || null;
  }
  spawnPoint() {if (!this.roadModel) throw Error('城市道路尚未載入'); return this.roadModel.pickSpawn();}
  // The city has no global scalar route s: teleports use pickSpawn().y.
  // Keep the legacy adapter method for engine compatibility only.
  position(_s, _side) {return {x: 0, y: CITY_ROAD_Y, z: 0};}
  resourceStats() {
    return {chunks: this.roadModel?.tiles.size ?? 0, ground: this.groundHandles.size,
      rails: this.railHandles.size, barriers: this.barrierHandles.size,
      obstacles: 0, buildings: this.buildingStats?.buildings ?? 0,
      buildingColliders:this.buildingHandles.size,
      streetTriangles:this.streetDetails?.stats.visualTriangles??0,
      flaggedBuildings:this.audit?.stats.overlappingBuildings??0,
      flaggedJunctions:this.junctionQuality?.stats.reviewJunctions??0,
      narrowRoads:this.wheelCoverage?.narrowCorridors.length??0,
      terrainTriangles:this.terrainModel?.stats.terrainTriangles??0,
      excavatedTerrainCells:this.terrainModel?.holes??0,
      structureRenderTiles:this.structureModel?.stats.renderTiles??0,
      structureCollisionTiles:this.structureModel?.stats.collisionTiles??0,
      structurePiers:this.structureModel?.stats.piers??0};
  }
  setDrivingView(active) {
    this.grid.visible = !active;
    this.outline.visible = !active;
    this.stationMarker.visible = !active && !this.buildingStats;
    this.scene.background.set(active ? 0xa2c0cb : 0x0c1924);
    this.scene.fog = active ? new THREE.Fog(0xa2c0cb, 190, 690) : null;
  }
  clearRoads() {
    if (this.colliders.length) throw Error('清除路面前需釋放 Rapier 碰撞體');
    for (const mesh of [...this.layers.children]) {
      this.layers.remove(mesh);
      mesh.geometry?.dispose();
    }
    for(const mesh of [...this.streetLayers.children]){
      this.streetLayers.remove(mesh);mesh.geometry.dispose();
    }
    this.clearDiagnosticGeometry();
    this.streetDetails=null;this.audit=null;this.coverage=null;
    this.clearStructureGeometry();
    this.terrainModel=null;
    this.junctionQuality=null;this.wheelCoverage=null;
    this.loaded = false;
    this.stats = null;
    this.roadModel = null;
  }
  dispose() {
    this.clearColliders();
    this.clearRoads();
    this.clearBuildings();this.buildingMaterial.dispose();
    this.ground.geometry.dispose();this.ground.material.dispose();
    this.recoveryGround.geometry.dispose();this.recoveryGround.material.dispose();
    this.outline.geometry.dispose();this.outline.material.dispose();
    this.grid.geometry.dispose();this.grid.material.dispose();
    this.stationMarker.geometry.dispose();this.stationMarker.material.dispose();
    for (const material of Object.values(this.materials)) material.dispose();
    for (const material of Object.values(this.streetMaterials)) material.dispose();
    for (const material of Object.values(this.structureMaterials)) material.dispose();
  }
}
