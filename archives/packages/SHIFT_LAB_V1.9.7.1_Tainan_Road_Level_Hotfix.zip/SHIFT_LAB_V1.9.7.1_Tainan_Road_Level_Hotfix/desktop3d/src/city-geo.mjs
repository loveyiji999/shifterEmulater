// SHIFT LAB v1.9.1: immutable real-world area and pure geospatial processing.
// Overture GeoJSON uses WGS84 (longitude, latitude). THREE world is x=east,
// z=north, y=height in meters. The local projection is intentionally limited
// to the 2 x 2 km Tainan Station square; vertical levels are estimated in V1.9.6.
export const TAINAN_STATION = Object.freeze({
  name: '臺南火車站', latitude: 22.9972062216332,
  longitude: 120.212369589515, widthMeters: 2000, heightMeters: 2000,
  reference: 'https://tcmb.culture.tw/zh-tw/detail?id=19981218000001&indexCode=BOCH_CountryCulture_11'
});
export const CITY_MAP_FORMAT = 'shiftlab.city.roads.v1';
export const CITY_MAP_PATH = './data/tainan-station-roads.json';
export const OVERTURE_ATTRIBUTION = '© OpenStreetMap contributors, Overture Maps Foundation';
const MAX_FEATURES = 100000;
const MAX_LINES = 40000;
const MAX_POINTS = 500000;
const EPSILON = 1e-7;

export function metersPerDegree(latitude) {
  if (!Number.isFinite(latitude) || Math.abs(latitude) >= 90) throw new Error('緯度超出可轉換範圍');
  const phi = latitude * Math.PI / 180;
  return {
    lon: 111412.84 * Math.cos(phi) - 93.5 * Math.cos(3 * phi) + 0.118 * Math.cos(5 * phi),
    lat: 111132.92 - 559.82 * Math.cos(2 * phi) + 1.175 * Math.cos(4 * phi) - 0.0023 * Math.cos(6 * phi)
  };
}

export function areaBounds(area = TAINAN_STATION) {
  const {lon, lat} = metersPerDegree(area.latitude);
  const dx = area.widthMeters / (2 * lon), dz = area.heightMeters / (2 * lat);
  return {west: area.longitude - dx, south: area.latitude - dz,
    east: area.longitude + dx, north: area.latitude + dz};
}

export function longitudeLatitudeToMeters(position, area = TAINAN_STATION) {
  if (!Array.isArray(position) || position.length < 2 ||
    !Number.isFinite(position[0]) || !Number.isFinite(position[1]) ||
    Math.abs(position[0]) > 180 || Math.abs(position[1]) > 90) {
    throw new Error('道路含有非有限值或無效的 WGS84 經緯度');
  }
  const scale = metersPerDegree(area.latitude);
  return [(position[0] - area.longitude) * scale.lon,
    (position[1] - area.latitude) * scale.lat];
}

export function metersToLongitudeLatitude(point, area = TAINAN_STATION) {
  if (!Array.isArray(point) || point.length < 2 || !point.slice(0, 2).every(Number.isFinite)) {
    throw new Error('無效的本地公尺座標');
  }
  const scale = metersPerDegree(area.latitude);
  return [area.longitude + point[0] / scale.lon, area.latitude + point[1] / scale.lat];
}

// Liang-Barsky clip in metric x/z space (not a geographic bbox filter).
export function clipLineToSquare(a, b, halfX = 1000, halfZ = 1000) {
  if (![...a, ...b, halfX, halfZ].every(Number.isFinite) || halfX <= 0 || halfZ <= 0)
    throw new Error('無效的幾何裁切輸入');
  const dx = b[0] - a[0], dz = b[1] - a[1];
  if (Math.hypot(dx, dz) <= EPSILON) return null;
  let begin = 0, end = 1;
  for (const [p, q] of [[-dx, a[0] + halfX], [dx, halfX - a[0]],
    [-dz, a[1] + halfZ], [dz, halfZ - a[1]]]) {
    if (Math.abs(p) <= EPSILON) {
      if (q < -EPSILON) return null;
    } else {
      const t = q / p;
      if (p < 0) begin = Math.max(begin, t);
      else end = Math.min(end, t);
      if (begin > end) return null;
    }
  }
  const p0 = [a[0] + begin * dx, a[1] + begin * dz];
  const p1 = [a[0] + end * dx, a[1] + end * dz];
  return Math.hypot(p1[0] - p0[0], p1[1] - p0[1]) <= EPSILON ? null : [p0, p1];
}

export function clipPolylineToSquare(points, halfX = 1000, halfZ = 1000) {
  if (!Array.isArray(points) || points.length < 2 || points.length > MAX_POINTS)
    throw new Error('道路线段包含無效或過多節點');
  const pieces = [];
  let active = null;
  const push = () => { if (active && active.length > 1) pieces.push(active); active = null; };
  const matches = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]) < 1e-5;
  for (let i = 1; i < points.length; i++) {
    const clipped = clipLineToSquare(points[i - 1], points[i], halfX, halfZ);
    if (!clipped) { push(); continue; }
    const [first, second] = clipped;
    if (!active || !matches(active.at(-1), first)) { push(); active = [first]; }
    if (!matches(active.at(-1), second)) active.push(second);
  }
  push();
  return pieces;
}

// Same XY clipping as clipPolylineToSquare, but also preserves fractional
// chainage along the ORIGINAL uncut Overture line for level_rules.between.
export function clipPolylineWithSourceRanges(points, halfX = 1000, halfZ = 1000) {
  if (!Array.isArray(points) || points.length < 2 || points.length > MAX_POINTS)
    throw new Error('道路原始中心線節點數不合法');
  const distances = [0];
  for (let i = 1; i < points.length; i++) {
    distances.push(distances.at(-1) + Math.hypot(points[i][0]-points[i-1][0],
      points[i][1]-points[i-1][1]));
  }
  const total = distances.at(-1);
  if (total < EPSILON) return [];
  const result = [];
  let active = null;
  const push = () => {if (active?.coordinates.length > 1) {
    result.push({coordinates:active.coordinates, sourceRange:[active.begin/total,active.end/total]});
  } active = null;};
  const matches = (a,b) => Math.hypot(a[0]-b[0],a[1]-b[1]) < 1e-5;
  for (let i = 1; i < points.length; i++) {
    const clipped = clipLineToSquare(points[i-1],points[i],halfX,halfZ);
    if (!clipped) {push();continue;}
    const [first,second] = clipped;
    const length = distances[i]-distances[i-1];
    const a = points[i-1], b = points[i], dx=b[0]-a[0], dz=b[1]-a[1];
    const t = p => length < EPSILON ? 0 : Math.max(0,Math.min(1,
      ((p[0]-a[0])*dx+(p[1]-a[1])*dz)/(length*length)));
    const begin = distances[i-1]+length*t(first);
    const end = distances[i-1]+length*t(second);
    if (!active || !matches(active.coordinates.at(-1),first)) {
      push();active = {coordinates:[first],begin,end};
    }
    if (!matches(active.coordinates.at(-1),second)) active.coordinates.push(second);
    active.end = end;
  }
  push();
  return result;
}

const VEHICLE_CLASSES = new Set(['motorway', 'trunk', 'primary', 'secondary', 'tertiary',
  'residential', 'unclassified', 'service', 'living_street', 'unknown']);

export function roadUse(segment) {
  if (segment.subtype === 'rail') return 'rail';
  if (segment.subtype !== 'road') return 'other';
  return VEHICLE_CLASSES.has(segment.roadClass) ? 'vehicle' : 'nonvehicle';
}

export function approximateRoadWidth(roadClass, subtype = 'road') {
  if (subtype === 'rail') return 2.2;
  const widths = {motorway: 12, trunk: 10, primary: 9, secondary: 8,
    tertiary: 7.5, residential: 6.2, service: 4.5, unclassified: 5.5,
    living_street: 4.5, pedestrian: 3.5, cycleway: 2.5,
    footway: 1.8, steps: 2.2, path: 2.0};
  return widths[roadClass] ?? 4.5;
}

function explicitWidth(props) {
  // 2026 Overture width rules vary in scope. Preserve all source rules in
  // metadata; use only a validated simple numeric value at this stage.
  const entry = Array.isArray(props.width_rules) ? props.width_rules.find(x =>
    x && Number.isFinite(x.value) && x.value >= 1 && x.value <= 40 && !x.between && !x.when) : null;
  return entry ? entry.value : null;
}

function verifyGeoJSONCollection(value, label) {
  if (!value || value.type !== 'FeatureCollection' || !Array.isArray(value.features))
    throw new Error(`${label} 必須是 Overture GeoJSON FeatureCollection`);
  if (value.features.length > MAX_FEATURES) throw new Error(`${label} 資料量超過預期限制`);
  return value.features;
}

// Consumers of this function must supply the genuine two Overture GeoJSON
// exports. No synthetic or OSM fallback is created or labeled as Overture.
export function prepareOvertureCityMap(segmentsGeoJSON, connectorsGeoJSON, options = {}) {
  const roadFeatures = verifyGeoJSONCollection(segmentsGeoJSON, 'segment');
  const connectorFeatures = verifyGeoJSONCollection(connectorsGeoJSON, 'connector');
  const halfX = TAINAN_STATION.widthMeters / 2, halfZ = TAINAN_STATION.heightMeters / 2;
  const segments = [], connectors = [], ids = new Set();
  let missingId = 0;
  for (const feature of roadFeatures) {
    if (feature?.type !== 'Feature' || feature?.geometry?.type !== 'LineString') continue;
    const props = feature.properties || {};
    if ((props.theme !== undefined && props.theme !== 'transportation') ||(props.type !== undefined && props.type !== 'segment'))
      throw new Error('輸入包含非 Overture transportation/segment 資料，不得標示為真實 Overture');
    const overtureId = props.id ?? feature.id; // GeoJSON may put feature ID in its envelope
    if (typeof overtureId !== 'string' || !overtureId.trim()) { missingId++; continue; }
    const coordinates = feature.geometry.coordinates;
    if (!Array.isArray(coordinates) || coordinates.length < 2) continue;
    const converted = coordinates.map(point => longitudeLatitudeToMeters(point));
    const clipped = clipPolylineWithSourceRanges(converted, halfX, halfZ);
    if (!clipped.length) continue;
    const roadClass = typeof props.class === 'string' ? props.class : 'unknown';
    const subtype = ['road', 'rail', 'water'].includes(props.subtype) ? props.subtype : 'other';
    const connectorRefs = Array.isArray(props.connectors) ? props.connectors
      .filter(c => c && typeof c.connector_id === 'string' && Number.isFinite(c.at) && c.at >= 0 && c.at <= 1)
      .map(c => ({id: c.connector_id, at: c.at})) : [];
    const name = typeof props.names?.primary === 'string' ? props.names.primary.slice(0, 120) : null;
    const width = explicitWidth(props) ?? approximateRoadWidth(roadClass, subtype);
    for (let i = 0; i < clipped.length; i++) {
      const id = overtureId + (clipped.length > 1 ? ':' + i : '');
      if (ids.has(id)) throw new Error('Overture 道路 ID 重複：' + id);
      ids.add(id);
      segments.push({id, sourceId: overtureId, subtype, roadClass, use: roadUse({subtype, roadClass}),
        name, widthMeters: width, coordinates: clipped[i].coordinates,
        sourceRange: clipped[i].sourceRange, connectorRefs,
        // Preserve source stacking metadata without fabricating a height.
        levelRules: Array.isArray(props.level_rules) ? props.level_rules : [],
        widthRules: Array.isArray(props.width_rules) ? props.width_rules : []});
      if (segments.length > MAX_LINES) throw new Error('裁切後道路數超出場景限制');
    }
  }
  if (missingId > 0) throw new Error('有 ' + missingId + ' 條道路缺乏 Overture feature ID');
  if (!segments.some(s => s.use === 'vehicle')) throw new Error('此範圍沒有可視化的車行道路，拒絕建立空白地圖');
  const connectorIds = new Set();
  for (const feature of connectorFeatures) {
    if (feature?.type !== 'Feature' || feature?.geometry?.type !== 'Point') continue;
    const props = feature.properties || {};
    if ((props.theme !== undefined && props.theme !== 'transportation') ||(props.type !== undefined && props.type !== 'connector'))
      throw new Error('connector 資料不是官方 Overture transportation/connector 格式');
    const overtureId = props.id ?? feature.id;
    if (typeof overtureId !== 'string' || !overtureId.trim()) throw new Error('connector 缺少 Overture feature ID');
    const coordinate = longitudeLatitudeToMeters(feature.geometry.coordinates);
    if (Math.abs(coordinate[0]) > halfX || Math.abs(coordinate[1]) > halfZ) continue;
    if (connectorIds.has(overtureId)) throw new Error('Overture connector ID 重複：' + overtureId);
    connectorIds.add(overtureId);
    connectors.push({id: overtureId, coordinates: coordinate});
  }
  return validateCityMap({format: CITY_MAP_FORMAT, area: {...TAINAN_STATION},
    source: {provider: 'Overture Maps Foundation', theme: 'transportation',
      license: 'ODbL-1.0', release: options.release || 'latest-via-STAC',
      attribution: OVERTURE_ATTRIBUTION,
      downloadedAt: options.downloadedAt || new Date().toISOString(),
      note: 'WGS84 XY precision and original feature chainage preserved; source levels are not surveyed metre elevations'},
    segments, connectors});
}

export function validateCityMap(map) {
  if (!map || map.format !== CITY_MAP_FORMAT || !Array.isArray(map.segments) ||
    !Array.isArray(map.connectors)) throw new Error('城市資料格式不符合 shiftlab.city.roads.v1');
  if (Math.abs(map.area?.latitude - TAINAN_STATION.latitude) > 1e-9 ||
    Math.abs(map.area?.longitude - TAINAN_STATION.longitude) > 1e-9 ||
    map.area?.widthMeters !== 2000 || map.area?.heightMeters !== 2000)
    throw new Error('城市區域不是指定的臺南車站中心 2×2 km');
  if (map.source?.provider !== 'Overture Maps Foundation' || map.source?.license !== 'ODbL-1.0' ||
    !map.source?.attribution?.includes('OpenStreetMap'))
    throw new Error('城市資料缺少 Overture 授權及來源資訊');
  if (map.segments.length > MAX_LINES || map.connectors.length > MAX_FEATURES)
    throw new Error('城市資料量超出安全限制');
  const idSet = new Set();
  for (const segment of map.segments) {
    if (!segment || typeof segment.id !== 'string' || !segment.id || idSet.has(segment.id) ||
      !['road', 'rail', 'water', 'other'].includes(segment.subtype) ||
      !['vehicle', 'nonvehicle', 'rail', 'other'].includes(segment.use) ||
      !Array.isArray(segment.coordinates) || segment.coordinates.length < 2 ||
      segment.coordinates.length > 30000 || !Number.isFinite(segment.widthMeters) ||
      segment.widthMeters < 0.5 || segment.widthMeters > 50)
      throw new Error('城市資料中有無效的道路 ID、類別、寬度或幾何');
    idSet.add(segment.id);
    for (const p of segment.coordinates) {
      if (!Array.isArray(p) || p.length !== 2 || !p.every(Number.isFinite) ||
        Math.abs(p[0]) > 1000.001 || Math.abs(p[1]) > 1000.001)
        throw new Error('道路幾何超出 2×2 km 裁切範圍');
    }
    if (segment.sourceRange !== undefined &&
      (!Array.isArray(segment.sourceRange) || segment.sourceRange.length !== 2 ||
       !segment.sourceRange.every(Number.isFinite) || segment.sourceRange[0] < -1e-6 ||
       segment.sourceRange[1] > 1+1e-6 || segment.sourceRange[0] > segment.sourceRange[1]))
      throw new Error('道路來源原始線段比例不合法');
    if (segment.levelRules !== undefined && (!Array.isArray(segment.levelRules) ||
      segment.levelRules.length > 200)) throw new Error('道路層級規則格式不合法');
    if (!Array.isArray(segment.connectorRefs) || segment.connectorRefs.length > 500)
      throw new Error('道路 connector 參照格式不正確');
    for (const c of segment.connectorRefs) {
      if (!c || typeof c.id !== 'string' || !Number.isFinite(c.at) || c.at < 0 || c.at > 1)
        throw new Error('不合法的路網 connector 參照');
    }
  }
  const connectorIds = new Set();
  for (const connector of map.connectors) {
    if (!connector || typeof connector.id !== 'string' || !connector.id || connectorIds.has(connector.id) ||
      !Array.isArray(connector.coordinates) || connector.coordinates.length !== 2 ||
      !connector.coordinates.every(Number.isFinite) ||
      connector.coordinates.some(x => Math.abs(x) > 1000.001))
      throw new Error('城市 connector 非法或重複');
    connectorIds.add(connector.id);
  }
  if (!map.segments.some(s => s.use === 'vehicle')) throw new Error('沒有真實車行道路；不使用假道路替代');
  return map;
}

export function cityStatistics(map) {
  validateCityMap(map);
  return {
    segments: map.segments.length, connectors: map.connectors.length,
    vehicular: map.segments.filter(s => s.use === 'vehicle').length,
    walking: map.segments.filter(s => s.use === 'nonvehicle').length,
    rail: map.segments.filter(s => s.use === 'rail').length,
    roadLengthKm: Number((map.segments.reduce((sum, s) =>
      sum + (s.use === 'vehicle' ? s.coordinates.slice(1).reduce((part, b, i) =>
        part + Math.hypot(b[0] - s.coordinates[i][0], b[1] - s.coordinates[i][1]), 0) : 0), 0) / 1000).toFixed(2))
  };
}
