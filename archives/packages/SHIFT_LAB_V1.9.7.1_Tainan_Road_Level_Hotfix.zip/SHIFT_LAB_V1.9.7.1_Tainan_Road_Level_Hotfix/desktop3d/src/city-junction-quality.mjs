// V1.9.5: Road-geometry QA candidates grounded in connector topology.
// The algorithm NEVER moves Overture features, guesses traffic control, or
// changes the road/collider meshes. Thresholds are engineering diagnostics.
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const angleDegrees=(a,b)=>Math.acos(clamp(a[0]*b[0]+a[1]*b[1],-1,1))*180/Math.PI;
const polygonArea=p=>!p?.length?0:Math.abs(p.reduce((sum,a,i)=>{
  const b=p[(i+1)%p.length];return sum+a[0]*b[1]-a[1]*b[0];
},0))*.5;

export function assessCityJunctionQuality(model,{limit=500}={}){
  if(!Array.isArray(model?.junctions)||!Array.isArray(model?.corridors))
    throw Error('需要帶連接點的真實 Overture 道路模型');
  if(!Number.isInteger(limit)||limit<1||limit>10000)throw Error('路口 QA 輸出限制無效');
  const stats={junctionsChecked:0,sharpArmPairs:0,shortLinkJunctions:0,
    abruptWidthJoinJunctions:0,oversizedHulls:0,reviewJunctions:0,
    reviewOnly:true,meaning:'Engineering flags on 2D estimated-width polygons; not verified road defects'};
  const issues=[];
  for(const j of model.junctions){
    stats.junctionsChecked++;
    const widths=j.node.arms.map(a=>a.widthMeters);
    const maxWidth=Math.max(...widths),minWidth=Math.min(...widths);
    let smallestAngle=180;
    for(let i=0;i<j.node.arms.length;i++)for(let k=i+1;k<j.node.arms.length;k++)
      smallestAngle=Math.min(smallestAngle,
        angleDegrees(j.node.arms[i].direction,j.node.arms[k].direction));
    const minimumLink=Math.min(...j.node.arms.map(a=>a.edge.length-
      a.edge.trims[0]-a.edge.trims[1]));
    const footprint=polygonArea(j.polygon);
    const reasons=[];
    if(smallestAngle<22){stats.sharpArmPairs++;reasons.push('sharp-arm-angle');}
    if(minimumLink<2.5){stats.shortLinkJunctions++;reasons.push('short-corridor');}
    if(j.degree===2&&maxWidth/minWidth>1.65){
      stats.abruptWidthJoinJunctions++;reasons.push('width-change-at-join');
    }
    if(footprint>maxWidth*maxWidth*3.1){
      stats.oversizedHulls++;reasons.push('large-convex-junction');
    }
    if(!reasons.length)continue;
    stats.reviewJunctions++;
    const score=(smallestAngle<10?4:smallestAngle<22?2:0)+
      (minimumLink<1?4:minimumLink<2.5?2:0)+
      (footprint>maxWidth*maxWidth*3.1?2:0)+
      (reasons.includes('width-change-at-join')?1:0);
    issues.push({id:j.id,type:j.type,x:j.point[0],z:j.point[1],degree:j.degree,
      minimumArmAngleDeg:Number(smallestAngle.toFixed(1)),
      remainingShortestLinkMeters:Number(minimumLink.toFixed(2)),
      hullAreaSqm:Number(footprint.toFixed(2)),
      maxWidthMeters:maxWidth,minWidthMeters:minWidth,
      widthEvidence:j.node.arms.every(a=>a.edge.widthSource==='source-rule')?'source-rule':'partly-estimated',
      reasons,score});
  }
  issues.sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));
  stats.issuesTruncated=Math.max(0,issues.length-limit);
  return {stats,issues:issues.slice(0,limit)};
}

import {atDistance} from './city-road-geometry.mjs';
import {createRoadTriangleIndex,pointOnAsphalt} from './city-street-audit.mjs';

export function auditCityWheelTrackSupport(model,{wheelHalfTrackMeters=.78,stepMeters=6,
  missLimit=100}={}){
  if(!model?.tiles||!Array.isArray(model?.corridors))throw Error('輪跡檢測需要有效車行路網');
  if(!Number.isFinite(wheelHalfTrackMeters)||wheelHalfTrackMeters<=0||wheelHalfTrackMeters>2||
    !Number.isFinite(stepMeters)||stepMeters<.5||stepMeters>100||
    !Number.isInteger(missLimit)||missLimit<1)throw Error('輪跡測試參數無效');
  const index=createRoadTriangleIndex(model), misses=[],narrowCorridors=[];
  let samples=0,outsideBounds=0,missesTotal=0;
  for(const edge of model.corridors){
    // A 1.5 m officially mapped passage cannot support both wheel centres of
    // a 1.56 m-track car. That is a WIDTH limit, NOT a collider gap.
    if(edge.widthMeters<2*(wheelHalfTrackMeters+.05)){
      narrowCorridors.push({edgeId:edge.id,widthMeters:edge.widthMeters,
        widthEvidence:edge.widthSource,lengthMeters:Number(edge.length.toFixed(2))});
      continue;
    }
    const start=edge.trims[0],end=edge.length-edge.trims[1];
    if(end<start)continue;
    const total=end-start;
    const count=Math.max(1,Math.ceil(total/stepMeters));
    for(let i=0;i<=count;i++){
      const along=start+total*i/count;
      const p=atDistance(edge.line,along);
      const before=atDistance(edge.line,Math.max(0,along-.35));
      const after=atDistance(edge.line,Math.min(edge.length,along+.35));
      const dx=after[0]-before[0],dz=after[1]-before[1],norm=Math.hypot(dx,dz);
      if(norm<.00001)continue;
      for(const side of [-1,1]){
        const x=p[0]-dz/norm*side*wheelHalfTrackMeters;
        const z=p[1]+dx/norm*side*wheelHalfTrackMeters;
        if(Math.abs(x)>998||Math.abs(z)>998){outsideBounds++;continue;}
        samples++;
        if(!pointOnAsphalt([x,z],index)){
          missesTotal++;
          if(misses.length<missLimit)misses.push({x:Number(x.toFixed(3)),z:Number(z.toFixed(3)),
            edgeId:edge.id,alongMeters:Number(along.toFixed(2)),side});
        }
      }
    }
  }
  return {samples,missesCount:missesTotal,misses,outsideBounds,narrowCorridors,
    wheelHalfTrackMeters,stepMeters,
    limitation:'2D wheel-centreline support only. Does not establish physical wheel contact, elevation, direction legality, or real-world lane width.'};
}
