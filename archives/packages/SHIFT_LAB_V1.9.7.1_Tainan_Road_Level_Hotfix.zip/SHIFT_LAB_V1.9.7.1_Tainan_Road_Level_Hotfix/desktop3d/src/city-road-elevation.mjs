// V1.9.6: topology-aware 3D profile from real Overture level_rules.
// Overture levels describe STACK ORDER, NOT surveyed elevations. The metre
// offset and maximum ramp grade below are explicitly engineering estimates.
// Nothing here changes the Overture XY centerlines, widths, or connector IDs.
import {CITY_ROAD_Y} from './city-vertical-datum.mjs';
export const LEVEL_HEIGHT_ESTIMATE_METERS = 5.25;
export const MAX_ESTIMATED_GRADE = 0.075;
const EPS = 1e-8;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

function validRule(rule) {
  if (!rule || !Number.isInteger(rule.value) || Math.abs(rule.value) > 6) return false;
  if (rule.between == null) return true;
  return Array.isArray(rule.between) && rule.between.length === 2 &&
    rule.between.every(v => Number.isFinite(v) && v >= 0 && v <= 1) &&
    rule.between[1] >= rule.between[0];
}

// Fraction on a clipped segment, mapped back to the uncut Overture feature.
// This matters for level_rules.between and must not be guessed from local s.
export function corridorLevelIntervals(segment, startMeters, endMeters, wholeLength) {
  const range = segment.sourceRange || [0, 1];
  const rangeLength = range[1] - range[0];
  const from = range[0] + rangeLength * startMeters / wholeLength;
  const to = range[0] + rangeLength * endMeters / wholeLength;
  const intervals = [];
  for (const rule of segment.levelRules || []) {
    if (!validRule(rule) || rule.value === 0) continue;
    const bounds = rule.between == null ? [0, 1] : rule.between;
    const low = Math.max(from, bounds[0]);
    const high = Math.min(to, bounds[1]);
    if (high - low < EPS) continue;
    const factor = (endMeters - startMeters) / Math.max(EPS, to - from);
    intervals.push({from: clamp((low - from) * factor, 0, endMeters - startMeters),
      to: clamp((high - from) * factor, 0, endMeters - startMeters),
      level: rule.value, height: rule.value * LEVEL_HEIGHT_ESTIMATE_METERS});
  }
  return intervals;
}

// Max heap: a level annotation can affect only physically CONNECTED roads.
// XY-crossing roads without an Overture connector remain separate in 3D.
class MaxHeap {
  constructor(){this.a=[];}
  push(item){const a=this.a;let i=a.length;a.push(item);while(i>0){const p=(i-1)>>1;
    if(a[p].weight>=item.weight)break;a[i]=a[p];i=p;}a[i]=item;}
  pop(){const a=this.a,root=a[0],last=a.pop();if(a.length){let i=0;while(true){
    const l=i*2+1,r=l+1;if(l>=a.length)break;
    const c=r<a.length&&a[r].weight>a[l].weight?r:l;
    if(a[c].weight<=last.weight)break;a[i]=a[c];i=c;
  }a[i]=last;}return root;}
  get length(){return this.a.length;}
}

export function applyCityRoadElevations(corridors, {mode = 'source-levels'} = {}) {
  if (mode !== 'source-levels' && mode !== 'flat') throw Error('不支援的道路高程模式');
  const links = new Map(), nodePos = new Map(), nodeNeg = new Map();
  const connect = (node, edge) => {if (!links.has(node)) links.set(node, []);links.get(node).push(edge);};
  for (const edge of corridors) {connect(edge.from, edge);connect(edge.to, edge);}
  function propagate(sign) {
    const values = sign === 1 ? nodePos : nodeNeg;
    const heap = new MaxHeap();
    const offer = (node, weight) => {
      if (weight <= EPS || weight <= (values.get(node) || 0) + EPS) return;
      values.set(node, weight);heap.push({node, weight});
    };
    if (mode !== 'flat') for (const edge of corridors) for (const interval of edge.levelIntervals || []) {
      if (Math.sign(interval.height) !== sign) continue;
      const h = Math.abs(interval.height);
      // A connector's trim is a LEVEL landing. The rise must be reached
      // BEFORE it, not by climbing across the centre of the intersection.
      const [fromTrim=0,toTrim=0]=edge.trims||[];
      offer(edge.from, h - MAX_ESTIMATED_GRADE * Math.max(0,interval.from-fromTrim));
      offer(edge.to, h - MAX_ESTIMATED_GRADE * Math.max(0,edge.length-toTrim-interval.to));
    }
    while (heap.length) {
      const {node, weight} = heap.pop();
      if (weight + EPS < values.get(node)) continue;
      for (const edge of links.get(node) || []) {
        const next = edge.from === node ? edge.to : edge.from;
        const [fromTrim=0,toTrim=0]=edge.trims||[];
        const climbDistance=Math.max(0,edge.length-fromTrim-toTrim);
        offer(next,weight-climbDistance*MAX_ESTIMATED_GRADE);
      }
    }
  }
  propagate(1);propagate(-1);
  let elevated = 0, depressed = 0, peak = 0, trough = 0, steepest = 0, annotated = 0;
  for (const edge of corridors) {
    if (edge.levelIntervals?.length) annotated++;
    const fromPos = nodePos.get(edge.from) || 0, toPos = nodePos.get(edge.to) || 0;
    const fromNeg = nodeNeg.get(edge.from) || 0, toNeg = nodeNeg.get(edge.to) || 0;
    const [fromTrim=0,toTrim=0]=edge.trims||[];
    edge.heightOffsetAt = s => {
      const u = clamp(s, 0, edge.length);
      // Connector landing zones are constant-height; outside them the same
      // maximum-grade envelopes remain continuous across adjacent edges.
      const distFrom=Math.max(0,u-fromTrim);
      const distTo=Math.max(0,edge.length-toTrim-u);
      let up = Math.max(0, fromPos - MAX_ESTIMATED_GRADE * distFrom,
        toPos - MAX_ESTIMATED_GRADE * distTo);
      let down = Math.max(0, fromNeg - MAX_ESTIMATED_GRADE * distFrom,
        toNeg - MAX_ESTIMATED_GRADE * distTo);
      if (mode !== 'flat') for (const interval of edge.levelIntervals || []) {
        const dist = Math.max(interval.from - u, 0, u - interval.to);
        const value = Math.abs(interval.height) - MAX_ESTIMATED_GRADE * dist;
        if (interval.height > 0) up = Math.max(up, value);
        else down = Math.max(down, value);
      }
      return up - down;
    };
    edge.heightAt = s => edge.heightOffsetAt(s) + CITY_ROAD_Y;
    edge.gradeAt = s => {
      const delta = Math.min(0.5, edge.length * .25);
      const left=clamp(s-delta,0,edge.length),right=clamp(s+delta,0,edge.length);
      return (edge.heightAt(right)-edge.heightAt(left))/Math.max(EPS,right-left);
    };
    const samples = Math.max(2, Math.ceil(edge.length / 3));
    let hasUp = false, hasDown = false, last = edge.heightOffsetAt(0);
    peak = Math.max(peak, last);trough = Math.min(trough, last);
    for (let k=1;k<=samples;k++) {
      const y = edge.heightOffsetAt(edge.length*k/samples);
      peak = Math.max(peak,y);trough = Math.min(trough,y);
      if (y > .025 || last > .025) hasUp = true;
      if (y < -.025 || last < -.025) hasDown = true;
      steepest = Math.max(steepest, Math.abs(y-last)*samples/edge.length);
      last = y;
    }
    if (hasUp) elevated++;
    if (hasDown) depressed++;
  }
  return {mode, levelHeightEstimateMeters: LEVEL_HEIGHT_ESTIMATE_METERS,
    targetRampGrade: MAX_ESTIMATED_GRADE, annotatedCorridors: annotated,
    elevatedCorridors:elevated, depressedCorridors:depressed,
    maximumOffsetMeters:Number(peak.toFixed(3)), minimumOffsetMeters:Number(trough.toFixed(3)),
    measuredMaxGrade:Number(steepest.toFixed(4)), sourceHeightSurveyed:false,
    levelJunctionCaps:true, geometricLandingDistance:true,
    heightEvidence:'Overture level_rules (stack ordering) + estimated clearance/transition; no DEM or survey'};
}
