import * as THREE from 'three';

// Same seeded route centerline and crossfall geometry as SHIFT LAB's physics.html.
// Collider windows are bound to arc-length, not camera position: hairpins cannot
// reuse a nearby but unrelated road segment.
export class RoadWorld {
  constructor(rapier, world, scene, physics) {
    this.rapier = rapier;
    this.world = world;
    this.scene = scene;
    this.physics = physics;
    this.chunks = new Map();
    this.groundHandles = new Set();
    this.railHandles = new Set();
    this.obstacleHandles = new Set();
    this.barrierHandles = new Set();
    this.surfaceMaterial = new THREE.MeshStandardMaterial({color:0x344149,roughness:.93,side:THREE.DoubleSide});
    this.soilMaterial = new THREE.MeshStandardMaterial({color:0x405247,roughness:1});
    this.railMaterial = new THREE.MeshStandardMaterial({color:0x95a9af,metalness:.4,roughness:.56});
    this.markMaterial = new THREE.MeshStandardMaterial({color:0xe6d9aa,roughness:.89});
    this.leafMaterial = new THREE.MeshStandardMaterial({color:0x326452,roughness:1});
    this.trunkMaterial = new THREE.MeshStandardMaterial({color:0x6b5642,roughness:1});
    this.shoulderMaterial = new THREE.MeshStandardMaterial({color:0x48545a,roughness:.97});
  }
  position(s, side) {
    const p = this.physics.roadPointAt(Math.max(0,Math.min(this.physics.roadTotalDistance(),s)));
    return {x:p.x+Math.cos(p.heading)*side,
      y:p.y+this.physics.roadCrossElevation(p,side),
      z:p.z-Math.sin(p.heading)*side};
  }
  makeChunk(index) {
    const width = [-14,-6,-5.2,-3.4,0,3.4,5.2,6,14];
    const s0 = index*100, end = Math.min((index+1)*100,this.physics.roadTotalDistance());
    if(end <= s0+2)return null;
    const count = Math.ceil((end-s0)/4);
    const vertices=[];
    for(let n=0;n<=count;n++){
      const s=s0+(end-s0)*n/count;
      for(const lateral of width){const p=this.position(s,lateral);vertices.push(p.x,p.y,p.z);}
    }
    const indices=[];
    for(let n=0;n<count;n++)for(let j=0;j<width.length-1;j++){
      const a=n*width.length+j,b=a+1,c=a+width.length,d=c+1;
      // Winding gives upward triangle normals for a forward +Z road.
      indices.push(a,c,b,b,c,d);
    }
    const v=new Float32Array(vertices),tri=new Uint32Array(indices);
    const collider=this.world.createCollider(this.rapier.ColliderDesc.trimesh(v,tri).setFriction(.65));
    this.groundHandles.add(collider.handle);
    const geo=new THREE.BufferGeometry();
    geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
    // The Rapier triangles above stay byte-identical. Rendering only is grouped
    // into THREE materials (3 draw groups per chunk, not 200+ per chunk).
    const renderGroups=[[],[],[]];
    for(let n=0;n<count;n++)for(let j=0;j<width.length-1;j++){
      const group=j===0||j===7?1:j===1||j===6?2:0;
      const offset=(n*(width.length-1)+j)*6;
      for(let k=0;k<6;k++)renderGroups[group].push(indices[offset+k]);
    }
    geo.setIndex(renderGroups.flat());geo.computeVertexNormals();
    let start=0;
    for(let material=0;material<renderGroups.length;material++){
      geo.addGroup(start,renderGroups[material].length,material);
      start+=renderGroups[material].length;
    }
    const mesh=new THREE.Mesh(geo,[this.surfaceMaterial,this.soilMaterial,this.shoulderMaterial]);
    mesh.receiveShadow=true;
    this.scene.add(mesh);
    const rails=[];
    const decorations=[];
    // The center line and verge foliage are chunk-owned. They are removed
    // together with the same road collider on map regeneration or streaming.
    for(let s=s0+9;s<end-4;s+=17){
      const p=this.position(s,0),heading=this.physics.roadPointAt(s).heading;
      const strip=new THREE.Mesh(new THREE.BoxGeometry(.11,.025,5),this.markMaterial);
      strip.position.set(p.x,p.y+.055,p.z);strip.rotation.y=heading;
      this.scene.add(strip);decorations.push(strip);
    }
    const hash=(Math.imul(index+17,1664525)^(this.physics.route.seedHash>>>0))>>>0;
    for(let side of [-1,1])for(let k=0;k<2;k++){
      const s=Math.min(end-5,s0+16+k*36+(hash%13));
      const shift=side*(10+(hash%4));
      const point=this.position(s,shift);
      const tree=new THREE.Group();tree.position.set(point.x,point.y,point.z);
      const height=2.3+((hash>>>(k*3))%8)*.2;
      const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.11,.16,height*.42,5),this.trunkMaterial);
      trunk.position.y=height*.21;
      const crown=new THREE.Mesh(new THREE.ConeGeometry(height*.38,height*.84,7),this.leafMaterial);
      crown.position.y=height*.77;tree.add(trunk,crown);
      this.scene.add(tree);decorations.push(tree);
    }
    // Guardrails are true 3D colliders with CCD chassis contact. Segment length
    // stays small enough for hairpin bends not to cut across the carriageway.
    const steps=Math.ceil((end-s0)/5);
    for(let i=0;i<steps;i++){
      const sa=s0+(end-s0)*i/steps,sb=s0+(end-s0)*(i+1)/steps;
      const midS=(sa+sb)/2,mid=this.physics.roadPointAt(midS);
      for(const sign of [-1,1]){
        if(!this.physics.roadRailEnabled(mid,sign))continue;
        const a=this.position(sa,sign*4.96),b=this.position(sb,sign*4.96);
        const length=Math.hypot(b.x-a.x,b.z-a.z)+.07;
        const center={x:(a.x+b.x)/2,y:(a.y+b.y)/2+.57,z:(a.z+b.z)/2};
        const angle=Math.atan2(b.x-a.x,b.z-a.z);
        const quat={x:0,y:Math.sin(angle/2),z:0,w:Math.cos(angle/2)};
        const descriptor=this.rapier.ColliderDesc.cuboid(.14,.41,length/2)
          .setTranslation(center.x,center.y,center.z).setRotation(quat)
          .setFriction(.45).setRestitution(.10);
        const rail=this.world.createCollider(descriptor);
        this.railHandles.add(rail.handle);rails.push(rail);
        const railMesh=new THREE.Mesh(new THREE.BoxGeometry(.28,.82,length),this.railMaterial);
        railMesh.position.set(center.x,center.y,center.z);
        railMesh.quaternion.set(quat.x,quat.y,quat.z,quat.w);
        railMesh.castShadow=true;this.scene.add(railMesh);
        rails.push(railMesh);
      }
    }
    return {collider,mesh,rails,decorations};
  }
  disposeChunk(index,chunk){
    this.groundHandles.delete(chunk.collider.handle);
    this.world.removeCollider(chunk.collider,true);
    this.scene.remove(chunk.mesh);chunk.mesh.geometry.dispose();
    for(const rail of chunk.rails){
      if(rail instanceof THREE.Object3D){
        this.scene.remove(rail);rail.geometry.dispose();
      }else{
        this.railHandles.delete(rail.handle);this.world.removeCollider(rail,true);
      }
    }
    for(const item of chunk.decorations||[]){
      this.scene.remove(item);
      item.traverse(mesh=>{if(mesh.geometry)mesh.geometry.dispose();});
    }
    this.chunks.delete(index);
  }
  clear(){
    for(const [index,chunk] of [...this.chunks])this.disposeChunk(index,chunk);
    // AcceptanceObstacles.dispose() must run before clear(); foreign ground
    // handles (e.g. ramp) are never silently deleted by this RoadWorld.
  }
  resourceStats(){
    return {chunks:this.chunks.size,ground:this.groundHandles.size,
      rails:this.railHandles.size,barriers:this.barrierHandles.size,
      obstacles:this.obstacleHandles.size};
  }
  assertClean(){
    const stats=this.resourceStats();
    if(Object.values(stats).some(count=>count!==0))
      throw new Error('道路重建後仍殘留碰撞資源：'+JSON.stringify(stats));
    return true;
  }
  ensure(s){
    const here=Math.floor(Math.max(0,s)/100);
    const begin=Math.max(0,here-2),end=here+4;
    for(let i=begin;i<=end;i++){
      if(!this.chunks.has(i)){
        const chunk=this.makeChunk(i);
        if(chunk)this.chunks.set(i,chunk);
      }
    }
    for(const [index,chunk] of this.chunks){
      if(index>=here-3&&index<=here+5)continue;
      this.disposeChunk(index,chunk);
    }
  }
}
