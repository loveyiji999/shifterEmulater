import * as THREE from 'three';
import RAPIER from '@dimforge/rapier3d-compat';
import {RoadWorld} from './road.mjs';
import {RapierChassisBridge} from './chassis.mjs';
import {AcceptanceObstacles} from './obstacles.mjs';
import {SCENARIOS,TEST_ORDER,gradeScenario} from './scenarios.mjs';
import {legacyDirectionalKey,legacySteerFromVisualAxis,visualSteeringFromLegacy,visualDirectionLabel} from './steering-input.mjs';
import {REFERENCE_MAP,DEFAULT_MAP,MAP_FIELDS,normalizeMapConfig,readMapDocument,serializeMap,sameMap,makeMapSeed,describeRoute} from './procedural-map.mjs';
import {createGameModes} from './game-modes.mjs';
import {automaticClutch,isAutomaticMode} from './automatic-transmission.mjs';
import {engageParkedManualGear} from './manual-gear.mjs';
import {checkAutomaticRange,automaticRangeRequest,automaticDisplayGear} from './automatic-range.mjs';
import {assertPhysicsHealth} from './physics-health.mjs';
import {CityRoadWorld} from './city-world.mjs';
import {CITY_MAP_PATH, prepareOvertureCityMap, validateCityMap, cityStatistics, metersToLongitudeLatitude} from './city-geo.mjs';
import {CITY_BUILDING_FORMAT,CITY_BUILDING_PATH,prepareOvertureBuildingMap} from './city-buildings-geo.mjs';

const $=id=>document.getElementById(id);
const canvas=$('view'),overlay=$('screen-overlay'),message=$('overlay-message');
const frame=$('physics'),gearSelect=$('gear');
const FIXED_DT=1/120;
let d=null,road=null,bridge=null,obstacles=null,world=null,renderer=null,scene=null,camera=null,vehicle=null;
let paused=false,locked=false,accumulator=0,prevFrame=performance.now(),lastHud=0,renderFPS=60,dropSteps=0;
let chosenPad='auto',lastPadLabel='',lastPadIndex=null,steerFiltered=0,physicsMs=0;
let scenarioId='free',lastResult=null,suiteResults=[],labReady=false;
let visualVehicleId='standard';
let cityWorld=null,cityMap=null,cityLoadError='尚未載入 Overture 真實資料';
let cityBuildingsError='尚未下載 Overture 真實建築資料';
let cityZoom=2600,cityCameraBackup=null,cityCameraTarget=new THREE.Vector3(0,0,0);
let cityIssueCursor=-1,cityJunctionCursor=-1,cityDiagnosticLast=0;
let driveEnvironment='procedural';
let gameModes=null,userMapConfig={...DEFAULT_MAP};
const MAP_STORAGE_KEY='shiftlab.v189.procedural-map';
const PREFERENCE_KEY='shiftlab.v189.settings'; // Preserve saved v1.8.9 choices.
const preferenceIds=['car-preset','road-surface','abs-toggle','tcs-toggle','esc','feel',
  'handling-balance','brake-bias','steering-preset','pad-invert','drive-mode','camera-mode'];
function savePreferences(){
  const record={};
  for(const id of preferenceIds){const el=$(id);if(el)record[id]=el.type==='checkbox'?el.checked:el.value;}
  try{localStorage.setItem(PREFERENCE_KEY,JSON.stringify(record));}catch{}
}
function restorePreferences(){
  try{
    const record=JSON.parse(localStorage.getItem(PREFERENCE_KEY)||'null');
    if(!record||typeof record!=='object')return;
    for(const id of preferenceIds){const el=$(id),value=record[id];if(!el)continue;
      if(el.type==='checkbox'&&typeof value==='boolean')el.checked=value;
      else if(typeof value==='string'&&[...el.options].some(item=>item.value===value))el.value=value;}
  }catch{}
}

function restoreMapPreference(){
  try{
    const str=localStorage.getItem(MAP_STORAGE_KEY);
    if(str)return normalizeMapConfig(JSON.parse(str),true);
  }catch(error){console.warn('Saved road config invalid:',error);}
  return {...DEFAULT_MAP};
}
function readMapForm(){
  return normalizeMapConfig({generator:Number($('map-generator').value),seed:$('map-seed').value,
    ...Object.fromEntries(MAP_FIELDS.map(key=>[key,Number($('map-'+key).value)]))},true);
}
function fillMapForm(config){
  $('map-generator').value=String(config.generator??1);
  $('map-seed').value=config.seed;
  for(const key of MAP_FIELDS)$('map-'+key).value=String(config[key]);
  updateMapFieldLabels();
}
function updateMapFieldLabels(){
  for(const key of MAP_FIELDS)$('map-'+key+'-val').textContent=$('map-'+key).value+'%';
}
function mapMessage(text,error=false){
  const el=$('map-message');el.textContent=text;el.style.color=error?'#ffaaa8':'';
}
function routePreview(){
  if(!d)return;
  const canvas=$('route-preview'),context=canvas.getContext('2d');
  const width=canvas.width,height=canvas.height;
  context.clearRect(0,0,width,height);context.fillStyle='#071723';context.fillRect(0,0,width,height);
  const route=d.route,limit=Math.min(3700,d.roadTotalDistance());
  const pts=route.points.filter((p,i)=>p.s<=limit&&i%4===0);
  if(pts.length<2)return;
  const minX=Math.min(...pts.map(p=>p.x)),maxX=Math.max(...pts.map(p=>p.x));
  const minZ=Math.min(...pts.map(p=>p.z)),maxZ=Math.max(...pts.map(p=>p.z));
  const scale=Math.min((width-46)/Math.max(70,maxX-minX),(height-32)/Math.max(70,maxZ-minZ));
  const cx=(minX+maxX)/2,cz=(minZ+maxZ)/2;
  const xy=p=>[width/2+(p.x-cx)*scale,height/2-(p.z-cz)*scale];
  context.lineWidth=3;context.strokeStyle='#2e665c';context.beginPath();
  pts.forEach((p,i)=>{const [x,y]=xy(p);i?context.lineTo(x,y):context.moveTo(x,y);});context.stroke();
  context.lineWidth=1.5;context.strokeStyle='#98edd1';context.stroke();
  for(const [p,color] of [[pts[0],'#f2c878'],[pts.at(-1),'#9ad8ff']]){
    const [x,y]=xy(p);context.beginPath();context.arc(x,y,4.5,0,Math.PI*2);
    context.fillStyle=color;context.fill();
  }
  context.fillStyle='#9bbac8';context.font='12px system-ui';
  context.fillText('前 '+(limit/1000).toFixed(1)+' km · 平面路線預覽',13,18);
}
function updateMapInfo(){
  if(!d)return;
  const stats=describeRoute(d.route);
  $('map-stats').replaceChildren();
  for(const value of ['v'+stats.generator+' 生成器',stats.distanceKm+' km',stats.bends+' 彎',stats.hairpins+' 髮夾彎',
    stats.climbs+' 上坡',stats.descents+' 下坡',
    ...(stats.quality?[stats.quality.ok?'幾何檢查 PASS':'幾何檢查 FAIL',
      '最小間距 '+(stats.quality.minNonlocalDistanceMeters?.toFixed(1)??'—')+' m']:[])]){
    const item=document.createElement('strong');item.textContent=value;$('map-stats').append(item);
  }
  routePreview();
}
function rebuildRoad(config){
  if(!d||!road||!obstacles)throw Error('3D 場景尚未建立');
  if(driveEnvironment==='city')leaveCityDriving();
  const prior={...d.route.config};
  const priorDistance=d.route.distance;
  // Destroy BOTH acceptance and route colliders before swapping centerlines.
  // The source generator remains the only authority for geometry and bank.
  const install=next=>{
    obstacles.dispose();obstacles.activeScenario='free';
    road.clear();road.assertClean();
    d.generateRoad(next);d.route.gradeMode='route';
    road.ensure(Math.max(70,Math.min(priorDistance,d.roadTotalDistance())));
    if(typeof world.updateSceneQueries==='function')world.updateSceneQueries();
  };
  try{install(config);updateMapInfo();}
  catch(error){
    try{install(prior);updateMapInfo();}
    catch(rollback){throw new Error('道路重建失敗，且舊道路無法還原：'+error.message+' / '+rollback.message);}
    throw new Error('道路重建失敗；已還原原始地圖：'+error.message);
  }
}
function ensureScenarioMap(id){
  const desired=id==='free'?userMapConfig:REFERENCE_MAP;
  if(!sameMap(d.route.config,desired))rebuildRoad(desired);
}
function applyMap(config){
  if(locked||!labReady)throw Error('正在驗收或 3D 引擎未就緒');
  const normalized=normalizeMapConfig(config,true);
  const previous={...userMapConfig};
  rebuildRoad(normalized);userMapConfig=normalized;
  try{resetDriving('free');}
  catch(error){userMapConfig=previous;rebuildRoad(previous);resetDriving('free');throw error;}
  try{localStorage.setItem(MAP_STORAGE_KEY,JSON.stringify(normalized));}catch{}
  setPause(true);
  fillMapForm(normalized);
  mapMessage('地圖已更新，車輛回到起點。返回駕駛即可遊玩。');
}
function previewNextBend(){
  if(locked||!labReady)throw Error('3D 引擎尚未就緒');
  if(driveEnvironment==='city'){leaveCityDriving();resetDriving('free');}
  if(scenarioId!=='free')resetDriving('free');
  const bend=d.route.segments.find(x=>x.type!=='straight'&&x.start>d.route.distance+20);
  if(!bend)throw Error('目前地圖沒有可預覽的下一個彎道');
  d.reset();
  const target=d.roadPointAt(Math.max(0,bend.start-65));
  road.ensure(target.s);bridge.teleport({roadPoint:target});
  d.route.distance=target.s;d.vehicleMotion.routeS=target.s;
  updateMapInfo();setPause(true);
  mapMessage('已將車輛移至彎道前 65 公尺；返回駕駛後可繼續行駛。');
}
function openGameMode(next){
  if(locked||!gameModes)return;
  // On leaving QA, restore the player's seed AND remove all test obstacles.
  if(next==='drive'&&scenarioId!=='free')resetDriving('free');
  gameModes.open(next);
}
const autoDrive={lastShiftTime:-100,shiftTarget:0};
let autoRange='P'; // P is the safe starting range; not a mechanical gear number.
let rangeNoticeTimer=null;
function showRangeWarning(text){
  const label=$('range-message');label.textContent=text;
  if(rangeNoticeTimer!==null)clearTimeout(rangeNoticeTimer);
  rangeNoticeTimer=setTimeout(()=>{label.textContent='';rangeNoticeTimer=null;},2800);
}
function driveFocus(){
  const active=document.activeElement;
  if(active&&active!==canvas&&typeof active.blur==='function')active.blur();
  canvas.focus({preventScroll:true});
}
function driveStatus(text){$('input-status').textContent=text;}
function syncTransmissionUI(){
  const automatic=isAutomaticMode($('drive-mode').value);
  // Only PRND is selectable in automatic; only mechanical gears in manual.
  gearSelect.disabled=locked||automatic;
  $('auto-range').disabled=locked||!automatic;
  $('auto-range').value=autoRange;
  $('auto-shifter').hidden=!automatic;
  for(const button of document.querySelectorAll('#auto-shifter [data-range]')){
    const selected=button.dataset.range===autoRange;
    button.setAttribute('aria-pressed',String(selected));
    button.disabled=locked;
  }
  $('gear-mode-hint').textContent=automatic?
    '自排：P 駐車／R 倒車／N 空檔／D 自動前進。行駛時煞停並踩住煞車才能切 P／R／D；F 鍵 D、R 倒車、N 空檔、P 駐車。':
    '手排：駕駛時按住 Shift + 數字鍵／R；在設定畫面停穩後選檔，會經原始離合器及同步器入檔。';
}
function selectAutomaticRange(target){
  if(!d||locked||scenarioId!=='free'||!isAutomaticMode($('drive-mode').value))return false;
  const v=bridge?.rigidBody?.linvel(),horizontal=v?Math.hypot(v.x,v.z):0;
  const speed=Math.max(Math.abs(d.state.velocity),horizontal);
  const brake=Math.max(d.inputKeys.has('s')?1:0,d.hostControls.brake||0,d.state.brake||0);
  // Settings is paused and cannot depress the physical brake. Treat the
  // stationary paused panel as a held brake; movement checks still apply.
  const result=checkAutomaticRange({current:autoRange,target,speedMps:speed,
    brake,paused:paused&&gameModes?.mode==='settings',pendingGear:d.state.pendingGear});
  if(!result.ok){
    driveStatus('自排拒絕：'+result.reason);
    showRangeWarning(result.reason);
    $('auto-range').value=autoRange;
    return false;
  }
  autoRange=target;
  d.hostControls.parkPawl=target==='P';
  if(target==='P'||target==='N')d.hostControls.clutch=1;
  driveStatus('自排：'+result.reason);
  $('range-message').textContent='';
  syncTransmissionUI();
  updateHud(true);
  return true;
}
function requestDriverGear(gear){
  if(!d||locked||isAutomaticMode($('drive-mode').value))return false;
  return d.requestGear(gear);
}
function setPause(value){
  paused=!!value;accumulator=0;
  $('pause').textContent=paused?'繼續':'暫停';
}

const binding={axis:0,gas:7,brake:6,clutch:4};
const keys={KeyW:'w',ArrowUp:'w',KeyS:'s',ArrowDown:'s',KeyA:'a',ArrowLeft:'a',KeyD:'d',ArrowRight:'d',ShiftLeft:'shift',ShiftRight:'shift'};
const trackedKeys=new Set();

// City preview and city driving use the SAME scene, mesh, and Overture data.
// The procedural track stays available for calibration and regression QA.
function cityStatus(message,error=false){
  const status=$('city-status'),detail=$('city-summary');
  if(!status||!detail)return;
  if(cityMap){
    const stats=cityStatistics(cityMap);
    status.textContent='Overture 已載入 · '+stats.vehicular+' 條車行道路';
    status.style.color='#79eac5';
    detail.textContent='車行 '+stats.vehicular+' 段 · '+cityWorld.stats.tJunctions+' 個 T 字路口 · '+
      cityWorld.stats.crossJunctions+' 個四向路口 · '+cityWorld.stats.collisionTiles+
      ' 個碰撞網格 · 車行中心線 '+stats.roadLengthKm+' km · 立體來源層級 '+cityWorld.stats.annotatedCorridors+' 段 · '+cityMap.source.release;
  }else{
    status.textContent='真實資料尚未載入';status.style.color='#ffd59d';
    detail.textContent=message||cityLoadError;
  }
  $('city-drive').disabled=!cityMap||locked;
  $('drive-tainan').disabled=!cityMap||locked;
  $('city-message').textContent=error?'資料驗證失敗：'+message:(message||'');
  cityBuildingsStatus();
  refreshCityDiagnostics();
}
function cityBuildingsStatus(){
  const label=$('city-buildings-status');
  if(!label||!cityWorld)return;
  const b=cityWorld.buildingStats;
  label.textContent=b
    ? '真實建築 '+b.buildings+' 棟 / '+b.renderedPolygons+' 個量體 · 來源高度 '+b.sourceHeight+
      ' 棟 · 樓層估高 '+b.floorEstimated+' 棟 · 預設估高 '+b.defaultEstimated+' 棟 · '+cityWorld.buildingMap.source.release
    : '建築圖資未載入：'+cityBuildingsError+'。道路仍可正常駕駛。';
  label.style.color=b?'#9ee9d6':'#ffd59d';
}
function updateCityCoordinateStatus(){
  if(!cityWorld?.loaded)return;
  const driving=driveEnvironment==='city'&&gameModes?.mode!=='city';
  const pos=driving&&bridge?.rigidBody?bridge.rigidBody.translation():cityCameraTarget;
  const nearest=cityWorld.closestRoad(pos.x,pos.z,120,driving?pos.y:null);
  const [lon,lat]=metersToLongitudeLatitude([pos.x,pos.z]);
  const description=(driving?'車輛':'預覽中心')+' X東 '+pos.x.toFixed(1)+'m / Z北 '+pos.z.toFixed(1)+
    'm · WGS84 '+lat.toFixed(6)+'°N '+lon.toFixed(6)+'°E';
  const road=nearest ? '最近 '+nearest.roadClass+' 道路 '+nearest.distance.toFixed(1)+'m · 路面寬 '+
    nearest.widthMeters.toFixed(1)+'m（'+(nearest.widthSource==='source-rule'?'Overture 寬度規則':'道路分類估算')+'）'+
    ' · 估算路面 Y '+nearest.y.toFixed(2)+'m / 坡度 '+(nearest.grade*100).toFixed(1)+'%（非 DEM）' :
    '目前位置附近未找到車行路面';
  $('city-coordinate-status').textContent=description+'；'+road;
  $('test-city-coordinates').textContent=description+'；'+road;
}
function refreshCityDiagnostics(){
  if(!$('city-street-status'))return;
  const stats=cityWorld?.stats,detail=cityWorld?.streetDetails?.stats;
  const ground=stats&&detail ? '道路 '+stats.corridors+' 段 · 寬度規則 '+detail.corridorsWithSourceWidth+
    ' 段／分類估算 '+detail.corridorsWithEstimatedWidth+' 段 · 估算人行道 '+
    detail.estimatedSidewalkCorridors+' 段 · 街道視覺三角形 '+detail.visualTriangles+
    ' 個（不影響 Rapier 路面碰撞） · 高架 '+stats.elevatedCorridors+' 段／下凹 '+stats.depressedCorridors+
    ' 段 · 坡度最大 '+(stats.measuredMaxGrade*100).toFixed(1)+'% · 已挖空地面 '+stats.excavatedCells+
    ' 格 · 護欄 '+Math.round(stats.structureGuardrailMeters??0)+'m／擋土壁 '+Math.round(stats.structureRetainingWallMeters??0)+
    'm（雙側總長） · 橋墩 '+(stats.structurePiers??0)+' 座 · 結構碰撞分區 '+(stats.structureCollisionTiles??0)+
    '（非柏油路面碰撞網格）'+
    '（以上為來源層級＋工程估高，非 DEM／現場結構測量） · 路口覆蓋 '+stats.coverageSamples+' 點／漏點 '+stats.coverageMisses : '道路尚未載入';
  $('city-street-status').textContent=ground;
  $('test-city-ground').textContent=ground;
  const audit=cityWorld?.audit;
  const overlaps=audit ? '已比對 '+audit.stats.buildingsChecked+' 棟真實建築，'+
    audit.stats.overlappingBuildings+' 棟疑似與車行柏油面重疊，'+
    audit.stats.overlapTrianglePairs+' 組路面三角形接觸；屬工程估算，待人工確認。' :
    '目前沒有完整道路＋建築資料可執行街廓侵入比對（並不代表零衝突）。';
  const junctions=cityWorld?.junctionQuality,wheels=cityWorld?.wheelCoverage;
  const safety=junctions&&wheels ? '道路路口 '+junctions.stats.junctionsChecked+' 處，'+
    junctions.stats.reviewJunctions+' 處需幾何人工複核（不是確定錯誤）；輪距 '+
    (2*wheels.wheelHalfTrackMeters).toFixed(2)+' m 的左右輪跡 '+wheels.samples+
    ' 點，曲面缺口 '+wheels.missesCount+'；'+wheels.narrowCorridors.length+
    ' 段道路比輪距加安全餘裕更窄，已另列，不屬碰撞缺口。' : '道路輪跡與路口品質尚未檢查。';
  $('city-junction-status').textContent=safety;
  $('city-next-junction').disabled=!junctions?.issues?.length;
  $('city-audit-status').textContent=overlaps;
  $('test-city-audit').textContent=overlaps;
  $('city-next-overlap').disabled=!audit?.issues?.length;
  $('city-export-audit').disabled=!stats;
  if(stats)updateCityCoordinateStatus();
}
function setStreetDebug(flag){
  if(!cityWorld)return;
  cityWorld.setStreetAppearance({diagnostics:Boolean(flag)});
  $('city-show-collision').checked=!!flag;
  refreshCityDiagnostics();
}
function downloadCityAudit(){
  if(!cityWorld?.roadModel)return;
  const payload={version:'1.9.7.1',generatedAt:new Date().toISOString(),
    drivingDataSource:cityMap?.source??null,buildingDataSource:cityWorld.buildingMap?.source??null,
    roadWidth:'mixed: source width rules if present, otherwise estimated per class',
    streetVisuals:'noncolliding estimates: paint, 0.075 m curb, 1.12 m sidewalk',
    limitation:'Geometric candidates only; false positives due to guessed widths, elevated buildings or incomplete geodata; no auto repairs',
    streetStats:cityWorld.streetDetails?.stats??null,
    elevation:{source:'Overture level_rules; NOT surveyed elevation',
      maxGrade:cityWorld.stats?.measuredMaxGrade??null,
      annotatedCorridors:cityWorld.stats?.annotatedCorridors??null,
      upperSoilExcavations:cityWorld.terrainModel?.holes??null},
    structures:{...cityWorld.structureModel?.stats,
      dataQuality:'estimated from source-relative levels; piers and barriers not surveyed'},
    roadSurfaceCoverage:cityWorld.coverage??null,
    wheelTrackCoverage:cityWorld.wheelCoverage??null,junctionQuality:cityWorld.junctionQuality??null,
    results:cityWorld.audit??null};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download='SHIFT_LAB_V197_City_Structures_QA.json';a.click();
  setTimeout(()=>URL.revokeObjectURL(url),3000);
}
function nextStreetIssue(){
  const issues=cityWorld?.audit?.issues;
  if(!issues?.length){$('city-message').textContent='尚未找到需複核的建築重疊候選。';return;}
  cityIssueCursor=(cityIssueCursor+1)%issues.length;
  const entry=issues[cityIssueCursor];
  cityCameraTarget.set(Math.max(-1000,Math.min(1000,entry.x)),0,
    Math.max(-1000,Math.min(1000,entry.z)));
  cityZoom=360;
  setStreetDebug(true);
  updateCityCoordinateStatus();
  $('city-message').textContent='候選 '+(cityIssueCursor+1)+'/'+issues.length+
    '：建築 '+entry.id+' · 單一相交三角形面積最多 '+entry.maxTriangleOverlapSqm+
    'm²。請人工對照實際街廓，估算路面寬度可能造成誤報。';
}

function nextJunctionIssue(){
  const issues=cityWorld?.junctionQuality?.issues;
  if(!issues?.length){$('city-message').textContent='沒有路口幾何需複核候選。';return;}
  cityJunctionCursor=(cityJunctionCursor+1)%issues.length;
  const entry=issues[cityJunctionCursor];
  cityCameraTarget.set(Math.max(-1000,Math.min(1000,entry.x)),0,
    Math.max(-1000,Math.min(1000,entry.z)));
  cityZoom=270;setStreetDebug(true);updateCityCoordinateStatus();
  $('city-message').textContent='路口 '+(cityJunctionCursor+1)+'/'+issues.length+
    '：'+entry.type+'，夾角 '+entry.minimumArmAngleDeg+'°，最短保留道路 '+
    entry.remainingShortestLinkMeters+'m。類別 '+entry.reasons.join('、')+
    '；皆為幾何複核提示，不表示已證實實景錯誤。';
}

function installCityBuildings(map){
  // Preserve the driving game's collider lifecycle on data replacement.
  if(driveEnvironment==='city'){leaveCityDriving();resetDriving('free');}
  const result=cityWorld.setBuildings(map);
  cityIssueCursor=-1;cityJunctionCursor=-1;
  cityBuildingsError='';cityBuildingsStatus();refreshCityDiagnostics();
  return result;
}
function installCityMap(map){
  const validated=validateCityMap(map);
  // Loading a replacement while driving must release the old physics tiles.
  if(driveEnvironment==='city'){leaveCityDriving();resetDriving('free');}
  const stats=cityWorld.setData(validated);
  cityMap=validated;cityLoadError='';cityIssueCursor=-1;cityJunctionCursor=-1;
  cityStatus('路面／Rapier 碰撞體已準備好：按「開始駕駛台南道路」進入真實街道。');
  return stats;
}
function leaveCityDriving(){
  if(driveEnvironment!=='city')return;
  setPause(true);
  cityWorld.setDrivingView(false);
  vehicle?.group.parent?.remove(vehicle.group);
  if(vehicle)scene.add(vehicle.group);
  d.setExternalRoadAdapter(null);
  cityWorld.clearColliders();
  bridge.road=road;
  driveEnvironment='procedural';
  $('city-attribution').hidden=true;
  road.ensure(70);
  world.step(); // Rapier 0.18 query pipeline refreshes in World.step().
  if(typeof world.updateSceneQueries==='function')world.updateSceneQueries();
}
function enterCityDriving(){
  if(!labReady||locked)throw Error('物理引擎未就緒或正在測試');
  if(!cityWorld?.loaded||!cityMap)throw Error('尚未載入有效的台南真實道路資料');
  if(driveEnvironment==='city'){
    resetDriving('free');openGameMode('drive');setPause(false);return;
  }
  setPause(true);
  obstacles.dispose();
  road.clear();road.assertClean();
  try{
    cityWorld.createColliders(RAPIER,world);
    world.step(); // Install all road/building triangles in Rapier's query pipeline first.
    bridge.road=cityWorld;
    if(!d.setExternalRoadAdapter(cityWorld))throw Error('物理核心拒絕 Overture 路網');
    driveEnvironment='city';
    $('city-attribution').hidden=false;
    cityWorld.setDrivingView(true);
    cityWorld.scene.add(vehicle.group);
    resetDriving('free');
    openGameMode('drive');setPause(false);
    driveStatus('台南真實街道 · '+cityWorld.spawnPoint().name+' · Rapier 實體路面 / '+
      (cityWorld.buildingStats?cityWorld.buildingStats.buildings+' 棟真實建築':'建築資料未載入'));
  }catch(error){
    if(driveEnvironment==='city')leaveCityDriving();
    else {cityWorld.clearColliders();bridge.road=road;d.setExternalRoadAdapter(null);road.ensure(70);}
    resetDriving('free');
    setPause(true);
    throw error;
  }
}
function enterProceduralDriving(){
  if(!labReady||locked)return;
  leaveCityDriving();
  resetDriving('free');
  openGameMode('drive');setPause(false);
  driveStatus('已恢復程序化道路 · 台南路網仍可透過選單切換');
}

async function readBundledCityMap({startInCity=false}={}){
  if(!cityWorld) return;
  try{
    const response=await fetch(CITY_MAP_PATH,{cache:'no-store'});
    if(!response.ok)throw new Error('沒有 '+CITY_MAP_PATH+'（HTTP '+response.status+'）。先執行官方資料下載腳本。');
    installCityMap(await response.json());
    await readBundledCityBuildings();
    if(startInCity&&gameModes?.mode==='drive'&&driveEnvironment!=='city')enterCityDriving();
  }catch(error){
    cityLoadError=error.message;
    // Preserve a previously imported, valid city; failed hot reload is not
    // allowed to silently replace the preview with an empty/synthetic map.
    if(!cityMap)cityStatus(cityLoadError,true);
    else $('city-message').textContent='重新讀取未成功，保留已載入版本：'+cityLoadError;
  }
}
async function readBundledCityBuildings(){
  try{
    const response=await fetch(CITY_BUILDING_PATH,{cache:'no-store'});
    if(!response.ok)throw Error('找不到 '+CITY_BUILDING_PATH+'（請在專案中執行 FETCH_TAINAN_BUILDINGS_WINDOWS.cmd）');
    installCityBuildings(await response.json());
  }catch(error){
    cityBuildingsError=error.message;
    cityBuildingsStatus(); // Never create synthetic footprints on a failed download.
  }
}
async function importBuildingFile(file){
  if(!file||file.size>120_000_000)throw Error('建築資料缺失或檔案超過 120 MB');
  const doc=JSON.parse(await file.text());
  const map=doc?.format===CITY_BUILDING_FORMAT?doc:prepareOvertureBuildingMap(doc);
  return installCityBuildings(map);
}
async function importCityFiles(fileList){
  const files=[...fileList];
  if(files.length!==1&&files.length!==2)throw Error('請選完整城市 JSON，或同時選 Overture segment + connector 兩份 GeoJSON');
  if(files.some(file=>file.size>50_000_000))throw Error('單一檔案不得超過 50 MB');
  const docs=await Promise.all(files.map(async file=>JSON.parse(await file.text())));
  if(files.length===1){
    if(docs[0]?.format!=='shiftlab.city.roads.v1')throw Error('單份檔案必須為完整 SHIFT LAB Overture 城市 JSON');
    return installCityMap(docs[0]);
  }
  const isSegment=document=>document?.features?.some(f=>f?.properties?.type==='segment');
  const segments=docs.find(isSegment);
  const connectors=docs.find(doc=>doc!==segments&&doc?.features?.some(f=>f?.properties?.type==='connector'));
  if(!segments||!connectors)throw Error('兩份檔案須分別為 Overture segment 及 connector 的官方輸出');
  return installCityMap(prepareOvertureCityMap(segments,connectors));
}
function setupCityCamera(next,previous){
  if(!camera)return;
  if(next==='city'){
    if(previous!=='city')cityCameraBackup={position:camera.position.clone(),rotation:camera.quaternion.clone()};
    cityWorld?.setDrivingView(false);
    camera.far=5600;camera.updateProjectionMatrix();
  }else if(previous==='city'){
    if(cityCameraBackup){camera.position.copy(cityCameraBackup.position);camera.quaternion.copy(cityCameraBackup.rotation);}
    camera.far=900;camera.updateProjectionMatrix();cityCameraBackup=null;
    if(driveEnvironment==='city')cityWorld?.setDrivingView(true);
  }
}
function renderCity(){
  camera.position.set(cityCameraTarget.x,cityZoom*.87,cityCameraTarget.z+cityZoom*.57);
  camera.lookAt(cityCameraTarget.x,0,cityCameraTarget.z);
  renderer.render(cityWorld.scene,camera);
  if(performance.now()-cityDiagnosticLast>450){cityDiagnosticLast=performance.now();updateCityCoordinateStatus();}
}
function failure(e){
  labReady=false;console.error('v1.9.7.1 game:',e);
  $('status').textContent='載入或執行失敗';
  message.textContent='無法啟動 3D 驗收：'+(e?.message||String(e))+'。請確認 npm install / npm run dev，並使用支援 WebGL2 的桌面瀏覽器。';
  if(!overlay.isConnected)document.body.append(overlay);
  overlay.hidden=false;
  const reload=$('reload-game');if(reload)reload.hidden=false;
}
function waitIframe(){
  return new Promise((resolve,reject)=>{
    const current=frame.contentWindow?.__SHIFT_LAB_DEBUG__;
    if(current){resolve(current);return;}
    const timeout=setTimeout(()=>reject(new Error('原始四輪物理引擎載入逾時')),20000);
    frame.addEventListener('load',()=>{
      clearTimeout(timeout);
      const api=frame.contentWindow?.__SHIFT_LAB_DEBUG__;
      api?resolve(api):reject(new Error('未取得物理核心 API；檢查 physics.html 是否載入'));
    },{once:true});
    frame.addEventListener('error',()=>{clearTimeout(timeout);reject(new Error('讀取 ./physics.html 失敗'));},{once:true});
  });
}
function selectOptions(){
  for(const [id,key,max] of [['pad-axis','axis',12],['pad-gas','gas',24],['pad-brake','brake',24],['pad-clutch','clutch',24]]){
    const select=$(id);
    for(let i=0;i<max;i++)select.add(new Option((key==='axis'?'軸 ':'按鈕 ')+i,String(i)));
    select.value=String(binding[key]);
    select.addEventListener('change',()=>binding[key]=Number(select.value));
  }
}
function readGamepad(){
  const available=typeof navigator.getGamepads==='function'?
    Array.from(navigator.getGamepads()||[]).filter(p=>p?.connected):[];
  const label=available.map(p=>p.index+':'+p.id).join('|');
  if(label!==lastPadLabel){
    const select=$('pad');
    select.replaceChildren(new Option('不使用手柄','off'),new Option('自動使用第一個','auto'));
    for(const pad of available)select.add(new Option(pad.id.slice(0,32),String(pad.index)));
    if(![...select.options].some(o=>o.value===chosenPad))chosenPad='auto';
    select.value=chosenPad;
    lastPadLabel=label;
  }
  if(chosenPad==='off')return null;
  return available.find(p=>String(p.index)===chosenPad)||(chosenPad==='auto'?available[0]:null)||null;
}
function readInputs(dt){
  if(!d||locked||gameModes?.mode!=='drive')return;
  const pad=readGamepad();
  if(!pad){
    lastPadIndex=null;steerFiltered=0;
    Object.assign(d.hostControls,{steer:0,throttle:0,brake:0,clutch:0});
    $('pad-status').textContent='未偵測到手柄；鍵盤仍可操作。';
    return;
  }
  if(lastPadIndex!==pad.index){lastPadIndex=pad.index;steerFiltered=0;}
  const raw=pad.axes?.[binding.axis]??0;
  // Ignore any historical hidden-panel pad-invert setting: the ONE visible
  // web panel controls inversion. Map the visual direction to legacy coordinates.
  const steer=d.normalizedAdvancedAxis(raw,{...d.advancedSteering,padInvert:false});
  const alpha=d.advancedSteering.padFilter>0?1-Math.exp(-dt/d.advancedSteering.padFilter):1;
  steerFiltered+=alpha*(steer-steerFiltered);
  if(Math.abs(steerFiltered)<.012&&Math.abs(steer)<.012)steerFiltered=0;
  const speed=Math.min(1,Math.abs(d.state.velocity)/38);
  d.hostControls.steer=legacySteerFromVisualAxis(steerFiltered,$('pad-invert').checked)*
    (1-.43*d.advancedSteering.padSpeed*speed);
  d.hostControls.throttle=Math.max(0,pad.buttons?.[binding.gas]?.value||0);
  d.hostControls.brake=Math.max(0,pad.buttons?.[binding.brake]?.value||0);
  d.hostControls.clutch=pad.buttons?.[binding.clutch]?.pressed?1:0;
  $('pad-status').textContent='已連接：'+pad.id.slice(0,40)+' · axis '+binding.axis+
    ' / gas '+binding.gas+' / brake '+binding.brake+' / clutch '+binding.clutch;
}
// Optional game accessibility aid. The four-wheel physics and mechanical
// gearbox stay authoritative: this host automates clutch/shift commands only.
// QA scenarios never use this aid, including when the UI selector says assisted.
function updateAutoDrive(){
  if(!d||scenarioId!=='free'||!isAutomaticMode($('drive-mode').value)||locked)return;
  const s=d.state,speed=Math.abs(s.velocity),rpm=s.engineOmega*60/(2*Math.PI);
  const throttle=Math.max(s.throttle||0,d.inputKeys.has('w')?1:d.hostControls.throttle||0);
  const brake=Math.max(s.brake||0,d.inputKeys.has('s')?1:d.hostControls.brake||0);
  // Keep the independent parking restraint engaged even with no brake input.
  d.hostControls.parkPawl=autoRange==='P';
  const desired=automaticRangeRequest({range:autoRange,gear:s.gear,pendingGear:s.pendingGear,
    speedMps:speed,throttle,brake,params:d.params,
    secondsSinceShift:s.time-autoDrive.lastShiftTime});
  // Start/shift through the ORIGINAL mechanical clutch and synchronizer.
  // No direct assignment to state.gear, no R-to-D shift without neutral.
  const shiftRequested=desired!==null;
  d.hostControls.clutch=autoRange==='P'||autoRange==='N'?1:
    automaticClutch({gear:s.gear,pendingGear:s.pendingGear,
      shiftRequested,speedMps:speed,throttle,engineOn:s.engineOn,
      engineRPM:rpm,params:d.params});
  if(!s.engineOn && (s.clutch>.84 || s.gear===0))d.startEngine();
  if(shiftRequested){
    // N/P must be able to cancel a pending synchronizer instantly and safely.
    // All other requests must wait for the existing mechanical synchronizer.
    if(desired===0||s.pendingGear===null&&s.clutch>=.83){
      if(d.requestGear(desired)){
        autoDrive.lastShiftTime=s.time;
        autoDrive.shiftTarget=desired;
      }
    }
  }
  if(s.time%1<1/120)driveStatus('自排 '+autoRange+' · '+
    (s.pendingGear!==null?'同步器換檔中':s.gear===-1?'倒車檔':s.gear===0?'空檔':s.gear+' 檔')+
    ' · 按 M 切換手排');
}
function makeCar(){
  const P=d.params,group=new THREE.Group();
  const bodyMaterial=new THREE.MeshStandardMaterial({color:0x1cb5a0,metalness:.45,roughness:.34});
  const glass=new THREE.MeshStandardMaterial({color:0x173b51,metalness:.22,roughness:.24});
  const body=new THREE.Mesh(new THREE.BoxGeometry(1.76,.42,P.wheelbase*1.48),bodyMaterial);
  body.position.y=.015;body.castShadow=true;group.add(body);
  const roof=new THREE.Mesh(new THREE.BoxGeometry(1.34,.45,1.60),glass);
  roof.position.set(0,.43,-.16);roof.castShadow=true;group.add(roof);
  const white=new THREE.MeshStandardMaterial({color:0xe2f4ff,emissive:0x576d75});
  const red=new THREE.MeshStandardMaterial({color:0xde3739,emissive:0x441016});
  for(const side of [-1,1])for(const front of [-1,1]){
    const lamp=new THREE.Mesh(new THREE.BoxGeometry(.26,.10,.04),front>0?white:red);
    lamp.position.set(side*.62,.05,front*P.wheelbase*.74);group.add(lamp);
  }
  const wheels=[];
  for(const id of d.WHEEL_IDS){
    const p=d.wheelCoords(id);
    const pivot=new THREE.Group();pivot.position.set(p.x,-P.cgHeight+P.wheelRadius,p.z);
    const cylinder=new THREE.Mesh(new THREE.CylinderGeometry(P.wheelRadius,P.wheelRadius,.22,20),
      new THREE.MeshStandardMaterial({color:0x171d20,roughness:.99}));
    cylinder.rotation.z=Math.PI/2;cylinder.castShadow=true;pivot.add(cylinder);
    group.add(pivot);wheels.push({id,pivot,cylinder});
  }
  scene.add(group);return {group,wheels};
}
function syncVisuals(dt){
  const b=bridge.rigidBody,t=b.translation(),rot=b.rotation();
  vehicle.group.position.set(t.x,t.y,t.z);
  vehicle.group.quaternion.set(rot.x,rot.y,rot.z,rot.w);
  for(const {id,pivot,cylinder} of vehicle.wheels){
    pivot.rotation.y=d.wheelModel[id].steer;
    cylinder.rotation.x-=d.wheelModel[id].omega*dt;
  }
  const heading=d.vehicleMotion.heading;
  const fwd=new THREE.Vector3(Math.sin(heading),0,Math.cos(heading));
  const right=new THREE.Vector3(Math.cos(heading),0,-Math.sin(heading));
  const target=new THREE.Vector3(t.x,t.y+.4,t.z);
  const cameraType=$('camera-mode').value;
  const wish=target.clone();
  if(cameraType==='side')wish.addScaledVector(right,11).add(new THREE.Vector3(0,3,0));
  else if(cameraType==='top')wish.add(new THREE.Vector3(0,23,0)).addScaledVector(fwd,-.1);
  else wish.addScaledVector(fwd,-10.5).add(new THREE.Vector3(0,4.0,0));
  camera.position.lerp(wish,Math.max(.04,1-Math.exp(-dt*5)));
  camera.up.set(0,1,0);
  if(cameraType==='top')camera.up.set(0,0,1);
  camera.lookAt(target.clone().addScaledVector(fwd,cameraType==='chase'?5:0));
}
function currentSnapshot(){
  if(!labReady)return {ready:false,error:$('status').textContent};
  const b=bridge.rigidBody,v=b.linvel(),t=b.translation();
  return {ready:true,scenario:scenarioId,paused,step:d.state.time,
    gear:d.state.gear,pendingGear:d.state.pendingGear,clutch:d.state.clutch,
    engineOn:d.state.engineOn,driveMode:$('drive-mode').value,
    autoRange:isAutomaticMode($('drive-mode').value)?autoRange:null,
    parkPawl:!!d.state.parkPawl,
    x:t.x,y:t.y,z:t.z,vx:v.x,vy:v.y,vz:v.z,
    signedVelocity:d.state.velocity,
    speed:Math.hypot(v.x,v.y,v.z),yaw:d.vehicleMotion.yawRate,
    roll:d.vehicleMotion.roll,pitch:d.vehicleMotion.pitch,
    contacts:d.suspension.contacts,rayHits:bridge.wheelCastHits,
    invalidWheelLoads:bridge.invalidWheelLoads,contactMicrosteps:bridge.contactMicrosteps,
    forceResetCount:bridge.forceResetCount,maxExternalForceN:bridge.maxExternalForceN,
    maxExternalTorqueNm:bridge.maxExternalTorqueNm,bodyMassKg:b.mass(),
    railHits:bridge.railHits,
    barrierHits:bridge.barrierHits,collisionCount:bridge.collisionCount,
    impact:bridge.maxImpactImpulse,penetration:bridge.maxBarrierPenetration,
    routeS:d.route.distance,physicsMs,frameDrops:dropSteps,
    driverMode:$('drive-mode').value,inputKeys:[...trackedKeys],mapSeed:d.route.config.seed,
    roadEnvironment:driveEnvironment,cityGroundColliders:cityWorld?.groundHandles.size??0,
    cityClosest:driveEnvironment==='city'?cityWorld.closestRoad(t.x,t.z):null,
    uiMode:gameModes?.mode||'drive',
    driverSteer:visualSteeringFromLegacy(d.vehicleMotion.steerInput),
    legacySteer:d.vehicleMotion.steerInput,roadSurface:d.state.surface,
    vehiclePreset:visualVehicleId,roadResources:(driveEnvironment==='city'?cityWorld:road).resourceStats(),
    focus:document.activeElement?.id||document.activeElement?.tagName||'none'};
}
function htmlMetric(id,text){$(id).textContent=text;}
function updateHud(force=false){
  const now=performance.now();if(!force&&now-lastHud<90)return;
  lastHud=now;
  if(!labReady)return;
  const a=currentSnapshot(),s=d.state,m=d.vehicleMotion;
  const speedKmh=a.speed*3.6,rpmValue=s.engineOmega*60/(2*Math.PI);
  $('dash-speed').textContent=String(Math.round(speedKmh));
  $('dash-rpm').textContent=(Math.max(0,rpmValue)/1000).toFixed(1);
  $('dash-gear').textContent=isAutomaticMode($('drive-mode').value)?
    automaticDisplayGear(autoRange,s.gear):s.gear===-1?'R':s.gear===0?'N':String(s.gear);
  $('speed-dial').style.setProperty('--arc',(Math.max(0,Math.min(speedKmh,240))/240*255).toFixed(1)+'deg');
  $('rpm-dial').style.setProperty('--arc',(Math.max(0,Math.min(rpmValue,7500))/7500*255).toFixed(1)+'deg');
  htmlMetric('speed',(a.speed*3.6).toFixed(1)+' km/h');
  htmlMetric('rpm',Math.round(s.engineOmega*60/(2*Math.PI)).toLocaleString('en-US'));
  htmlMetric('yaw',(m.yawRate*180/Math.PI).toFixed(1)+' °/s');
  const visualSteer=visualSteeringFromLegacy(m.steerInput);
  htmlMetric('steer-direction',visualDirectionLabel(visualSteer)+' · '+
    Math.abs(m.steerAngle*180/Math.PI).toFixed(1)+'°');
  htmlMetric('attitude',(m.roll*180/Math.PI).toFixed(1)+' / '+(m.pitch*180/Math.PI).toFixed(1)+'°');
  htmlMetric('contacts',d.suspension.contacts+' / 4');
  htmlMetric('ext-force',bridge.maxExternalForceN.toFixed(0)+' N / '+bridge.maxExternalTorqueNm.toFixed(0)+' N·m');
  htmlMetric('ray-health',bridge.invalidWheelLoads===0?
    bridge.wheelCastHits+' 命中 / '+bridge.wheelCastMisses+' 未命中':
    '異常 '+bridge.invalidWheelLoads+' 次');
  htmlMetric('esc-status',d.handling.escBrakeNm>5?
    d.handling.escWheel+' '+Math.round(d.handling.escBrakeNm)+' Nm':d.handling.phase);
  htmlMetric('rail-hits',bridge.railHits+' / '+bridge.barrierHits);
  htmlMetric('impact',bridge.maxImpactImpulse.toFixed(0)+' N·s');
  htmlMetric('penetration',bridge.maxBarrierPenetration.toFixed(3)+' m');
  htmlMetric('physics-step',physicsMs.toFixed(2)+' ms');
  htmlMetric('fps',renderFPS.toFixed(0));
  htmlMetric('lost-steps',dropSteps.toString());
  $('engine').textContent=s.engineOn?'引擎已啟動':'啟動引擎 [I]';
  gearSelect.value=String(s.pendingGear??s.gear);
  $('alert').textContent=m.contact?'目前存在路障／護欄接觸，Rapier CCD 已開啟':
    d.suspension.contacts===0?'四輪離地：請觀察車身姿態及落地':'目前無路障／護欄碰撞';
  const events=$('events');events.replaceChildren();
  if(!bridge.eventHistory.length){const li=document.createElement('li');li.textContent='尚無碰撞事件';events.append(li);}
  for(const event of [...bridge.eventHistory].reverse().slice(0,6)){
    const li=document.createElement('li');li.textContent=event.time.toFixed(2)+' s · '+event.type+
      ' · '+(event.speed*3.6).toFixed(1)+' km/h · '+event.impulse.toFixed(0)+' N·s';events.append(li);
  }
}
function displayResult(target,result){
  const root=$(target);root.replaceChildren();
  if(!result)return;
  const summary=document.createElement('div');
  summary.className='result '+(result.pass?'pass':'fail');
  summary.textContent=(result.pass?'PASS':'FAIL')+' · '+SCENARIOS[result.scenario].name+
    ' · '+result.runtimeMs.toFixed(0)+' ms（運算時間）';root.append(summary);
  for(const c of result.checks){
    const line=document.createElement('div');line.className='result '+(c.passed?'pass':'fail');
    line.textContent=(c.passed?'✓':'✕')+' '+c.label+'：'+(typeof c.value==='number'?Number(c.value.toFixed(4)):c.value);
    root.append(line);
  }
}
function renderSuite(){
  const holder=$('suite-results');holder.replaceChildren();
  if(!suiteResults.length)return;
  const heading=document.createElement('h3');heading.textContent='完整驗收：'+suiteResults.filter(r=>r.pass).length+
    ' / '+suiteResults.length+' 通過';holder.append(heading);
  for(const result of suiteResults){
    const item=document.createElement('div');item.className='result '+(result.pass?'pass':'fail');
    item.textContent=(result.pass?'PASS':'FAIL')+' · '+SCENARIOS[result.scenario].name+
      ' · '+result.checks.filter(c=>c.passed).length+'/'+result.checks.length+' 檢查';holder.append(item);
  }
}
function resetDriving(id){
  if(!d||!bridge||!road)return;
  if(id!=='free'&&driveEnvironment==='city')leaveCityDriving();
  const setting=SCENARIOS[id]||SCENARIOS.free;
  if(driveEnvironment!=='city')ensureScenarioMap(id);
  d.reset(); // Also resets the single-authority Rapier body.
  // QA uses the original reference preset; the one visible page owns all free-
  // drive settings. The hidden iframe is a computation engine, never a second UI.
  const free=id==='free';
  const preset=free?$('car-preset').value:'standard';
  if(!d.applyVehicle(preset))throw new Error('無法載入車型 '+preset);
  if(preset!==visualVehicleId){
    if(vehicle){vehicle.group.parent?.remove(vehicle.group);vehicle.group.traverse(part=>{
      if(part.geometry)part.geometry.dispose();
      if(part.material){const list=Array.isArray(part.material)?part.material:[part.material];
        list.forEach(material=>material.dispose());}
    });}
    vehicle=makeCar();visualVehicleId=preset;
    if(driveEnvironment==='city')cityWorld.scene.add(vehicle.group);
  }
  const inner=frame.contentWindow.document;
  inner.getElementById('abs-enabled').checked=free?$('abs-toggle').checked:true;
  inner.getElementById('tcs-enabled').checked=free?$('tcs-toggle').checked:true;
  inner.getElementById('surface-select').value=free?$('road-surface').value:'dry';
  d.setESCEnabled(free?$('esc').value==='on':true);
  d.setHandlingFeel(free?$('feel').value:'balanced');
  d.setHandlingBalance(free?$('handling-balance').value:'neutral');
  d.setBrakeBias(free?Number($('brake-bias').value):.68);
  const steeringPreset=free?$('steering-preset').value:'balanced';
  Object.assign(d.advancedSteering,d.ADV_STEER_PRESETS[steeringPreset]);
  d.roadAppearance.guardrails='both';
  d.hostControls.active=true;
  Object.assign(d.hostControls,{steer:0,throttle:0,brake:0,clutch:0,parkPawl:false});
  trackedKeys.clear();d.inputKeys.clear();
  autoDrive.lastShiftTime=-100;autoDrive.shiftTarget=0;
  autoRange='P';
  if(free&&isAutomaticMode($('drive-mode').value))d.hostControls.parkPawl=true;
  $('range-message').textContent='';
  const inCity=driveEnvironment==='city';
  const point=inCity?cityWorld.spawnPoint():d.roadPointAt(setting.spawnS);
  if(!inCity){road.ensure(point.s);obstacles.configure(id);}
  bridge.teleport({roadPoint:point,side:inCity?0:setting.side,
    angle:inCity?0:setting.angle,speed:inCity?0:setting.speed});
  if(inCity)cityWorld.syncBuildingColliders(point.x,point.z,245,true);
  // The route guard is disabled only while driving Overture. No fake road
  // centerline is ever substituted for a real branching street junction.
  d.vehicleMotion.routeS=point.s;
  d.vehicleMotion.offroad=false;
  d.route.distance=point.s;
  gearSelect.value='0';dropSteps=0;accumulator=0;
  syncTransmissionUI();
  scenarioId=id;
  $('scenario').value=id;
  $('scenario-brief').textContent=setting.description;
  $('status').textContent=inCity?'就緒：台南真實道路 · '+(point.name||point.roadClass)+
    ' · 四輪 Rapier 路面碰撞 / 可自由轉向':'就緒：'+setting.name+' · 單一網頁 / 四輪模型 / Rapier 剛體';
  updateHud(true);
}
function stepOnce(){
  if(driveEnvironment==='city') {
    const p=bridge.rigidBody.translation();
    cityWorld.syncBuildingColliders(p.x,p.z);
  } else road.ensure(d.route.distance);
  const begin=performance.now();
  updateAutoDrive();
  d.advancePhysics(FIXED_DT);
  assertPhysicsHealth(bridge.rigidBody,d);
  physicsMs=performance.now()-begin;
}
function measureBaseline(){
  const p=bridge.rigidBody.translation();
  return {finite:true,nonFiniteSteps:0,maxPositionAbs:0,maxSpeed:0,
    maxTiltDeg:0,maxWheelContacts:0,validWheelSteps:0,
    invalidWheelLoads:0,rayHits:0,maxImpactImpulse:0,
    forceResetCount:0,maxExternalForceN:0,maxExternalTorqueNm:0,bodyMassKg:bridge.rigidBody.mass(),
    barrierHits:0,railHits:0,maxBeyondBarrier:-1e9,
    maxBarrierPenetration:0,minY:p.y,maxY:p.y,
    x:p.x,z:p.z,travel:0,verticalExcursion:0,maxRouteS:d.route.distance,runtimeMs:0};
}
function observe(data,baseline){
  const b=bridge.rigidBody,p=b.translation(),v=b.linvel(),w=b.angvel();
  const vals=[p.x,p.y,p.z,v.x,v.y,v.z,w.x,w.y,w.z];
  if(!vals.every(Number.isFinite)){data.finite=false;data.nonFiniteSteps++;return false;}
  data.maxPositionAbs=Math.max(data.maxPositionAbs,...vals.slice(0,3).map(Math.abs));
  data.maxSpeed=Math.max(data.maxSpeed,Math.hypot(v.x,v.y,v.z));
  data.maxTiltDeg=Math.max(data.maxTiltDeg,
    Math.hypot(d.vehicleMotion.roll,d.vehicleMotion.pitch)*180/Math.PI);
  data.maxWheelContacts=Math.max(data.maxWheelContacts,d.suspension.contacts);
  if(d.suspension.contacts>=2)data.validWheelSteps++;
  data.invalidWheelLoads=bridge.invalidWheelLoads;
  data.rayHits=bridge.wheelCastHits;
  data.forceResetCount=bridge.forceResetCount;
  data.maxExternalForceN=bridge.maxExternalForceN;
  data.maxExternalTorqueNm=bridge.maxExternalTorqueNm;
  if(data.invalidWheelLoads>0){data.finite=false;data.nonFiniteSteps++;return false;}
  data.barrierHits=bridge.barrierHits;data.railHits=bridge.railHits;
  data.maxImpactImpulse=Math.max(data.maxImpactImpulse,bridge.maxImpactImpulse);
  data.maxBarrierPenetration=Math.max(data.maxBarrierPenetration,bridge.maxBarrierPenetration);
  data.maxBeyondBarrier=Math.max(data.maxBeyondBarrier,p.z-obstacles.barrierCenter.z);
  data.minY=Math.min(data.minY,p.y);data.maxY=Math.max(data.maxY,p.y);
  data.verticalExcursion=data.maxY-data.minY;
  data.travel=Math.hypot(p.x-baseline.x,p.z-baseline.z);
  data.maxRouteS=Math.max(data.maxRouteS,d.route.distance);
  return true;
}
function setBusy(value){
  locked=value;
  for(const id of ['scenario','drive-now','load-scenario','run-case','run-suite','reset',
    'pause','step','gear','auto-range','engine','drive-mode','city-drive','drive-tainan',
    'drive-procedural','city-procedural',...preferenceIds])$(id).disabled=value;
  if(!value){$('city-drive').disabled=!cityMap;$('drive-tainan').disabled=!cityMap;}
  if(!value)syncTransmissionUI();
}
async function runScenario(id,options={}){
  if(!labReady)throw new Error('3D 引擎尚未就緒');
  if(locked&&!options.fromSuite)throw new Error('已有測試進行中');
  if(!options.fromSuite)setBusy(true);
  const beforePaused=paused;paused=true;$('pause').textContent='繼續';
  try{
    resetDriving(id);
    const setting=SCENARIOS[id];
    if(!setting.duration)throw new Error('自由試駕沒有自動驗收腳本');
    const data=measureBaseline(),start={x:data.x,z:data.z};
    const startTime=performance.now();
    // Deterministic stepping independent of render FPS. Simulated time is fixed.
    for(let n=0,total=Math.round(setting.duration/FIXED_DT);n<total;n++){
      try{stepOnce();}
      catch(error){data.finite=false;data.nonFiniteSteps++;
        data.abortReason='物理健康檢查失敗：'+error.message;break;}
      if(!observe(data,start))break;
      // Fail visibly and stop this test if the rigid body catastrophically
      // accelerates; do not continue simulating a car launched into the sky.
      if(data.maxSpeed>Math.max(36,setting.speed+45)||data.maxPositionAbs>5000){
        data.abortReason='3D 剛體失穩，停止此工況';break;
      }
      if(n%20===19){updateHud(true);await new Promise(resolve=>requestAnimationFrame(resolve));}
    }
    data.runtimeMs=performance.now()-startTime;
    const graded=gradeScenario(id,data);
    const result={scenario:id,pass:graded.pass,checks:graded.checks,
      metrics:{...data},runtimeMs:data.runtimeMs,
      engine:'Rapier 0.18 + SHIFT LAB four-wheel, 120 Hz / 4 microsteps, v1.9.0 Road v2 + v1.8.9.3 PRND',
      events:bridge.eventHistory.map(e=>({...e}))};
    lastResult=result;displayResult('qa-results',result);updateHud(true);
    $('status').textContent=(result.pass?'PASS':'FAIL')+' · '+setting.name+' · '+graded.checks.filter(x=>x.passed).length+'/'+graded.checks.length;
    return result;
  }finally{
    paused=true; // Leave contact pose on screen so the player can inspect it.
    $('pause').textContent='繼續';
    if(!options.fromSuite)setBusy(false);
    if(!beforePaused)accumulator=0;
  }
}
async function runSuite(){
  if(locked||!labReady)return;
  setBusy(true);suiteResults=[];renderSuite();
  try{
    for(const id of TEST_ORDER){
      $('status').textContent='正在執行 '+SCENARIOS[id].name+' …';
      const result=await runScenario(id,{fromSuite:true});
      suiteResults.push(result);renderSuite();
      if(id==='settle'&&!result.pass){
        $('status').textContent='靜止穩定未通過：已停止後續碰撞與坡道驗收，請先修復基礎剛體';
        break;
      }
    }
    if(suiteResults.length===TEST_ORDER.length)$('status').textContent='3D 驗收完成：'+suiteResults.filter(r=>r.pass).length+'/'+suiteResults.length+
      ' 通過 · 點「開始自由駕駛」繼續試玩';
  }catch(e){failure(e);throw e;}
  finally{setBusy(false);}
  return suiteResults.map(r=>({...r}));
}
function exportReport(){
  const bundle={version:'1.9.0',createdAt:new Date().toISOString(),
    userAgent:navigator.userAgent,
    physics:'Four-wheel SHIFT LAB v1.8.6 bridge / Rapier 3D 0.18',
    suite:suiteResults.map(r=>({...r})),lastResult,
    snapshot:currentSnapshot(),qaScope:'simulator only, not real-vehicle validation'};
  const blob=new Blob([JSON.stringify(bundle,null,2)],{type:'application/json'});
  const href=URL.createObjectURL(blob),link=document.createElement('a');
  link.href=href;link.download='SHIFT_LAB_V1893_Physics_QA_'+new Date().toISOString().slice(0,10)+'.json';
  link.click();setTimeout(()=>URL.revokeObjectURL(href),3000);
}
function installEvents(){
  selectOptions();restorePreferences();syncTransmissionUI();
  $('reload-game')?.addEventListener('click',()=>window.location.reload());
  gameModes=createGameModes(document,{onModeChange(next,previous){
    setupCityCamera(next,previous);
    trackedKeys.clear();if(d)d.inputKeys.clear();
    if(d)Object.assign(d.hostControls,{steer:0,throttle:0,brake:0,clutch:0});
    if(next==='drive'){
      setPause(false);driveFocus();
    }else{
      setPause(true);
      if(next==='settings')updateMapInfo();
      if(next==='city')cityStatus(cityLoadError);
      if(next==='tests')refreshCityDiagnostics();
    }
  }});
  for(const key of MAP_FIELDS){
    $('map-'+key).addEventListener('input',()=>{updateMapFieldLabels();mapMessage('參數尚未套用，點擊「按設定生成」。');});
  }
  $('map-seed').addEventListener('input',()=>mapMessage('種子尚未套用，點擊「按設定生成」。'));
  $('map-generator').addEventListener('change',()=>mapMessage('產生器版本已變更，按「按設定生成」才會重新建立道路。'));
  $('map-generate').addEventListener('click',()=>{
    try{applyMap(readMapForm());}catch(error){mapMessage(error.message,true);}
  });
  $('map-random').addEventListener('click',()=>{
    $('map-seed').value=makeMapSeed();
    try{applyMap(readMapForm());}catch(error){mapMessage(error.message,true);}
  });
  $('map-next-bend').addEventListener('click',()=>{
    try{previewNextBend();}catch(error){mapMessage(error.message,true);}
  });
  $('map-export').addEventListener('click',()=>{
    try{
      const blob=new Blob([serializeMap(userMapConfig)],{type:'application/json'});
      const href=URL.createObjectURL(blob),link=document.createElement('a');
      link.href=href;link.download='SHIFT_LAB_Road_'+userMapConfig.seed+'.json';link.click();
      setTimeout(()=>URL.revokeObjectURL(href),3000);
    }catch(error){mapMessage(error.message,true);}
  });
  $('map-import').addEventListener('click',()=>$('map-import-file').click());
  $('map-import-file').addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file)return;
    try{
      if(file.size>10000)throw Error('道路設定檔不得超過 10 KB');
      const config=readMapDocument(JSON.parse(await file.text()));
      applyMap(config);
    }catch(error){mapMessage('匯入失敗：'+error.message,true);}
    e.target.value='';
  });
  const bindMode=(id,next)=>$(id).addEventListener('click',()=>openGameMode(next));
  bindMode('hud-menu','menu');bindMode('resume-drive','drive');
  bindMode('open-city','city');bindMode('close-city','drive');
  $('city-drive').addEventListener('click',()=>{try{enterCityDriving();}catch(e){$('city-message').textContent=e.message;}});
  $('drive-tainan').addEventListener('click',()=>{try{enterCityDriving();}catch(e){openGameMode('city');cityStatus(e.message,true);}});
  $('drive-procedural').addEventListener('click',enterProceduralDriving);
  $('city-procedural').addEventListener('click',enterProceduralDriving);
  bindMode('open-settings','settings');bindMode('open-tests','tests');
  bindMode('close-settings','drive');bindMode('close-tests','drive');
  $('city-show-markings').addEventListener('change',event=>
    cityWorld?.setStreetAppearance({markings:event.target.checked}));
  $('city-show-sidewalks').addEventListener('change',event=>
    cityWorld?.setStreetAppearance({walkways:event.target.checked}));
  $('city-show-collision').addEventListener('change',event=>setStreetDebug(event.target.checked));
  $('city-next-overlap').addEventListener('click',nextStreetIssue);
  $('city-next-junction').addEventListener('click',nextJunctionIssue);
  $('city-export-audit').addEventListener('click',downloadCityAudit);
  $('test-city-debug').addEventListener('click',()=>setStreetDebug(!cityWorld?.streetAppearance.diagnostics));
  $('test-city-open').addEventListener('click',()=>openGameMode('city'));
  $('city-refresh').addEventListener('click',()=>readBundledCityMap());
  $('city-buildings-refresh').addEventListener('click',readBundledCityBuildings);
  $('city-buildings-import').addEventListener('click',()=>$('city-buildings-import-file').click());
  $('city-buildings-import-file').addEventListener('change',async event=>{
    const input=event.target;
    try{if(input.files?.[0]){const stats=await importBuildingFile(input.files[0]);
      $('city-message').textContent='建築圖資已載入：'+stats.buildings+' 棟；來源高度與估高有分開記錄。';}}
    catch(error){$('city-message').textContent='建築匯入失敗（原資料保留）：'+error.message;}
    finally{input.value='';}
  });
  $('city-import').addEventListener('click',()=>$('city-import-file').click());
  $('city-import-file').addEventListener('change',async event=>{
    const input=event.target;
    if(!input.files?.length)return;
    try{await importCityFiles(input.files);}
    catch(error){$('city-message').textContent='匯入失敗：'+error.message;}
    input.value='';
  });
  $('city-zoom-in').addEventListener('click',()=>{cityZoom=Math.max(240,cityZoom*.81);});
  $('city-zoom-out').addEventListener('click',()=>{cityZoom=Math.min(5500,cityZoom*1.23);});
  for(const [id,dx,dz] of [['city-pan-west',-1,0],['city-pan-east',1,0],
    ['city-pan-north',0,1],['city-pan-south',0,-1]])$(id).addEventListener('click',()=>{
    const step=Math.max(35,Math.min(260,cityZoom*.14));
    cityCameraTarget.x=Math.max(-950,Math.min(950,cityCameraTarget.x+dx*step));
    cityCameraTarget.z=Math.max(-950,Math.min(950,cityCameraTarget.z+dz*step));
  });
  $('city-pan-reset').addEventListener('click',()=>{cityCameraTarget.set(0,0,0);cityZoom=2600;});
  canvas.addEventListener('wheel',event=>{
    if(gameModes?.mode!=='city')return;
    event.preventDefault();
    cityZoom=Math.max(240,Math.min(5500,cityZoom*(event.deltaY>0?1.12:.89)));
  },{passive:false});
  $('menu-reset').addEventListener('click',()=>{if(!locked){resetDriving('free');openGameMode('drive');}});
  for(const id of preferenceIds){
    $(id).addEventListener('change',()=>{
      if(locked)return;
      savePreferences();
      if(!d||!labReady)return;
      if(id==='car-preset'){
        resetDriving('free');setPause(gameModes?.mode!=='drive');
        driveStatus('已切換車型並重置為自由駕駛；使用 W/A/S/D');
      }else if(id==='road-surface'){
        frame.contentWindow.document.getElementById('surface-select').value=$('road-surface').value;
      }else if(id==='abs-toggle'){
        frame.contentWindow.document.getElementById('abs-enabled').checked=$('abs-toggle').checked;
      }else if(id==='tcs-toggle'){
        frame.contentWindow.document.getElementById('tcs-enabled').checked=$('tcs-toggle').checked;
      }else if(id==='handling-balance')d.setHandlingBalance($('handling-balance').value);
      else if(id==='brake-bias')d.setBrakeBias(Number($('brake-bias').value));
      else if(id==='steering-preset')Object.assign(d.advancedSteering,d.ADV_STEER_PRESETS[$('steering-preset').value]);
      if(gameModes?.mode==='drive')driveFocus();
    });
  }
  $('hud-toggle').addEventListener('click',()=>{
    const panel=$('right'),hide=!panel.hidden;
    panel.hidden=hide;
    $('hud-toggle').textContent=hide?'展開詳細數據':'收合詳細數據';
    $('hud-toggle').setAttribute('aria-expanded',String(!hide));
  });
  $('pad').addEventListener('change',e=>{chosenPad=e.target.value;if(gameModes?.mode==='drive')driveFocus();});
  $('auto-range').addEventListener('change',e=>selectAutomaticRange(e.target.value));
  for(const button of document.querySelectorAll('#auto-shifter [data-range]')){
    button.addEventListener('click',()=>{
      selectAutomaticRange(button.dataset.range);
      if(gameModes?.mode==='drive')driveFocus();
    });
  }
  $('scenario').addEventListener('change',e=>$('scenario-brief').textContent=SCENARIOS[e.target.value].description);
  function goFree(){
    if(locked||!labReady)return;
    resetDriving('free');openGameMode('drive');setPause(false);driveFocus();
    driveStatus($('drive-mode').value==='manual'?'手排模式 · 按 I 發動，踩 Shift 入 1 檔後鬆開離合器':
      '自排模式 · 初始 P 檔；踩住煞車後選 D 前進，或選 R 倒車');
  }
  $('drive-now').addEventListener('click',goFree);
  $('load-scenario').addEventListener('click',()=>{if(locked)return;
    resetDriving($('scenario').value);setPause(true);});
  $('reset').addEventListener('click',()=>{if(!locked){resetDriving(scenarioId);setPause(gameModes?.mode!=='drive');}});
  $('pause').addEventListener('click',()=>{if(locked)return;setPause(!paused);driveFocus();});
  $('drive-mode').addEventListener('change',()=>{
    syncTransmissionUI();
    if(!locked&&scenarioId==='free'){resetDriving('free');setPause(gameModes?.mode!=='drive');}
  });
  canvas.addEventListener('pointerdown',driveFocus);
  $('step').addEventListener('click',()=>{if(!locked&&paused){stepOnce();updateHud(true);}});
  $('engine').addEventListener('click',async()=>{
    if(!d||locked)return;
    // The paused Settings panel may contain a parked car already in gear.
    // Press the physical clutch before using the unmodified starter interlock.
    if(gameModes?.mode==='settings'&&d.state.gear!==0&&
      Math.abs(d.state.velocity)<.28&&d.state.clutch<.85){
      setBusy(true);
      const before=d.hostControls.clutch;
      try{
        d.hostControls.clutch=1;
        for(let i=0;i<42&&d.state.clutch<.86;i++)stepOnce();
        d.startEngine();
        driveStatus(d.state.engineOn?'離合器已分離並成功發動引擎':'發動失敗；請檢查原始引擎互鎖');
      }catch(error){driveStatus('發動失敗：'+error.message);}
      finally{d.hostControls.clutch=before;setBusy(false);updateHud(true);}
    }else d.startEngine();
  });
  gearSelect.addEventListener('change',async()=>{
    if(!d||locked)return;
    const target=Number(gearSelect.value);
    if(isAutomaticMode($('drive-mode').value)){
      gearSelect.value=String(d.state.pendingGear??d.state.gear);return;
    }
    if(gameModes?.mode!=='settings'){
      requestDriverGear(target);gearSelect.value=String(d.state.pendingGear??d.state.gear);return;
    }
    setBusy(true);
    try{
      const velocity=bridge?.rigidBody?.linvel();
      const extraSpeed=velocity?Math.hypot(velocity.x,velocity.y,velocity.z):0;
      const result=await engageParkedManualGear({core:d,gear:target,step:stepOnce,
        extraSpeed,yieldFrame:()=>new Promise(resolve=>requestAnimationFrame(resolve))});
      driveStatus((result.ok?'手排：':'未完成排檔：')+result.reason);
    }catch(error){driveStatus('手排操作失敗：'+error.message);}
    finally{setBusy(false);gearSelect.value=String(d.state.pendingGear??d.state.gear);updateHud(true);}
  });
  $('esc').addEventListener('change',()=>{d?.setESCEnabled($('esc').value==='on');});
  $('feel').addEventListener('change',()=>{d?.setHandlingFeel($('feel').value);});
  for(const id of ['pad-axis','pad-gas','pad-brake','pad-clutch','camera-mode']){
    $(id).addEventListener('change',()=>{if(gameModes?.mode==='drive')driveFocus();});
  }
  $('run-case').addEventListener('click',()=>runScenario($('scenario').value).catch(failure));
  $('run-suite').addEventListener('click',()=>runSuite().catch(failure));
  $('export-report').addEventListener('click',exportReport);
  window.addEventListener('keydown',e=>{
    if(e.code==='Escape'){
      e.preventDefault();if(!e.repeat&&!locked)openGameMode(gameModes?.mode==='drive'?'menu':'drive');return;
    }
    if(e.code==='F1'||e.code==='F2'){
      e.preventDefault();if(!e.repeat&&!locked)openGameMode(e.code==='F1'?'settings':'tests');return;
    }
    // Inputs in menus must never operate the car, including gear shortcuts.
    if(gameModes?.mode!=='drive')return;
    const editing=['INPUT','SELECT','TEXTAREA'].includes(e.target?.tagName);
    if(editing||locked)return;
    const key=keys[e.code];
    if(key){
      e.preventDefault();
      // Shift is ONLY the manual clutch. Letting it reach the hidden engine
      // in automatic mode interferes with the automatic clutch actuator.
      if(key==='shift'&&isAutomaticMode($('drive-mode').value))return;
      trackedKeys.add(key);if(d)d.inputKeys.add(legacyDirectionalKey(key));return;
    }
    if(e.repeat)return;
    if(e.code==='Space'){e.preventDefault();setPause(!paused);}
    else if(e.code==='KeyI'){e.preventDefault();d?.startEngine();}
    else if(e.code==='Backspace'){e.preventDefault();resetDriving('free');driveFocus();}
    else if(e.code==='KeyM'){
      e.preventDefault();$('drive-mode').value=$('drive-mode').value==='manual'?'assisted':'manual';
      savePreferences();syncTransmissionUI();
      resetDriving('free');setPause(false);driveFocus();
    }
    else if(isAutomaticMode($('drive-mode').value)&&['KeyP','KeyR','KeyN','KeyF'].includes(e.code)){
      e.preventDefault();
      selectAutomaticRange({KeyP:'P',KeyR:'R',KeyN:'N',KeyF:'D'}[e.code]);
    }
    else if(/^(Digit|Numpad)[0-6]$/.test(e.code)){
      e.preventDefault();requestDriverGear(Number(e.code.slice(-1)));
    }
    else if(e.code==='KeyR'){e.preventDefault();requestDriverGear(-1);}
  });
  window.addEventListener('keyup',e=>{
    const key=keys[e.code];if(key){
      e.preventDefault();trackedKeys.delete(key);
      if(d)d.inputKeys.delete(legacyDirectionalKey(key));
    }
  });
  window.addEventListener('blur',()=>{trackedKeys.clear();if(d)d.inputKeys.clear();});
}
function render(now){
  if(!labReady)return;
  try{
    const elapsed=Math.max(0,Math.min(.075,(now-prevFrame)/1000));prevFrame=now;
    renderFPS+=(1-Math.exp(-elapsed*3))*((elapsed>0?1/elapsed:renderFPS)-renderFPS);
    readInputs(elapsed);
    if(!paused&&!locked){
      accumulator+=elapsed;
      let count=0;
      while(accumulator>=FIXED_DT&&count<8){stepOnce();accumulator-=FIXED_DT;count++;}
      if(accumulator>=FIXED_DT){dropSteps+=Math.floor(accumulator/FIXED_DT);accumulator=0;}
    }else accumulator=0;
    if(gameModes?.mode==='city')renderCity();
    else{syncVisuals(elapsed);renderer.render(driveEnvironment==='city'?cityWorld.scene:scene,camera);updateHud();}
    requestAnimationFrame(render);
  }catch(e){failure(e);}
}
async function boot(){
  installEvents();
  d=await waitIframe();
  d.setExternalClock(true);
  userMapConfig=restoreMapPreference();
  // The hidden core produces BOTH road versions; one centerline is shared by
  // visible Three.js meshes, wheel contact, and Rapier road colliders.
  if(!sameMap(d.route.config,userMapConfig))d.generateRoad(userMapConfig);
  fillMapForm(userMapConfig);updateMapInfo();
  await RAPIER.init();
  if(!window.WebGL2RenderingContext)throw new Error('此瀏覽器不支援 WebGL2');
  scene=new THREE.Scene();scene.background=new THREE.Color(0xa2c0cb);scene.fog=new THREE.Fog(0xa2c0cb,170,650);
  scene.add(new THREE.HemisphereLight(0xe9faff,0x3e493b,2.2));
  const sun=new THREE.DirectionalLight(0xfff1d7,2.45);sun.position.set(-40,125,80);scene.add(sun);
  renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
  renderer.outputColorSpace=THREE.SRGBColorSpace;
  renderer.setPixelRatio(Math.min(2,window.devicePixelRatio||1));
  camera=new THREE.PerspectiveCamera(63,innerWidth/innerHeight,.1,900);
  const resize=()=>{renderer.setSize(canvas.clientWidth,canvas.clientHeight,false);
    camera.aspect=Math.max(1,canvas.clientWidth)/Math.max(1,canvas.clientHeight);camera.updateProjectionMatrix();};
  window.addEventListener('resize',resize);resize();
  world=new RAPIER.World({x:0,y:-9.81,z:0});
  world.maxCcdSubsteps=4;
  road=new RoadWorld(RAPIER,world,scene,d);d.roadAppearance.guardrails='both';road.ensure(70);
  cityWorld=new CityRoadWorld();
  obstacles=new AcceptanceObstacles(RAPIER,world,scene,road);
  bridge=new RapierChassisBridge(RAPIER,world,road,d);bridge.create(d.params);
  if(!d.setChassisBridge(bridge))throw new Error('原始物理核心拒絕外部剛體橋接');
  vehicle=makeCar();labReady=true;
  resetDriving('free');updateMapInfo();
  overlay.remove();
  readBundledCityMap({startInCity:true}); // default to the real city if bundled data is valid; no fake streets
  prevFrame=performance.now();requestAnimationFrame(render);
  window.__SHIFT_LAB_3D_QA__={
    version:'1.9.7.1',steeringMapping:{visualLeft:legacyDirectionalKey('a'),
      visualRight:legacyDirectionalKey('d'),visualPadRight:legacySteerFromVisualAxis(1)},
    get ready(){return labReady;},get paused(){return paused;},snapshot:currentSnapshot,
    loadScenario(id){if(!(id in SCENARIOS))throw Error('未知工況 '+id);if(locked)throw Error('正在執行自動驗收');
      resetDriving(id);paused=true;return currentSnapshot();},
    step(n=1){if(!labReady||locked)throw Error('busy/not ready');paused=true;
      for(let i=0;i<Math.max(0,Math.min(10000,Math.trunc(n)));i++)stepOnce();updateHud(true);return currentSnapshot();},
    runScenario,runSuite,gradeScenario,
    get map(){return {...d.route.config};},
    get savedMap(){return {...userMapConfig};},
    get roadQuality(){return d.route.quality?{...d.route.quality}:null;},
    get city(){return cityMap?{loaded:true,source:cityMap.source,
      stats:{...cityWorld.stats},buildings:cityWorld.buildingStats?{...cityWorld.buildingStats}:null,
      buildingColliders:cityWorld.buildingHandles.size,driving:driveEnvironment==='city'}:{loaded:false,reason:cityLoadError};},
    get cityStreetAudit(){return cityWorld?.audit??null;},
    get citySurfaceCoverage(){return cityWorld?.coverage??null;},
    setCityStreetAppearance(config){return cityWorld?.setStreetAppearance(config)??null;},
    openCity(){openGameMode('city');return this.city;},
    driveCity(){enterCityDriving();return currentSnapshot();},
    driveProcedural(){enterProceduralDriving();return currentSnapshot();},
    resetCity(){if(driveEnvironment!=='city')throw Error('目前未在台南街道');resetDriving('free');return currentSnapshot();},
    applyMap(config){applyMap(config);return currentSnapshot();},
    openMode:openGameMode,selectAutomaticRange,
    get report(){return {lastResult,suiteResults:[...suiteResults]};}
  };
  $('status').textContent='v1.9.7.1 已初始化 · 立體橋墩／護欄／地下擋土壁 / 四輪物理 / PRND';
}
boot().catch(failure);
