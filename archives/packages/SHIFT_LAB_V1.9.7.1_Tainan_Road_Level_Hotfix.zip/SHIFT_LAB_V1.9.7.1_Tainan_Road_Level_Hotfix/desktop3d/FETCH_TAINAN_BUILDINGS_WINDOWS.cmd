@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -m pip show overturemaps >nul 2>nul
  if errorlevel 1 py -m pip install overturemaps
  py scripts\fetch-tainan-buildings.py
) else (
  python -m pip show overturemaps >nul 2>nul
  if errorlevel 1 python -m pip install overturemaps
  python scripts\fetch-tainan-buildings.py
)
if errorlevel 1 (
  echo.
  echo [ERROR] See messages above. No mock buildings were generated.
) else (
  echo.
  echo [OK] Restart / refresh the web game to load the buildings.
)
pause
