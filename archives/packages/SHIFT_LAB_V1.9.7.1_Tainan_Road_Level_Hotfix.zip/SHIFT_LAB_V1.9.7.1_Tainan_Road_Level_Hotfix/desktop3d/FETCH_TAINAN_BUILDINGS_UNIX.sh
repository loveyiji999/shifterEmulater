#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 -m pip install overturemaps
python3 scripts/fetch-tainan-buildings.py
