@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js not found. Install Node.js and retry.
  pause
  exit /b 1
)
node ".\scripts\audit-tainan-streets.mjs"
if errorlevel 1 (
  echo [ERROR] Street QA failed. Inspect above diagnostics.
  pause
  exit /b 1
)
echo.
echo [PASS] See reports\tainan-street-audit.json
pause
