#!/usr/bin/env node
// Transform downloaded official Overture building GeoJSON into compact browser data.
import {readFile,writeFile,mkdir,rename,rm} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {areaBounds} from '../src/city-geo.mjs';
import {prepareOvertureBuildingMap,buildingStatistics} from '../src/city-buildings-geo.mjs';
const base=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const args=process.argv.slice(2);
const positional=args.filter(x=>!x.startsWith('--'));
const outputArg=args.find(x=>x.startsWith('--output='));
const releaseArg=args.find(x=>x.startsWith('--release='));
const sourcePath=resolve(positional[0]??resolve(base,'overture_raw/tainan_building.geojson'));
const outputPath=resolve(outputArg?.slice('--output='.length)||resolve(base,'public/data/tainan-station-buildings.json'));
let temporary=null;
try{
  const buffer=await readFile(sourcePath);
  if(buffer.length>220_000_000)throw Error('GeoJSON 原始檔超過 220MB 安全限額');
  const input=JSON.parse(buffer.toString('utf8'));
  const map=prepareOvertureBuildingMap(input,{release:releaseArg?.slice('--release='.length)});
  const stats=buildingStatistics(map);
  if(!stats.buildings)throw Error('此 GeoJSON 在臺南車站 2×2 km 內沒有 Overture 建築；拒絕寫入空資料');
  await mkdir(dirname(outputPath),{recursive:true});
  temporary=outputPath+'.tmp-'+process.pid;
  await writeFile(temporary,JSON.stringify(map));
  await rename(temporary,outputPath);
  temporary=null;
  const bounds=areaBounds();
  console.log('PASS Overture 台南真實建築資料轉換');
  console.log('WGS84 bbox: '+[bounds.west,bounds.south,bounds.east,bounds.north].map(x=>x.toFixed(8)).join(','));
  console.log('輪廓: '+stats.buildings+' 棟 / '+stats.polygons+' 多邊形');
  console.log('來源高度: '+stats.sourceHeight+'；樓層估高: '+stats.floorEstimated+'；預設估高: '+stats.defaultEstimated);
  console.log('輸出: '+outputPath);
}catch(error){
  if(temporary)await rm(temporary,{force:true}).catch(()=>{});
  console.error('FAIL Overture building 轉檔: '+error.message);
  process.exitCode=1;
}
