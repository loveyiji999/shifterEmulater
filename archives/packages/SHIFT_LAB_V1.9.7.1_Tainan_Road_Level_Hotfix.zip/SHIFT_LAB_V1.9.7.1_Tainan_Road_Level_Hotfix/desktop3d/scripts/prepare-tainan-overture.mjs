#!/usr/bin/env node
// Process the two unmodified official Overture GeoJSON exports into the
// stable, browser-friendly SHIFT LAB city document. Does not access network.
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {resolve, dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {areaBounds, cityStatistics, prepareOvertureCityMap} from '../src/city-geo.mjs';

const base = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const files = process.argv.slice(2).filter(x => !x.startsWith('--'));
const releaseArg = process.argv.find(x => x.startsWith('--release='));
const outputArg = process.argv.find(x => x.startsWith('--output='));
if (files.length !== 2) {
  console.error('使用：node scripts/prepare-tainan-overture.mjs <segment.geojson> <connector.geojson> [--release=YYYY-MM-DD.N] [--output=path]');
  process.exit(2);
}
const segmentPath = resolve(files[0]);
const connectorPath = resolve(files[1]);
const outputPath = outputArg ? resolve(outputArg.slice('--output='.length)) :
  resolve(base, 'public/data/tainan-station-roads.json');
const parse = async path => {
  const input = await readFile(path, 'utf8');
  if (input.length > 100_000_000) throw new Error('單個 GeoJSON 檔案超過 100 MB 保護限制');
  return JSON.parse(input);
};
try {
  const map = prepareOvertureCityMap(await parse(segmentPath), await parse(connectorPath),
    {release: releaseArg ? releaseArg.slice('--release='.length) : undefined});
  const stats = cityStatistics(map);
  await mkdir(dirname(outputPath), {recursive: true});
  await writeFile(outputPath, JSON.stringify(map));
  const bbox = areaBounds();
  console.log('PASS 真實 Overture 資料轉換成功');
  console.log('中心：臺南火車站 / 2 km x 2 km');
  console.log('WGS84 bbox：' + [bbox.west,bbox.south,bbox.east,bbox.north].map(x=>x.toFixed(8)).join(','));
  console.log('道路 ' + stats.segments + ' 筆（車行 ' + stats.vehicular + '；人行 ' + stats.walking + '；軌道 ' + stats.rail + '）');
  console.log('路網連接點 ' + stats.connectors + ' 筆；道路中心線 ' + stats.roadLengthKm + ' km');
  console.log('輸出：' + outputPath);
} catch (e) {
  console.error('FAIL Overture 轉檔：' + e.message);
  process.exit(1);
}
