#!/usr/bin/env python3
"""Fetch (or reconvert) official Overture building features for SHIFT LAB.

- The Overture SDK is the source of a fresh download.
- Parsed/converted GeoJSON never silently changes the source footprints.
- Downloads are retained if the Node converter fails, allowing offline retry.
- Run with --reconvert-only to avoid network/downloads when a cache exists.
- Run with --refresh to explicitly download a new Overture release.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import urllib.request

BASE = Path(__file__).resolve().parent.parent
LAT, LON = 22.9972062216332, 120.212369589515
P = math.radians(LAT)
METERS_LAT = 111132.92 - 559.82 * math.cos(2 * P) + 1.175 * math.cos(4 * P) - 0.0023 * math.cos(6 * P)
METERS_LON = 111412.84 * math.cos(P) - 93.5 * math.cos(3 * P) + 0.118 * math.cos(5 * P)
BBOX = (LON - 1000 / METERS_LON, LAT - 1000 / METERS_LAT,
        LON + 1000 / METERS_LON, LAT + 1000 / METERS_LAT)
RAW = BASE / 'overture_raw' / 'tainan_building.geojson'
TEMP = BASE / 'overture_raw' / 'tainan_building.geojson.download'
RAW_META = BASE / 'overture_raw' / 'tainan_building.source.json'
TEMP_META = BASE / 'overture_raw' / 'tainan_building.geojson.download.source.json'
CONVERTER = BASE / 'scripts' / 'prepare-tainan-buildings.mjs'
OUTPUT = BASE / 'public' / 'data' / 'tainan-station-buildings.json'


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def latest_release():
    try:
        req = urllib.request.Request('https://stac.overturemaps.org/catalog.json',
                                     headers={'User-Agent': 'SHIFT-LAB-1.9.3.1'})
        with urllib.request.urlopen(req, timeout=15) as response:
            result = json.load(response)
        value = result.get('latest')
        return value if isinstance(value, str) and len(value) < 60 else 'latest-via-STAC'
    except (OSError, ValueError, KeyError):
        return 'latest-via-STAC'


def metadata_path(path):
    return TEMP_META if path == TEMP else RAW_META


def save_metadata(path, release):
    record = {
        'provider': 'Overture Maps Foundation',
        'fetchApi': "overturemaps.record_batch_reader('building', bbox=BBOX)",
        'release': release,
        'bbox': list(BBOX),
        'sha256': sha256_file(path),
        'downloadedAt': datetime.now(timezone.utc).isoformat(),
    }
    meta_path = metadata_path(path)
    meta_temp = meta_path.with_suffix('.json.tmp')
    meta_temp.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
    meta_temp.replace(meta_path)


def cached_release(path):
    meta_path = metadata_path(path)
    if meta_path.is_file():
        try:
            info = json.loads(meta_path.read_text(encoding='utf-8'))
            if (info.get('sha256') == sha256_file(path) and
                    info.get('fetchApi') == "overturemaps.record_batch_reader('building', bbox=BBOX)"):
                return str(info.get('release') or 'latest-via-STAC')
            print('WARNING: 快取雜湊與下載紀錄不符，來源 release 將標為未知。', flush=True)
        except (OSError, ValueError):
            print('WARNING: 來源紀錄無法讀取，release 將標為未知。', flush=True)
    return 'unknown-cached-release'


def convert(source, release):
    print('轉換現有 GeoJSON: ' + str(source), flush=True)
    if not source.is_file() or source.stat().st_size == 0:
        raise RuntimeError('GeoJSON 快取不存在或檔案為空')
    try:
        subprocess.run(['node', str(CONVERTER), str(source), f'--release={release}'], check=True)
    except subprocess.CalledProcessError as exc:
        print('保留原始下載檔: ' + str(source), file=sys.stderr, flush=True)
        print('修復程式後可使用 --reconvert-only 重試，無須重新下載。', file=sys.stderr, flush=True)
        raise RuntimeError('Node.js 建築轉檔失敗；原始資料已保留') from exc
    if source == TEMP:
        # Publish the original only after the game-ready JSON was validated.
        TEMP.replace(RAW)
        if TEMP_META.is_file():
            TEMP_META.replace(RAW_META)
    print('PASS 建築圖資可用: ' + str(OUTPUT), flush=True)
    print('請重新整理遊戲網頁以載入台南真實建築量體。', flush=True)


def fresh_download():
    try:
        from overturemaps import record_batch_reader
        from overturemaps.writers import copy, get_writer
    except ImportError as exc:
        raise RuntimeError('未安裝 overturemaps：請執行 py -m pip install overturemaps') from exc
    print('Overture 建築 bbox: ' + ','.join(f'{x:.10f}' for x in BBOX), flush=True)
    release = latest_release()
    print('STAC release: ' + release, flush=True)
    reader = record_batch_reader('building', bbox=BBOX)
    if reader is None:
        raise RuntimeError('Overture building 返回空結果；現有建築檔保留不變')
    TEMP.parent.mkdir(parents=True, exist_ok=True)
    # When refreshing, the existing valid RAW always survives download failures.
    with get_writer('geojson', str(TEMP), schema=reader.schema) as writer:
        copy(reader, writer)
    if not TEMP.is_file() or TEMP.stat().st_size == 0:
        raise RuntimeError('Overture 寫出空的 GeoJSON；保留舊資料')
    save_metadata(TEMP, release)
    convert(TEMP, release)


def main(argv=None):
    parser = argparse.ArgumentParser(description='Fetch/reconvert genuine Overture building GeoJSON')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--reconvert-only', action='store_true', help='Only retry existing .download or .geojson, no network')
    mode.add_argument('--refresh', action='store_true', help='Re-download new release even when local data exists')
    args = parser.parse_args(argv)
    if not args.refresh:
        if TEMP.is_file():
            convert(TEMP, cached_release(TEMP))
            return
        if RAW.is_file():
            convert(RAW, cached_release(RAW))
            return
        if args.reconvert_only:
            raise RuntimeError('找不到可重新轉換的建築檔。原 V1.9.3 可能已刪除 .download，請重新下載一次。')
    fresh_download()


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, subprocess.CalledProcessError) as exc:
        print('FAIL:', exc, file=sys.stderr, flush=True)
        sys.exit(1)
