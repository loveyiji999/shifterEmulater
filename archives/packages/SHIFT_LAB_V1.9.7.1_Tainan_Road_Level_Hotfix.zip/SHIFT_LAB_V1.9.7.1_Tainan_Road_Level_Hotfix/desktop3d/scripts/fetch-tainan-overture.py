#!/usr/bin/env python3
"""Download official Overture transportation data around Tainan Station.

Requires an internet connection and `pip install overturemaps` on the user's
computer. Raw GeoJSON is stored outside public/; browser serves compact output.
No OSM-only or synthetic fallback is ever presented as Overture.
"""
import math
import re
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
ORIGIN_LAT = 22.9972062216332
ORIGIN_LON = 120.212369589515
phi = math.radians(ORIGIN_LAT)
M_LAT = 111132.92 - 559.82 * math.cos(2 * phi) + 1.175 * math.cos(4 * phi) - 0.0023 * math.cos(6 * phi)
M_LON = 111412.84 * math.cos(phi) - 93.5 * math.cos(3 * phi) + 0.118 * math.cos(5 * phi)
BBOX = ','.join(f'{v:.10f}' for v in (
    ORIGIN_LON - 1000 / M_LON, ORIGIN_LAT - 1000 / M_LAT,
    ORIGIN_LON + 1000 / M_LON, ORIGIN_LAT + 1000 / M_LAT))


def main():
    cli = shutil.which('overturemaps')
    if not cli:
        raise RuntimeError('找不到官方 overturemaps CLI。請先執行 python -m pip install overturemaps')
    raw = BASE / 'overture_raw'
    raw.mkdir(exist_ok=True)
    try:
        result = subprocess.run([cli, 'releases', 'latest'], check=True,
                                capture_output=True, text=True, timeout=40)
        match = re.search(r'\d{4}-\d{2}-\d{2}\.\d+', result.stdout)
        release = match.group(0) if match else 'latest-via-STAC'
    except (subprocess.SubprocessError, OSError):
        release = 'latest-via-STAC'
    print('Overture release:', release, flush=True)
    print('WGS84 bbox:', BBOX, flush=True)
    files = []
    for kind in ('segment', 'connector'):
        path = raw / ('tainan_' + kind + '.geojson')
        print('下載 Overture', kind, '...', flush=True)
        subprocess.run([cli, 'download', '--bbox=' + BBOX,
                        '--type=' + kind, '-f', 'geojson', '-o', str(path)], check=True)
        files.append(path)
    print('轉換原始道路及連接點，並執行邊界裁切...', flush=True)
    subprocess.run(['node', str(HERE / 'prepare-tainan-overture.mjs'),
                    *map(str, files), '--release=' + release], check=True)
    print('完成：可啟動 npm run dev，於選單檢視台南車站真實道路', flush=True)


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, subprocess.CalledProcessError) as err:
        print('FAIL:', err, file=sys.stderr)
        sys.exit(1)
