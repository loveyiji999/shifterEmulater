#!/usr/bin/env node
// Offline V1.9.5 geometry report. Uses only Node.js and the same in-game road
// geometry/audit code. Does not download, invent or modify Overture data.
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {validateCityMap} from '../src/city-geo.mjs';
import {validateBuildingMap} from '../src/city-buildings-geo.mjs';
import {buildCityRoadGeometry} from '../src/city-road-geometry.mjs';
import {buildCityStreetDetails} from '../src/city-street-details.mjs';
import {auditCityRoadCoverage,buildCityStreetAudit} from '../src/city-street-audit.mjs';
import {assessCityJunctionQuality,auditCityWheelTrackSupport} from '../src/city-junction-quality.mjs';

const base=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const roadPath=resolve(base,'public/data/tainan-station-roads.json');
const buildingPath=process.argv[2]?resolve(process.argv[2]):resolve(base,'public/data/tainan-station-buildings.json');
const outputPath=process.argv[3]?resolve(process.argv[3]):resolve(base,'reports/tainan-street-audit.json');
try{
  const roadMap=validateCityMap(JSON.parse(await readFile(roadPath,'utf8')));
  const model=buildCityRoadGeometry(roadMap);
  const streets=buildCityStreetDetails(model);
  const coverage=auditCityRoadCoverage(model);
  const junctionQuality=assessCityJunctionQuality(model);
  const wheelTrackCoverage=auditCityWheelTrackSupport(model);
  let buildingMap=null;
  try{buildingMap=validateBuildingMap(JSON.parse(await readFile(buildingPath,'utf8')));}
  catch(err){if(err.code!=='ENOENT')throw err;}
  const buildingAudit=buildingMap?buildCityStreetAudit(model,buildingMap):null;
  const report={format:'shiftlab.city.audit.v195',generatedAt:new Date().toISOString(),
    roadSource:roadMap.source,buildingSource:buildingMap?.source||null,
    roadStats:model.stats,streetVisualStats:streets.stats,roadCoverage:coverage,
    junctionQuality,wheelTrackCoverage,
    buildingAudit,
    caution:'Estimated width, road paint, curb and sidewalk are NOT site surveys. Flagged junctions and building overlaps are review candidates, NOT confirmed defects. Roads narrower than vehicle wheel track are NOT collider gaps. Original Rapier road meshes are unchanged.'};
  await mkdir(dirname(outputPath),{recursive:true});
  await writeFile(outputPath,JSON.stringify(report,null,2)+'\n');
  console.log('PASS V1.9.5 台南路面離線診斷報告');
  console.log('車行 corridors：'+model.corridors.length+'；來源寬度規則：'+streets.stats.corridorsWithSourceWidth+'；分類估算：'+streets.stats.corridorsWithEstimatedWidth);
  console.log('路口中心線：'+coverage.samples+' 點，幾何漏點 '+coverage.missesCount);
  console.log('左右輪跡：'+wheelTrackCoverage.samples+' 點，幾何漏點 '+wheelTrackCoverage.missesCount+
    '；道路過窄 '+wheelTrackCoverage.narrowCorridors.length+' 段');
  console.log('需複核路口：'+junctionQuality.stats.reviewJunctions+' / '+junctionQuality.stats.junctionsChecked);
  if(buildingAudit)console.log('已載入建築 '+buildingAudit.stats.buildingsChecked+' 棟；二維疑似重疊：'+buildingAudit.stats.overlappingBuildings+' 棟');
  else console.log('未找到真實建築資料：省略建築侵入檢查（不能視為 0 棟重疊）');
  console.log('輸出：'+outputPath);
  if(coverage.missesCount>0||wheelTrackCoverage.missesCount>0)process.exitCode=1;
}catch(error){console.error('FAIL V1.9.4 台南路面離線診斷：'+error.message);process.exitCode=1;}
