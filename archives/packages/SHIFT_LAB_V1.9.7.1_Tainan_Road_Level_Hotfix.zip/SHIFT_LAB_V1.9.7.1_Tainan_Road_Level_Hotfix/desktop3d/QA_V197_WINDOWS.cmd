@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22+ or 20.19+ required.
  pause
  exit /b 1
)
echo SHIFT LAB v1.9.7 - City structures, 3D physics compatibility
echo =============================================================
node tests\validate-city-structures-v197.mjs
if errorlevel 1 (echo FAIL: V1.9.7 structure geometry & pause & exit /b 1)
node tests\validate-city-elevation-v196.mjs
if errorlevel 1 (echo FAIL: V1.9.6 3D roads & pause & exit /b 1)
node tests\validate-city-road-v195.mjs
if errorlevel 1 (echo FAIL: legacy flat geometry & pause & exit /b 1)
echo PASS: all offline 3D structures and prior city-geometry regressions.
if exist "node_modules\@dimforge\rapier3d-compat\package.json" (
  echo Running installed Rapier engine integration tests...
  node tests\validate-city-structures-rapier-v197.mjs
  if errorlevel 1 (echo FAIL: V1.9.7 Rapier physics & pause & exit /b 1)
  node tests\validate-city-rapier-v196.mjs
  if errorlevel 1 (echo FAIL: V1.9.6 Rapier physics & pause & exit /b 1)
) else (
  echo NOTE: Rapier not installed, engine integration tests not run.
  echo       In desktop3d run npm ci then npm run qa:city:structures:rapier.
)
pause
