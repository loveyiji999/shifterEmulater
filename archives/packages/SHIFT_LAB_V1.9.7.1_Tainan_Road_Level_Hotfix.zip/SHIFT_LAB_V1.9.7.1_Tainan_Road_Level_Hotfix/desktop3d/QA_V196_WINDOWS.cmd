@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22+ or 20.19+ is required.
  pause
  exit /b 1
)
echo SHIFT LAB v1.9.6 - Offline city road 3D geometry QA
echo ---------------------------------------------------------
node tests\validate-city-elevation-v196.mjs
if errorlevel 1 (echo FAIL: 3D geometry and excavation QA & pause & exit /b 1)
node tests\validate-city-road-v195.mjs
if errorlevel 1 (echo FAIL: V1.9.5 flat compatibility regression & pause & exit /b 1)
echo PASS: V1.9.6 geometry and V1.9.5 planar compatibility.
echo NOTE: actual Rapier and browser drive validation require npm dependencies.
pause
