@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22+ or 20.19+ required.
  pause
  exit /b 1
)
echo SHIFT LAB V1.9.7.1 - Road Datum, Seam, Ramp, and Regression Tests
echo =============================================================
node tests\validate-city-road-level-v1971.mjs
if errorlevel 1 (echo FAIL V1.9.7.1 level/seam test & pause & exit /b 1)
node tests\validate-city-elevation-v196.mjs
if errorlevel 1 (echo FAIL V1.9.6 elevation regression & pause & exit /b 1)
node tests\validate-city-structures-v197.mjs
if errorlevel 1 (echo FAIL V1.9.7 structure regression & pause & exit /b 1)
node tests\validate-city-road-v195.mjs
if errorlevel 1 (echo FAIL V1.9.5 XY/index regression & pause & exit /b 1)
node tests\validate-steering.mjs
if errorlevel 1 (echo FAIL steering & pause & exit /b 1)
node tests\validate-automatic-range.mjs
if errorlevel 1 (echo FAIL PRND & pause & exit /b 1)
echo PASS: Offline V1.9.7.1 and compatibility geometry tests.
if exist "node_modules\@dimforge\rapier3d-compat\package.json" (
  echo Running installed Rapier contact suites...
  node tests\validate-city-rapier-v196.mjs
  if errorlevel 1 (echo FAIL Rapier V196 & pause & exit /b 1)
  node tests\validate-city-structures-rapier-v197.mjs
  if errorlevel 1 (echo FAIL Rapier V197 & pause & exit /b 1)
) else (
  echo NOTE: Rapier/Vite packages absent. In desktop3d run npm ci then:
  echo       npm run qa:city:elevation:rapier
  echo       npm run qa:city:structures:rapier
  echo       npm run build
)
pause
