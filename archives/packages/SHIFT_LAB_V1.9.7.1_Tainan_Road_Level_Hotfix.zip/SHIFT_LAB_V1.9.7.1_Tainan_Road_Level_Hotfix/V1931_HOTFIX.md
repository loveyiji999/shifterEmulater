# SHIFT LAB V1.9.3.1 — Overture 建築 GeoJSON 轉檔 Hotfix

2026-10-22 / 給 V1.9.3 使用者的修正

## 觸發紀錄

- 使用者 Windows Python 3.13、overturemaps 1.0.2，成功透過 `record_batch_reader('building')` 取得 4,985 筆，官方 STAC release `2026-10-21.0`。
- V1.9.3 Node 腳本接著出現 `需要完整官方 Overture buildings/building 特徵`。
- **根因是程式判斷錯誤**：SDK GeoJSON writer 不一定將資料分區 `theme/type` 寫進每個 GeoJSON `properties`；V1.9.3 強制要求兩欄，造成全部合法資料遭拒。
- Python V1.9.3 的 `finally: tmp.unlink()` 又在轉檔失敗時刪掉原始快取，造成無謂重抓。

## 修改位置

1. `desktop3d/src/city-buildings-geo.mjs`：`theme`/`type` 有填才比對，若填錯就拒絕；新增 Overture 必填 `version` 非負整數驗證；持續檢查 id、裁切、幾何、多邊形與輸出授權欄位。**本檢查是資料格式驗證，不是防篡改簽章**。來源可信度來自已知 SDK 下載流程及下載內容的 hash 紀錄，不得單憑手動匯入的 GeoJSON 欄位宣稱完成來源驗證。
2. `desktop3d/scripts/fetch-tainan-buildings.py`：成功下載後才寫 SHA256 和 STAC release 對應的來源紀錄。轉檔成功後才把 `.download` 原始檔移到正式 `.geojson`；任何失敗均保留原始快取，並保留上次有效的遊戲建築檔。新增 `--reconvert-only`、`--refresh`，預設已存在快取時不連網。
3. `desktop3d/tests/validate-city-buildings-v193.mjs`：新增官方 SDK writer 形式（頂層 `feature.id`、無 `theme/type`）和錯誤類型／遺失版本拒絕測試。
4. `desktop3d/tests/validate-building-download-v1931.mjs`：以 4,985 筆**合成測試幾何**模擬官方 writer，從 Python 重新轉檔、保存快取、失敗時維持舊版資料與 checksum release 記錄做 end-to-end 回歸。不含合成建築進遊戲資料夾。

## Windows 使用方式

### 方式 A：在原 V1.9.3 安裝補丁（保留既有圖資／設定）

把 `SHIFT_LAB_V1.9.3.1_Hotfix_Replace_Files.zip` 解壓至你原來的 `SHIFT_LAB_V1.9.3_Tainan_Buildings` 專案**根目錄**，確認覆蓋 `desktop3d/src/city-buildings-geo.mjs`、`desktop3d/scripts/fetch-tainan-buildings.py` 等同名檔。然後雙擊 `desktop3d/FETCH_TAINAN_BUILDINGS_WINDOWS.cmd`。

- 如果 `desktop3d/overture_raw/tainan_building.geojson.download` 或 `tainan_building.geojson` 仍存在，新版會直接使用它，省去重新下載。
- 但 V1.9.3 失敗時通常已刪除 `.download`，所以你這次很可能仍需重新下載一次；V1.9.3.1 之後不再在轉檔失敗時刪掉已完成的下載。
- 成功後確認 `desktop3d/public/data/tainan-station-buildings.json` 存在，重新整理網頁。

### 方式 B：下載 V1.9.3.1 完整專案

解壓 V1.9.3.1 全案，進入其 `desktop3d`，雙擊 `FETCH_TAINAN_BUILDINGS_WINDOWS.cmd`，成功後執行專案根目錄 `START_WEB_WINDOWS.cmd`。

## 測試與限制

- 已執行 Node 轉檔器對應官方 writer 格式的 4,985 筆合成資料測試、Python 離線重轉、原始檔保留、錯誤資料拒絕與已有效資料不覆蓋測試，均通過；非下載真實台南 4,985 筆的實地驗證。
- 原有 12 個**無額外 npm 模組依賴**的道路／操控／傳動／物理狀態 JS 測試均通過。
- 此容器中 `npm ci` 安裝逾時，因此本次未再執行 Vite browser build 及需要 Rapier／Three npm 套件的完整碰撞測試；那些是 V1.9.3 基版之前的測試結果，不能算新的端到端實測。
- 真實台南建築下載／遊戲內 WebGL 畫面仍須你在 Windows 執行驗收。
- 官方資料 ODbL 1.0；正式商用須遵守 Overture 與 OSM 相關署名與資料庫再散布規定。
