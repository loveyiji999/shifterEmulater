## 最新 V1.9.7.1 QA（2026-10-22）

已重現並修復 V1.9.7 的路面基準差（柏油 +0.16 m，建築 0 m，地面 -0.02 m）；現在平面路面 Y=0.025 m、建築／地面 Y=0。臺南 5,832 個路口接合臂的端面高度差符合浮點誤差；最大計算坡度 15%，仍是非實測估算。35,018 個立體柏油三角形、2,110 個地下道路抽樣、822.1 m 低坡補邊（僅視覺）驗收 PASS，V1.9.5 原平面路網 XY/index SHA 回歸 PASS。舊版統計因坡道有效長度修正而更新，詳見 `V1971_QA.md`。

**尚待執行**：Windows Rapier 真實動態碰撞、Vite build、瀏覽器完整駕駛。`npm ci --offline` 因 Vite 套件未快取而失敗，不能將未實測項目列為通過。

---

## 最新 V1.9.7 QA（2026-10-22）

新增立體橋面結構、護欄、橋墩與下凹擋土壁的 **Node 幾何／三維跨層與碰撞區域避讓檢測 PASS**；原 V1.9.6 三維幾何、V1.9.5 平面雜湊、懸吊、轉向與 PRND 回歸測試仍然 PASS。工程生成規模為 20 個推估橋墩、36 個結構碰撞分區。npm Registry DNS `EAI_AGAIN`，Rapier 真正碰撞、Vite 建置與 Windows 駕駛尚未在本環境完成。詳細請見 `V197_QA.md`，新資料未宣稱與現場測繪一致。

---

## 最新 V1.9.6 QA（2026-10-22）

新版本的道路層級、坡道、橋梁及地下道共用三維幾何已完成離線測試。33,610 個 XYZ 柏油三角形、2,094 個接點高度一致、1,382 個下凹道路採樣點無上層地面阻擋；V1.9.5 的 flat 網格回歸 hash 仍通過。**Rapier 真實動態接觸、Vite build 與 Windows WebGL 駕駛尚未在此環境執行，不能宣稱已通過。** 詳見 `V196_QA.md`。

---

## Latest V1.9.5 QA

See `V195_QA.md` for reproducible details and untested browser limitations. V1.9.4 results below are historical and were not silently reinterpreted as newly passed tests.

# V1.9.4 — 台南街道細節與碰撞幾何 QA（2026-10-22）

本次實際完成：新增街道細節視覺層、二維道路／建築侵入候選掃描、WGS84／公尺比例尺顯示、Windows 離線診斷工具；**未改動既有柏油碰撞體頂點與三角形索引**（V1.9.3.1 與 V1.9.4 相同 SHA-256）。

- 全部台南路網 3,196 corridors、962 T 字與 295 四向路口，純幾何覆蓋檢查 36,349 點，0 漏點。新增估算式街道視覺三角形 44,218 個；均不進入 Rapier collider。
- 原有 12 項不需外部 npm 模組之 Node 回歸測試，加上本版街道細節測試，已完成。額外測試離線診斷有／無合成建築兩種情境。
- **限制**：此環境 npm Registry DNS `EAI_AGAIN`；Vite/WebGL2 與實際 Rapier 整合測試無法重新執行。使用者 Windows 取得的真實台南建築資料不在本次執行環境，無法宣稱已逐棟核實所有相交候選。
- 詳細測試清單、手動驗收與證據參見 `V194_QA.md`。以下是先前版本紀錄，不代表 V1.9.4 已重做其所有實測。

---

# V1.9.3 — 台南建築量體 QA 補充（2026-10-22）

完整結果請見 `V193_QA.md` 及 `V193_QA_RESULT.log`。全部 Node 單元／Rapier 道路、建築幾何測試 PASS；Windows 瀏覽器與實際 Overture 台南建築尚未實測。**本版 ZIP 不包含台南建築圖資**，需自行執行 `desktop3d/FETCH_TAINAN_BUILDINGS_WINDOWS.cmd` 後才有建築。原下方為 V1.9.2 歷史紀錄。

---

# 當前發行版：V1.9.2（真實 Overture 路面碰撞）

`npm run qa:all` 已在本次環境 PASS：既有機械／程序化道路／PRND 測試及新 V1.9.2 Rapier 實體幾何驗證；台南 962 個 T 字、295 個四向路口中心與 35,098 個路口連接臂曲線採樣全部具有實際柏油碰撞面。**端到端 WebGL 駕駛、真車式長時間操控與正式 Linux 建置未完成**。詳見 `V192_QA.md`。

---

# 當前發行版：v1.8.9.3

最新 PRND、倒車／前進、坡道駐車及實機待驗範圍，請優先查看 `V1893_QA.md`。以下保留 v1.8.9.2 的歷史品質紀錄，不代表 v1.8.9.3 已完成 Rapier WebGL 驗收。

---

# v1.8.9.2 Stability Integration Gate (2026-10-21)

- **SOURCE QA PASSED**: segmented legacy and new Python/Chromium suites: 103 cases (101 PASS, 2 SKIP for unavailable raw measurement data). Node tests: all nine validation scripts PASS. Original four-wheel iframe core and manual Settings shift pass in Chromium.
- **NATIVE WEBGL GATE UNVERIFIED**: npm package registry DNS error `EAI_AGAIN` blocked installing Rapier/Three/Vite. Consequently no `npm run build`, full 3D acceptance or 30-minute endurance evidence was generated in this environment.
- **Release classification**: v1.8.9.2 source-complete stability candidate, NOT a fully browser-accepted production build.
- Detailed evidence and manual acceptance commands: `V1892_QA.md` and `desktop3d/tests/browser_v1892.py`.

---

# SHIFT//LAB V1.8.5 — Data and compatibility QA

## Genuine gasoline-car source

- BMW M235i original CAN CSV was read and numerically processed via GitHub connector in this conversation; source git SHA1 `9fb7b829265b9e94a09bbc188740dd7d350b0245`.
- 4708 original rows / 341.99s. No invented observations; model split was chosen before tuning.
- Train 1411 rows / holdout 1357 valid rows with 20s temporal gap; speed >5m/s. 60 model combinations are fitted **only on train**.
- Zero-prediction holdout RMSE: **0.69340 m/s²**.
- Static no-lag `v²*steer` holdout RMSE **0.40154 m/s²**, R² 0.664.
- Training-selected delayed nonlinearity holdout RMSE **0.40488 m/s²**, R² 0.658. **WORSE** than the simple no-delay model; failure visible in game panel and exported metrics.
- The connected tool read the entire CSV, but local artifact runtime has DNS blocked. **Do not claim the new Python downloader was executed against full BMW original in the local container**. It is provided for reproducibility on a network-enabled computer; its offline validation, checksum guards and math routines are unit-tested.

## Bucknell P1 raw MAT source check

- All 6 original 500Hz files processed locally after pinned SHA256 verification.
- Both-wheel Fz load plausibility gate: **0/6 passes**. Raw source sensor zero/sign/calibration ambiguity blocks direct transfer of empirical Fy/Fz tire coefficients.

## Ford Fiesta Titanium source check

- Published 2021 Data in Brief paper and original repository document vehicle CAN fields, including engine rpm, gear and clutch position.
- Repository individual CSVs are Git LFS pointer text rather than original observations; no Ford real fit claimed. Exact gasoline engine/gearbox specification not verified.

## Functional integrity

- V1.8.4 2DOF P1 calibrated surrogate and V1.8.3 sensor benchmarks remain unchanged in model functions.
- Runtime game wheel/steer/drivetrain physics parameters remain unchanged. Existing V1.8 reference calibration toggle OFF by default.
- Browser and data QA counts will be filled after running tests. Historical 900+ test suites from V0.4–V1.8 are **not** claimed in V1.8.5 unless rerun.
- The source archive will be ZIP-verified, patched back to V1.8.4 and checked for original raw-file exclusion.

## Executed final QA

- **51/51 total targeted suites**: 12 V1.8.3 + 20 V1.8.4 + 19 V1.8.5, zero failures.
- `P1_RAW_DIR=/mnt/data` explicitly enabled original-file tests for six institution-source MAT recordings. Raw files passed SHA256 checks and the intentional P1 force-channel quality rejection.
- All new Chromium desktop/mobile checks passed, including no horizontal overflow, preserved game debug functions and read-only source data panels.
- Source parity: V1.8.4 → V1.8.5 JS differences consist solely of the new frozen measured-reference object and debug export; no tire, suspension, steering rack, powertrain, replay or input physics algorithm changed.
- BMW published raw content was read using connected GitHub API and processed with deterministic JavaScript; the shipped standalone Python utility was not run on the full remote BMW raw source inside the DNS-restricted artifact container. Its numerical helper functions and checksum rejection were unit-tested.

## V1.9.3.1 Hotfix 回歸

- `node desktop3d/tests/validate-building-download-v1931.mjs`：PASS；4,985 筆官方 writer 形式的合成幾何、離線轉檔、檔案保留、錯誤輸入不覆寫已有效資料、已快取 release/hash 追溯（不是真實台南資料）。
- JS 單元測試 12 項 PASS：automatic-transmission、automatic-range、manual-gear、steering、city-map、procedural-map、road-v2、road-reset、scenarios、ray-contact、physics-health、force-lifecycle。
- `node tests/validate-city-buildings-v193.mjs` 與 `node tests/validate-city-road-v192.mjs` 需要 Three／Rapier。npm 安裝於本容器連網逾時，未在本次再次執行；不能宣稱 V1.9.3.1 全面 browser/physics 整合驗收完成。
