# SHIFT LAB V1.9.4 — 台南街道細化及幾何驗證

基礎：V1.9.3.1 官方 Overture 真實道路與建築 Hotfix；開發日期 2026-10-22。

## 完成的工程變更

1. `desktop3d/src/city-street-details.mjs`：新的純幾何視覺層。根據既有路幅寬度與中心線建立平面標線、低路緣（模型高 0.075m）和估算人行道（1.12m）。路口依 V1.9.2 connector 裁切結果自然斷開。不添加新的車行路面、道路拓撲或任何路緣／人行道 Rapier collider。
2. `desktop3d/src/city-street-audit.mjs`：道路三角形建 45m 空間網格，逐建築 Polygon/MultiPolygon 及 holes 做投影相交面積測試。另沿 T／十字路口實際中心線 36,349 點驗證既有路面三角形的幾何覆蓋，零漏點。回傳疑似侵入清單（有最小交疊閾值）。這是可審核的候選位置，不是現場證據或自動修正。
3. `desktop3d/src/city-road-geometry.mjs`：沿用相同車行三角形與道路碰撞體；僅新增供視覺細節使用的幾何 helper export、道路寬度來源 (`source-rule` vs `estimated-class`) 及 QA 計數。
4. `desktop3d/src/city-world.mjs`：街道外觀獨立 Group；標線和人行道可分別切換。可選擇顯示**原本 Rapier 路面所用的同一批**三角形線框、10m 真比例尺及疑似侵入建築輪廓；不改 Rapier 車體或道路碰撞流程。
5. `desktop3d/index.html` / `src/main.mjs`：城市預覽面板添加圖層開關、碰撞與建築交疊 QA、WGS84 / 東北向米制座標與最近道路寬度來源、逐點導航及診斷 JSON 匯出；測試模式增加相同 QA 摘要。駕駛 HUD 不增加持續性文字。
6. `desktop3d/tests/validate-city-street-v194.mjs`：全量內附台南路網與合成建築 fixture 驗證；測試 fixture 不包進遊戲城市資料。

## 資料忠實性

- 交通道路與建築仍取自原 V1.9.3.1 的官方 Overture 輸入；新增標線、路緣、人行道位置及大小**只有工程估算**。
- 使用者實際下載的 `tainan-station-buildings.json` 不會在這個未取得檔案的環境假造補齊。小型覆蓋包僅取代本次更新程式碼，保留使用者原本的正式建築圖資。
- 道路寬度多數由分類估算，僅部分 corridor 有可用 `width_rules`；不能把標線視作真實車道數／行車方向／交通標誌。
- 地面仍為平面，橋梁、地下道、實際高程尚未建立。街廓相交檢測不代表垂直碰撞或產權邊界正確。

## 相容性與回滾

- 保留 V1.9.3.1 的入口 `START_WEB_WINDOWS.cmd` 與建築下載 `FETCH_TAINAN_BUILDINGS_WINDOWS.cmd`。
- 不變更四輪物理核心、自排/手排/PRND、Rapier 路網 trimesh、建築碰撞物理、地圖檔格式、面板 ID、既有測試 API。
- 新增視覺及 QA 圖層獨立可開關；debug layers 可以在地圖切換／dispose 時完全釋放 GPU 資源。
- 回滾只需將新程式碼覆蓋回 V1.9.3.1，原使用者 Overture 地圖 JSON 可直接沿用。
