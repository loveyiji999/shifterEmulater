# SHIFT LAB V1.9.2 — 臺南真實道路駕駛與路口碰撞實作

開發基準：上傳的 `SHIFT_LAB_V1.9.1_Tainan_Station_Overture.zip` 及內附的 `desktop3d/public/data/tainan-station-roads.json`。發行日期：2026-10-22。

## 實作範圍

1. **真正的道路曲面**：`desktop3d/src/city-road-geometry.mjs` 根據官方 Overture 車行道路的局部公尺中心線及 `widthMeters`，將每段分為可轉向的路廊。沿曲線重新取樣、計算轉角 miter，再產生具有朝上法線的三角帶。沒有以假隨機道路取代台南街道。
2. **路口拓撲**：讀取 `connectorRefs.id` 對應的實際 `connectors[].coordinates`，沿每段道路投影定位 connector；當資料遭 2×2 km 裁切，忽略實際位置離可見道路超過 0.75 m 的陳舊 connector 參照。依同一 connector 所連道路的實際臂數產生二向接點、T 字（3 臂）、四向（4 臂）與複合路口，對各臂作短距離修剪並以路緣點凸包鋪設連續路口區塊。
3. **Rapier 道路碰撞**：`desktop3d/src/city-world.mjs` 用**相同頂點／索引緩衝**建立 Three.js `BufferGeometry` 與 Rapier `ColliderDesc.trimesh()`；依 180 m 空間瓦片和道路類別分組。柏油三角面 Y=0.16 m；區域內另有較低的無名稱地面作越野掉落緩衝。行人道路和鐵道僅視覺呈現，尚無交通碰撞或軌道行車機制。
4. **真正自由轉向**：隱藏的 `public/physics.html` 新增 `setExternalRoadAdapter()`。在真實道路模式，車輛位姿持續由原本四輪 Rapier `RapierChassisBridge` 主導；僅將原程序化路線的最近點／行駛距離參考改為 Overture 路廊的局部查詢，不施加原單線路線重置，也不將車輛鎖在中心線。路網查詢以 50 m 格網加速，不每步搜尋整座城市。
5. **場景切換**：`desktop3d/src/main.mjs` 進入城市時移除程序化道路及 QA 障礙的碰撞體、安裝台南道路碰撞體、將車輛 Three.js 群組移到城市 scene，並在真實道路上重置；返回程序化道路時完整釋放城市碰撞、恢復原場景和外部 adapter。Rapier 0.18 在初次接入後執行一次 `world.step()`，重建射線查詢索引。
6. **啟動預設**：若發行版附帶有效的台南資料，啟動完成後自動進入真實街道駕駛；若沒有資料，維持程序化可駕駛地圖並顯示缺檔訊息。主選單可以明確切換「台南真實街道」與「程序化測試道路」。行駛城市時常駐顯示 Overture／OSM 署名。

## 實際地圖結果

| 指標 | 結果 |
|---|---:|
| 原始道路／步行／軌道路段 | 2,517 |
| 車行道路 | 1,342 |
| 地圖 connector 點 | 4,043 |
| 路廊切分 | 3,196 |
| 分析出的 T 字路口 | 962 |
| 分析出的四向路口 | 295 |
| 其他複合路口 | 28 |
| 朝上柏油三角面 | 30,168 |
| 柏油 trimesh collider | 291 |
| 低位越野地面 collider | 1 |

這些是幾何建模器以**當前下載資料**推得的結果；數量不等於現場經實測的車道、交叉口或通行規則。一個現實路口可能有多個 connector；平行、分岔或重疊道路的拓撲以資料來源為準。

## 已保留／未做的部分

- 保留原四輪懸吊、輪胎、ESC/TCS/ABS、同步器、手排、PRND 自排、鍵盤／手柄和固定 QA 工況；沒有重新擬合車型物理。
- 未導入 Overture turn restrictions、號誌、行車方向限制、車道線、分車道寬度、路肩路緣高度；本版只驗證「碰撞面連續且物理車輛可轉向」。
- 真實高程、橋與地下道上下層及實際立體交叉**尚未完成**。所有可駕駛車行路面在 Y=0.16 m，同一平面附近的非連通道路可能出現幾何覆蓋；不宣稱完整還原實際立體道路。
- 建築、地表材質、碰撞路緣、交通燈／AI 交通、網路多人及分塊動態串流尚未實作。2000×2000 m 地面只是實驗用緩衝面，不是真實地形。

## 核心新增檔案

- `desktop3d/src/city-road-geometry.mjs`
- `desktop3d/tests/validate-city-road-v192.mjs`
- `V192_QA.md`
- `V1.9.1_to_V1.9.2.patch`

資料來源與授權詳見 `DATA_PROVENANCE.md`。來源 `release` 欄仍是原匯入器記錄的 `latest-via-STAC`，尚**未固定可重現的 Overture 正式 release 編號**；若將本版公開商用，需要先確認對應正式 release、ODbL 衍生資料庫義務及歸屬標示。
