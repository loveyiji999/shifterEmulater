# SHIFT LAB V1.9.7.1 — Road Datum / Junction Landing Hotfix

Date: 2026-10-22. Base: user's tested V1.9.7 full release.

## Reproduced causes

1. V1.9.7 placed at-grade vehicle asphalt at world Y=+0.16 m, Overture building footprints at world Y=0, and the terrain mesh at Y=-0.02 m. The ordinary asphalt was 0.16 m above the building base and 0.18 m above the terrain even outside grade-separated crossings.
2. Intersections were filled using a convex hull of the connector and road approach caps. 805 of 11,664 actual cap endpoints were not on the hull boundary; 77 missing cap endpoints had a meaningful original slope-height mismatch. A sloped interpolated hull could thus sit above/below the approach face even though each connected Overture node had a single centre height.
3. V1.9.7 had no physical-looking shoulder fill for low positive ramps before its 1.65 m bridge fascia threshold. Those approaches visually showed a suspended road slab.

## Engineering changes

- Added `desktop3d/src/city-vertical-datum.mjs`: common local ground datum Y=0 and at-grade road Y=0.025 m (2.5 cm clearance against z-fighting). Building bases from Overture default to Y=0. This is a relative local reference, not real DEM/sea-level data.
- Switched the roadway `CITY_ROAD_Y`, elevation profile baseline, terrain ground and bridge/retaining-wall structure datum to this single source. City preview grid is rendered slightly above asphalt to avoid coplanar flickering.
- Road approaches now reserve the computed geometric connector trims as **level landing zones**. Elevation is solved *after* those trim lengths have been fixed. The propagation graph charges the available non-junction road distance for grade changes. Under these rules every rendered road cap lies at exactly the corresponding connector's Y. No fake short steep interpolation is injected at the cap.
- The original two-step positive/negative level propagation still uses the 7.5% estimate per sign; interacting positive and negative profiles can produce up to 15% combined grade. Unsupported grade estimates are explicitly unsurveyed, unchanged in semantics.
- Terrain excavation now uses the actual new ground/road baseline rather than old absolute Y constants, so ordinary ground streets are not accidentally excavated; underpasses remain clear of higher soil.
- Added visual-only sloped side fill (up to the start of the existing bridge fascia) for low raised road approaches; this does not generate colliders or wheel-ray supports. Wall/coping height exclusion was adjusted for the new common datum, keeping separate ground-level crossings unobstructed.
- Three rendering and Rapier roads still consume the same road XYZ buffers. Structural collision tiles still do not enter `groundHandles` wheel contact filters. The Overture map JSON and vehicle physics modules are byte-for-byte retained.

## Changed code

- `src/city-vertical-datum.mjs` (new)
- `src/city-road-geometry.mjs` (profile ordering / corridor end cap heights)
- `src/city-road-elevation.mjs` (trim-aware grade propagation)
- `src/city-terrain-geometry.mjs` (shared ground / excavation threshold)
- `src/city-road-structures.mjs` (datum, crossing-aware wall caps, approach fill)
- `src/city-world.mjs` (scene materials and ground Y)
- `tests/validate-city-road-level-v1971.mjs` (new)
- Legacy geometry tests updated to compare historical *XY/indices* after normalizing the intentionally changed old Y=0.16 datum, and to accept 3D re-tessellation near newly lengthened ramps. Old source map and centreline data are untouched.
- Release labels, Windows QA script and associated docs.

## Limitations

- This is not a reconstruction of surveyed Tainan road/terrain/building elevations. The source `level_rules` indicates relative layers, not absolute height. Some estimated connected ramps legitimately remain above Y=0; a DEM and field mapping are required to know where roads should follow actual natural terrain.
- The new graded shoulder fill is visual only. It does not claim engineering soil parameters or complete drainage/tunnel walls.
- The user needs to verify complete Rapier dynamic contact, Windows WebGL rendering and real downloaded building volumes. This environment lacks downloaded local building files and could not restore npm packages from offline cache.
