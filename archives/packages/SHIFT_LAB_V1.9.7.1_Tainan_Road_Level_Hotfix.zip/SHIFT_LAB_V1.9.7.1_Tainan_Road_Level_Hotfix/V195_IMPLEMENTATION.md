# V1.9.5 — Road Accuracy / Junction Visual Geometry

2026-10-22，基礎：V1.9.4。網頁單機 Vite／Three.js／Rapier。沒有更換任何外部函式、資料格式或交通來源。

## 變更內容

1. `src/city-road-geometry.mjs`：只在 corridor metadata 增加 `sourceStartMeters`，標示從 Overture segment 起點走到 connector 子段起點的公尺數。路面推導、junction convex hull、T／十字拓撲、分區 trimesh 的浮點頂點及索引不變。
2. `src/city-street-details.mjs`：同一來源道路的虛線沿原 segment 的距離採同一相位；路口依 degree／寬度合理退縮視覺標線；新增道路轉角裸露邊緣的 bevel curb/apron 視覺片段；人行道透過現有柏油網格的點覆蓋檢查，避免蓋到已知行駛曲面；所有視覺估算物件均不產生 Rapier collider。
3. `src/city-junction-quality.mjs`：新增路口幾何複核候選與左右輪跡取樣。兩段 1.5m 服務道路因不足 1.56m 輪距而被分類為 width issue，避免誤報為碰撞缺口；不會憑空強加寬度。
4. `src/city-street-audit.mjs`：對凹形建築及內院改採 ring ear-triangulation + convex triangle clipping，降低二維相交面積誤判；對無法安全三角化的壞資料保留保守回退，不阻斷正式圖資匯入。
5. `src/city-world.mjs`：新的 wheel/junction QA 與舊中心線／建築 QA 同時顯示；琥珀色符號標記待複核路口；清理生命週期時釋放所有圖層。
6. `src/main.mjs`、`index.html`：擴充城市 QA 提示、下一處路口複核定位、JSON 匯出，駕駛 HUD 仍不顯示大量測試文字。
7. `scripts/audit-tainan-streets.mjs`、`tests/validate-city-road-v195.mjs`：實際台南道路批次報告／回歸，含全尺寸舊幾何 SHA、輪距、路口、凹形輪廓、連續虛線及人行道排除證明。

## 不變的核心

- 四輪車體、引擎／變速箱、自排 PRND、懸吊／輪胎及手把控制。
- Overture segments/connectors 及 WGS84→公尺投影、校園／街區資料來源標示。
- `CityRoadWorld.createColliders()` 維持原車行 trimesh；不新增假的車道或者行車地面。
- 未觸碰原有 Overture 建築資料或使用者 Windows 本機下載檔；沒有包入合成建物。

## 風險範圍

- 2D「輪跡支撐」與 Rapier 真實接觸是不同指標。無高度資訊的地下道／高架路及緊貼複雜路口仍要目視或實車操作檢查。
- 急角與短道路只作可能問題列表，不是自動修復或違規判斷。
- 一些 Overture `source-rule` 極窄道路不適合預設轎車；若要提供禁入／路寬導航，需另規劃後續資料與路徑邏輯。
- 測試模組沒有任何程式變更會覆蓋使用者 `public/data/tainan-station-buildings.json`。
