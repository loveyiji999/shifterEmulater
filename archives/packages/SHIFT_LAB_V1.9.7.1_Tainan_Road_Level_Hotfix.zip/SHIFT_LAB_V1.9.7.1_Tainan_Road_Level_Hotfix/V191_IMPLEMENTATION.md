# SHIFT LAB V1.9.1 — 台南車站 Overture 真實道路導入

開發基準：V1.9.0。開發區域固定為臺南火車站（臺南市東區北門路二段4號）**2,000 m × 2,000 m**。

## 1. 地理基準與裁切範圍

- 參考來源：文化部國家文化記憶庫，「臺南火車站」，緯度 `22.9972062216332`、經度 `120.212369589515`。
- WGS84 經緯度順序為 longitude, latitude。以站體為局部公尺座標原點 `[x=0,z=0]`，x 軸朝東，z 軸朝北。
- 當地 WGS84 平面近似尺度由橢球的每度公尺長計算。在 2 km 範圍內可作為展示及遊戲局部座標；未作測量級投影精度保證。
- 範圍：西 `120.2026158340`、南 `22.9881763836`、東 `120.2221233450`、北 `23.0062360596`。
- 官方 bbox 下載只做資料候選篩選；本地 `clipPolylineToSquare` 以公尺座標再次精確裁切，跨越邊界的中心線不超出 1,000m。

## 2. 已建立的程式模組

- `desktop3d/src/city-geo.mjs`：獨立、無依賴的 Overture GIS 資料解析、邊界計算、座標轉換、道路裁切、ODbL attribution、穩定 JSON 格式與安全驗證。
- `desktop3d/src/city-world.mjs`：隔離的 Three.js 3D 預覽 scene，依分類建立地面道路帶狀 mesh、軌道與步行路線；包含 2km 格線、邊界和台南車站原點標記。
- `desktop3d/scripts/fetch-tainan-overture.py`：跨平台呼叫 Overture 官方 Python CLI，下載 `transportation/segment` 及 `transportation/connector`。保留原始 GeoJSON 於 `desktop3d/overture_raw/`。
- `desktop3d/scripts/prepare-tainan-overture.mjs`：將實際資料轉成 `public/data/tainan-station-roads.json`，保留原始 GERS ID、connectors / at fractional reference、names、subtype、class、level rules、width rules 與來源 release 資訊。
- `desktop3d/src/main.mjs`, `desktop3d/index.html`, `desktop3d/src/game-modes.mjs`：主選單新增「臺南車站 · 真實道路預覽」；支援放置本地 JSON 檔或直接匯入兩份官方 GeoJSON，預覽滑鼠滾輪縮放及重新讀取。
- `desktop3d/tests/validate-city-map.mjs`：本地假資料**僅作單元測試**，絕不公開渲染成台南真實道路。

## 3. 實際資料取得與使用

本地使用者需能連外，於 `desktop3d/` 執行：

```sh
python -m pip install overturemaps
python scripts/fetch-tainan-overture.py
npm install
npm run dev
```

登入網頁後在選單點「臺南車站 · 真實道路預覽」。若尚未取得真實 Overture 檔案，畫面只出現 **2km 外框與車站中心標記**，並明確警告資料尚未載入；不以隨機生成器替代街道。可直接在程式中匯入**兩份** Overture GeoJSON（segment、connector）或預處理後的完整 JSON，不需要資料庫伺服器。玩家使用正式部署版時，不需要安裝 GIS／Python CLI，僅需部署已轉好的 JSON。

## 4. 原版功能隔離

- 原有程序化道路 v1、v2 演算法、使用者 seed、物理引擎、四輪 Rapier、PRND、手排、QA 工況及測試障礙不因城市預覽而修改。
- 城市預覽使用不同的 Three.js scene，非駕駛模式，暫停汽車物理更新，不新增或移除真實 RoadWorld colliders；退出預覽後還原駕駛相機。
- 程序化道路仍為目前可駕駛的唯一地圖；不可誤認為 V1.9.2 的可駕駛真實路口已完成。

## 5. 後續版本必要工作

- V1.9.2：根據 Overture 原始 connector 拓撲與禁止轉向規則建構路口／車道／可駕駛真實路面（目前僅保留參照，尚無轉向圖或物理路面）。
- V1.9.3：增加 `buildings/building` 取得、真實建築輪廓與高度估計。
- V1.9.4：依可靠高程與 `level_rules` 處理橋、地下道；目前所有真實道路預覽均被平鋪在 y=0 附近，**不代表真實高度**。
- V1.9.5：位置區塊串流、動態資源配置及實際 3D 效能驗證。

## 6. 授權與限制

Overture transportation 為 ODbL 1.0，署名文字 `© OpenStreetMap contributors, Overture Maps Foundation` 已置於預覽模式。請保留實際來源 release、下載日期及必要的上游授權資訊。商業公開改編資料庫時，必須另行評估 ODbL 署名及衍生資料庫義務。

**本執行環境無法存取 Overture GeoParquet 雲端，本次交付的 ZIP 未包含台南實際道路 GeoJSON／JSON。** 因缺乏 npm `three`, `vite`, `@dimforge/rapier3d-compat` 相依套件，本地亦不能證明 WebGL/Rapier 實機畫面已通過。詳見 `V191_QA.md`。
