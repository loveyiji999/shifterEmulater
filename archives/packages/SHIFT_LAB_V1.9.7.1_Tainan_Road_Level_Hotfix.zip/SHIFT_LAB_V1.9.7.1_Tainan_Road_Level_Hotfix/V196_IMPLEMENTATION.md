# V1.9.6 實作說明：道路高程、坡道、橋面與地下道物理

日期：2026-10-22，基礎：使用者上傳的 V1.9.5 ZIP。此次僅針對道路立體物理和必要相依修改，不改動整車動力系統及 Overture 原始 GeoJSON。

## 主要修改

| 模組 | 修改 | 保證／限制 |
|---|---|---|
| `src/city-geo.mjs` | `clipPolylineWithSourceRanges()` 沿原始中心線距離記錄每一裁切片段的 `[from,to]` | 經來源比對：2,517 條道路 ID、XY、寬度、connector、`levelRules` 與舊版完全相等 |
| `src/city-road-elevation.mjs`（新增） | 由 `level_rules` 的區間映射到 connector 分割後的 corridor，再以相連道路網路傳播估算坡度 | 高度非 DEM；預設每層 5.25m，單一正或負層級每米衰減 0.075m，正負影響可能疊加達 15% |
| `src/city-road-geometry.mjs` | 路面頂點 Y 改為連續坡度採樣；道路路口使用 connector 高度的面片扇形；`closestRoad` 增加高度提示，`pickSpawn` 回傳實際 Y | 無 connector 的跨層交叉不受高度傳播；Flat 相容模式維持原 30,168 三角形／sha256 |
| `src/city-terrain-geometry.mjs`（新增） | 以 10m 方格裁切原本整塊阻擋地下道的地面土壤，建立真實渲染與碰撞共用的 terrain buffer | 非真實挖填設計／DEM，孔洞下方配置安全恢復面 |
| `src/city-world.mjs` | Rapier road + 3D soil 均與 Three renderer 共用頂點／索引資料，原程序化道路不改 | 地面新增「上層挖空碰撞」與「下層恢復面」；更換地圖時回收碰撞 |
| `src/city-street-details.mjs` | 虛線、車道邊線、路緣、人行道根據其所屬 corridor 的 3D 高度修正 | 仍僅供可視化，沒有額外路緣／人行道碰撞 |
| `src/chassis.mjs` | 真實地圖 reset/teleport 使用道路點 Y，而非程序化全域路線 s | 原程序化道路模擬和四輪受力方程式保持不變 |
| `src/main.mjs` / `index.html` | 狀態視窗顯示估算道路高度／坡度、上下層數量與挖空方格數；新 QA 匯出 | 明確呈現沒有實測 DEM 的限制 |
| `tests/` | 加入 V196 3D 幾何／土壤 QA 與可選 Rapier 實測接觸腳本 | 前版 V195 哈希由 `elevationMode:'flat'` 檢測 |

## 單位與幾何規則

- 本地 X 向東，Z 向北，Y 垂直向上，單位公尺。只有可駕駛車行道路會在車輛路面物理中生成 Rapier 三角網格；人行及軌道沿用純視覺層。
- 真實來源給出 XY、道路 class、connector 和少數 `level_rules`。未標示的道路以 Y=0.16m 為基礎，無海拔真值；`level=1` 約 +5.25m、`level=-1` 約 -5.25m、`level=2` 約 +10.50m，這些是工程估高。
- 索引按 connector IDs 建立，只將**真實物理相連**的線段共同過渡。每條高度函式 `edge.heightAt(s)` 以正負樓層距離影響相加，避免生成不連接的虛構匝道；但若正負層級靠近，可能超過單側 7.5% 工程坡度。
- 建物資料仍獨立載入。V196 不調整建築足跡／高度，不偽造地形地圖。真正高架結構、護欄、隧道門廊、橋墩及與建築的立面高程校核在 V1.9.7 之後完成。

## 開發限制

沒有附帶實際臺南道路海拔或 DEM。繪製曲面與 Rapier 共用 buffer **能驗證引擎物理／視覺位置一致**，卻**不構成實地高程正確**。使用者需 Windows＋Vite＋Rapier 實際駕駛驗收；只有純 Node 測試通過，不代表真實瀏覽器動態碰撞無問題。
