@echo off
setlocal
cd /d "%~dp0.."
for %%F in (desktop3d\tests\validate-*.mjs) do (
  node "%%F"
  if errorlevel 1 exit /b 1
)
for %%F in (tests\test_v*.py) do (
  echo ==== %%~nxF ====
  python -m unittest discover -s tests -p "%%~nxF" -q
  if errorlevel 1 exit /b 1
)
echo Source QA complete. Run python desktop3d\tests\browser_v1893.py for real WebGL/Rapier.
